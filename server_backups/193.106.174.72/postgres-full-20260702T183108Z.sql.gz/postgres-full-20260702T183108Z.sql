--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE IF EXISTS gigme;
DROP DATABASE IF EXISTS template_postgis;




--
-- Drop roles
--

DROP ROLE IF EXISTS gigme;


--
-- Roles
--

CREATE ROLE gigme;
ALTER ROLE gigme WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:mTeMNhq1u+1vnewLm9VbIg==$tsHX7T8E+NPU8vSxQ4BVs7koRU+9TWZ3LVSf2khIELg=:c8vTjMAHbFiRPxtZ+ifo6RvqzM04cC7WG+sjDOzLvZI=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: gigme
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO gigme;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: gigme
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: gigme
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: gigme
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "gigme" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: gigme; Type: DATABASE; Schema: -; Owner: gigme
--

CREATE DATABASE gigme WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE gigme OWNER TO gigme;

\connect gigme

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: gigme; Type: DATABASE PROPERTIES; Schema: -; Owner: gigme
--

ALTER DATABASE gigme SET search_path TO '$user', 'public', 'topology', 'tiger';


\connect gigme

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO gigme;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO gigme;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO gigme;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: gigme
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_bot_messages; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.admin_bot_messages (
    id bigint NOT NULL,
    chat_id bigint NOT NULL,
    direction text NOT NULL,
    message_text text NOT NULL,
    telegram_message_id bigint,
    sender_telegram_id bigint,
    sender_username text,
    sender_first_name text,
    sender_last_name text,
    admin_telegram_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT admin_bot_messages_direction_check CHECK ((direction = ANY (ARRAY['INCOMING'::text, 'OUTGOING'::text])))
);


ALTER TABLE public.admin_bot_messages OWNER TO gigme;

--
-- Name: admin_bot_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.admin_bot_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_bot_messages_id_seq OWNER TO gigme;

--
-- Name: admin_bot_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.admin_bot_messages_id_seq OWNED BY public.admin_bot_messages.id;


--
-- Name: admin_broadcast_jobs; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.admin_broadcast_jobs (
    id bigint NOT NULL,
    broadcast_id bigint NOT NULL,
    target_user_id bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_broadcast_jobs OWNER TO gigme;

--
-- Name: admin_broadcast_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.admin_broadcast_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_broadcast_jobs_id_seq OWNER TO gigme;

--
-- Name: admin_broadcast_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.admin_broadcast_jobs_id_seq OWNED BY public.admin_broadcast_jobs.id;


--
-- Name: admin_broadcasts; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.admin_broadcasts (
    id bigint NOT NULL,
    admin_user_id bigint NOT NULL,
    audience text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_broadcasts OWNER TO gigme;

--
-- Name: admin_broadcasts_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.admin_broadcasts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_broadcasts_id_seq OWNER TO gigme;

--
-- Name: admin_broadcasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.admin_broadcasts_id_seq OWNED BY public.admin_broadcasts.id;


--
-- Name: admin_event_parser_events; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.admin_event_parser_events (
    id bigint NOT NULL,
    source_id bigint,
    source_type text NOT NULL,
    input text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    date_time timestamp with time zone,
    location text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    links text[] DEFAULT '{}'::text[] NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    parser_error text,
    parsed_at timestamp with time zone DEFAULT now() NOT NULL,
    imported_event_id bigint,
    imported_by bigint,
    imported_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT admin_event_parser_events_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'imported'::text, 'rejected'::text, 'error'::text])))
);


ALTER TABLE public.admin_event_parser_events OWNER TO gigme;

--
-- Name: admin_event_parser_events_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.admin_event_parser_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_event_parser_events_id_seq OWNER TO gigme;

--
-- Name: admin_event_parser_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.admin_event_parser_events_id_seq OWNED BY public.admin_event_parser_events.id;


--
-- Name: admin_event_parser_sources; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.admin_event_parser_sources (
    id bigint NOT NULL,
    source_type text DEFAULT 'auto'::text NOT NULL,
    input text NOT NULL,
    title text,
    is_active boolean DEFAULT true NOT NULL,
    last_parsed_at timestamp with time zone,
    created_by bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_event_parser_sources OWNER TO gigme;

--
-- Name: admin_event_parser_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.admin_event_parser_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_event_parser_sources_id_seq OWNER TO gigme;

--
-- Name: admin_event_parser_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.admin_event_parser_sources_id_seq OWNED BY public.admin_event_parser_sources.id;


--
-- Name: event_comments; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.event_comments (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_comments OWNER TO gigme;

--
-- Name: event_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.event_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_comments_id_seq OWNER TO gigme;

--
-- Name: event_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.event_comments_id_seq OWNED BY public.event_comments.id;


--
-- Name: event_likes; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.event_likes (
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_likes OWNER TO gigme;

--
-- Name: event_media; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.event_media (
    id bigint NOT NULL,
    event_id bigint NOT NULL,
    url text NOT NULL,
    type text DEFAULT 'image'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_media OWNER TO gigme;

--
-- Name: event_media_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.event_media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.event_media_id_seq OWNER TO gigme;

--
-- Name: event_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.event_media_id_seq OWNED BY public.event_media.id;


--
-- Name: event_participants; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.event_participants (
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    status text DEFAULT 'joined'::text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.event_participants OWNER TO gigme;

--
-- Name: events; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.events (
    id bigint NOT NULL,
    creator_user_id bigint NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone,
    location public.geography(Point,4326) NOT NULL,
    address_label text,
    capacity integer,
    is_hidden boolean DEFAULT false NOT NULL,
    promoted_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    filters text[] DEFAULT '{}'::text[] NOT NULL,
    contact_telegram text,
    contact_whatsapp text,
    contact_wechat text,
    contact_fb_messenger text,
    contact_snapchat text,
    is_private boolean DEFAULT false NOT NULL,
    access_key text,
    links text[] DEFAULT '{}'::text[] NOT NULL,
    is_landing_published boolean DEFAULT false NOT NULL
);


ALTER TABLE public.events OWNER TO gigme;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO gigme;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: landing_content; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.landing_content (
    id smallint DEFAULT 1 NOT NULL,
    hero_eyebrow text DEFAULT ''::text NOT NULL,
    hero_title text DEFAULT ''::text NOT NULL,
    hero_description text DEFAULT ''::text NOT NULL,
    hero_primary_cta_label text DEFAULT ''::text NOT NULL,
    about_title text DEFAULT ''::text NOT NULL,
    about_description text DEFAULT ''::text NOT NULL,
    partners_title text DEFAULT ''::text NOT NULL,
    partners_description text DEFAULT ''::text NOT NULL,
    footer_text text DEFAULT ''::text NOT NULL,
    updated_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sonic_stage_title text DEFAULT ''::text NOT NULL,
    sonic_stage_description text DEFAULT ''::text NOT NULL,
    sonic_stage_image_url text DEFAULT ''::text NOT NULL,
    lensound_stage_title text DEFAULT ''::text NOT NULL,
    lensound_stage_description text DEFAULT ''::text NOT NULL,
    lensound_stage_image_url text DEFAULT ''::text NOT NULL,
    space_stage_title text DEFAULT ''::text NOT NULL,
    space_stage_description text DEFAULT ''::text NOT NULL,
    space_stage_image_url text DEFAULT ''::text NOT NULL,
    CONSTRAINT landing_content_id_check CHECK ((id = 1))
);


ALTER TABLE public.landing_content OWNER TO gigme;

--
-- Name: notification_jobs; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.notification_jobs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint,
    kind text NOT NULL,
    run_at timestamp with time zone NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_jobs OWNER TO gigme;

--
-- Name: notification_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.notification_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_jobs_id_seq OWNER TO gigme;

--
-- Name: notification_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.notification_jobs_id_seq OWNED BY public.notification_jobs.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    order_id uuid NOT NULL,
    item_type text NOT NULL,
    product_id uuid NOT NULL,
    product_ref text NOT NULL,
    quantity integer NOT NULL,
    unit_price_cents bigint NOT NULL,
    line_total_cents bigint NOT NULL,
    meta_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT order_items_item_type_check CHECK ((item_type = ANY (ARRAY['TICKET'::text, 'TRANSFER'::text]))),
    CONSTRAINT order_items_line_total_cents_check CHECK ((line_total_cents >= 0)),
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT order_items_unit_price_cents_check CHECK ((unit_price_cents >= 0))
);


ALTER TABLE public.order_items OWNER TO gigme;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_items_id_seq OWNER TO gigme;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint NOT NULL,
    status text NOT NULL,
    payment_method text NOT NULL,
    payment_reference text,
    payment_notes text,
    promo_code_id uuid,
    subtotal_cents bigint NOT NULL,
    discount_cents bigint DEFAULT 0 NOT NULL,
    total_cents bigint NOT NULL,
    currency text DEFAULT 'RUB'::text NOT NULL,
    confirmed_at timestamp with time zone,
    canceled_at timestamp with time zone,
    redeemed_at timestamp with time zone,
    confirmed_by bigint,
    canceled_by bigint,
    canceled_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT orders_discount_cents_check CHECK ((discount_cents >= 0)),
    CONSTRAINT orders_payment_method_check CHECK ((payment_method = ANY (ARRAY['PHONE'::text, 'USDT'::text, 'PAYMENT_QR'::text, 'TOCHKA_SBP_QR'::text]))),
    CONSTRAINT orders_status_check CHECK ((status = ANY (ARRAY['PENDING'::text, 'PAID'::text, 'CANCELED'::text, 'REDEEMED'::text]))),
    CONSTRAINT orders_subtotal_cents_check CHECK ((subtotal_cents >= 0)),
    CONSTRAINT orders_total_cents_check CHECK ((total_cents >= 0))
);


ALTER TABLE public.orders OWNER TO gigme;

--
-- Name: payment_settings; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.payment_settings (
    id smallint DEFAULT 1 NOT NULL,
    phone_number text DEFAULT ''::text NOT NULL,
    usdt_wallet text DEFAULT ''::text NOT NULL,
    usdt_network text DEFAULT 'TRC20'::text NOT NULL,
    usdt_memo text DEFAULT ''::text NOT NULL,
    phone_description text DEFAULT ''::text NOT NULL,
    usdt_description text DEFAULT ''::text NOT NULL,
    qr_description text DEFAULT ''::text NOT NULL,
    sbp_description text DEFAULT ''::text NOT NULL,
    updated_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_qr_data text DEFAULT ''::text NOT NULL,
    phone_enabled boolean DEFAULT true NOT NULL,
    usdt_enabled boolean DEFAULT true NOT NULL,
    payment_qr_enabled boolean DEFAULT true NOT NULL,
    sbp_enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT payment_settings_id_check CHECK ((id = 1))
);


ALTER TABLE public.payment_settings OWNER TO gigme;

--
-- Name: payment_settings_scoped; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.payment_settings_scoped (
    scope text NOT NULL,
    phone_number text DEFAULT ''::text NOT NULL,
    usdt_wallet text DEFAULT ''::text NOT NULL,
    usdt_network text DEFAULT 'TRC20'::text NOT NULL,
    usdt_memo text DEFAULT ''::text NOT NULL,
    payment_qr_data text DEFAULT ''::text NOT NULL,
    phone_enabled boolean DEFAULT true NOT NULL,
    usdt_enabled boolean DEFAULT true NOT NULL,
    payment_qr_enabled boolean DEFAULT true NOT NULL,
    sbp_enabled boolean DEFAULT true NOT NULL,
    phone_description text DEFAULT ''::text NOT NULL,
    usdt_description text DEFAULT ''::text NOT NULL,
    qr_description text DEFAULT ''::text NOT NULL,
    sbp_description text DEFAULT ''::text NOT NULL,
    updated_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT payment_settings_scoped_scope_check CHECK ((scope = ANY (ARRAY['TICKET'::text, 'TRANSFER'::text])))
);


ALTER TABLE public.payment_settings_scoped OWNER TO gigme;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    provider text NOT NULL,
    provider_payment_id text,
    amount bigint NOT NULL,
    status text NOT NULL,
    raw_response_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT payments_amount_check CHECK ((amount >= 0))
);


ALTER TABLE public.payments OWNER TO gigme;

--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.promo_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    discount_type text NOT NULL,
    value bigint NOT NULL,
    usage_limit integer,
    used_count integer DEFAULT 0 NOT NULL,
    active_from timestamp with time zone,
    active_to timestamp with time zone,
    event_id bigint,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT promo_codes_discount_type_check CHECK ((discount_type = ANY (ARRAY['PERCENT'::text, 'FIXED'::text]))),
    CONSTRAINT promo_codes_usage_limit_check CHECK ((usage_limit > 0)),
    CONSTRAINT promo_codes_value_check CHECK ((value >= 0))
);


ALTER TABLE public.promo_codes OWNER TO gigme;

--
-- Name: referral_claims; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.referral_claims (
    id bigint NOT NULL,
    referral_code_id bigint NOT NULL,
    event_id bigint NOT NULL,
    invitee_user_id bigint NOT NULL,
    inviter_user_id bigint NOT NULL,
    bonus_amount integer DEFAULT 100 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.referral_claims OWNER TO gigme;

--
-- Name: referral_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.referral_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referral_claims_id_seq OWNER TO gigme;

--
-- Name: referral_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.referral_claims_id_seq OWNED BY public.referral_claims.id;


--
-- Name: referral_codes; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.referral_codes (
    id bigint NOT NULL,
    code text NOT NULL,
    owner_user_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.referral_codes OWNER TO gigme;

--
-- Name: referral_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.referral_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.referral_codes_id_seq OWNER TO gigme;

--
-- Name: referral_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.referral_codes_id_seq OWNED BY public.referral_codes.id;


--
-- Name: sbp_qr; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.sbp_qr (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    qrc_id text NOT NULL,
    payload text NOT NULL,
    merchant_id text NOT NULL,
    account_id text NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.sbp_qr OWNER TO gigme;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO gigme;

--
-- Name: ticket_products; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.ticket_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id bigint NOT NULL,
    type text NOT NULL,
    price_cents bigint NOT NULL,
    inventory_limit integer,
    sold_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    CONSTRAINT ticket_products_inventory_limit_check CHECK ((inventory_limit > 0)),
    CONSTRAINT ticket_products_price_cents_check CHECK ((price_cents >= 0)),
    CONSTRAINT ticket_products_type_check CHECK ((type = ANY (ARRAY['SINGLE'::text, 'GROUP2'::text, 'GROUP10'::text])))
);


ALTER TABLE public.ticket_products OWNER TO gigme;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    user_id bigint NOT NULL,
    event_id bigint NOT NULL,
    ticket_type text NOT NULL,
    quantity integer NOT NULL,
    qr_payload text,
    qr_payload_hash text,
    qr_issued_at timestamp with time zone,
    redeemed_at timestamp with time zone,
    redeemed_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    qr_delivered_at timestamp with time zone,
    qr_delivery_error text,
    CONSTRAINT tickets_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT tickets_ticket_type_check CHECK ((ticket_type = ANY (ARRAY['SINGLE'::text, 'GROUP2'::text, 'GROUP10'::text, 'TRANSFER_THERE'::text, 'TRANSFER_BACK'::text, 'TRANSFER_ROUNDTRIP'::text])))
);


ALTER TABLE public.tickets OWNER TO gigme;

--
-- Name: transfer_products; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.transfer_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id bigint NOT NULL,
    direction text NOT NULL,
    price_cents bigint NOT NULL,
    info_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    inventory_limit integer,
    sold_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    CONSTRAINT transfer_products_direction_check CHECK ((direction = ANY (ARRAY['THERE'::text, 'BACK'::text, 'ROUNDTRIP'::text]))),
    CONSTRAINT transfer_products_inventory_limit_check CHECK ((inventory_limit > 0)),
    CONSTRAINT transfer_products_price_cents_check CHECK ((price_cents >= 0))
);


ALTER TABLE public.transfer_products OWNER TO gigme;

--
-- Name: user_contact_matches; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.user_contact_matches (
    user_id bigint NOT NULL,
    contact_user_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_contact_matches OWNER TO gigme;

--
-- Name: user_push_tokens; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.user_push_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    platform text NOT NULL,
    token text NOT NULL,
    device_id text,
    app_version text,
    locale text,
    is_active boolean DEFAULT true NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_push_tokens OWNER TO gigme;

--
-- Name: user_push_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.user_push_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_push_tokens_id_seq OWNER TO gigme;

--
-- Name: user_push_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.user_push_tokens_id_seq OWNED BY public.user_push_tokens.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: gigme
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    telegram_id bigint NOT NULL,
    username text,
    first_name text NOT NULL,
    last_name text,
    photo_url text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_location public.geography(Point,4326),
    last_seen_at timestamp with time zone,
    rating numeric(3,2) DEFAULT 0 NOT NULL,
    rating_count integer DEFAULT 0 NOT NULL,
    balance_tokens bigint DEFAULT 0 NOT NULL,
    is_blocked boolean DEFAULT false NOT NULL,
    blocked_reason text,
    blocked_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO gigme;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: gigme
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO gigme;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gigme
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_bot_messages id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_bot_messages ALTER COLUMN id SET DEFAULT nextval('public.admin_bot_messages_id_seq'::regclass);


--
-- Name: admin_broadcast_jobs id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcast_jobs ALTER COLUMN id SET DEFAULT nextval('public.admin_broadcast_jobs_id_seq'::regclass);


--
-- Name: admin_broadcasts id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcasts ALTER COLUMN id SET DEFAULT nextval('public.admin_broadcasts_id_seq'::regclass);


--
-- Name: admin_event_parser_events id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_events ALTER COLUMN id SET DEFAULT nextval('public.admin_event_parser_events_id_seq'::regclass);


--
-- Name: admin_event_parser_sources id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_sources ALTER COLUMN id SET DEFAULT nextval('public.admin_event_parser_sources_id_seq'::regclass);


--
-- Name: event_comments id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_comments ALTER COLUMN id SET DEFAULT nextval('public.event_comments_id_seq'::regclass);


--
-- Name: event_media id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_media ALTER COLUMN id SET DEFAULT nextval('public.event_media_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: notification_jobs id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.notification_jobs ALTER COLUMN id SET DEFAULT nextval('public.notification_jobs_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: referral_claims id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims ALTER COLUMN id SET DEFAULT nextval('public.referral_claims_id_seq'::regclass);


--
-- Name: referral_codes id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_codes ALTER COLUMN id SET DEFAULT nextval('public.referral_codes_id_seq'::regclass);


--
-- Name: user_push_tokens id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_push_tokens ALTER COLUMN id SET DEFAULT nextval('public.user_push_tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admin_bot_messages; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.admin_bot_messages (id, chat_id, direction, message_text, telegram_message_id, sender_telegram_id, sender_username, sender_first_name, sender_last_name, admin_telegram_id, created_at) FROM stdin;
1	476021753	INCOMING	dbznzbzbznzzb	1882	476021753	ggEff	Egor	Galaev	\N	2026-02-19 11:30:07.031991+00
2	476021753	OUTGOING	dhxbxnxznxnzn	\N	\N	\N	\N	\N	653848276	2026-02-19 11:30:35.585246+00
3	476021753	OUTGOING	привет	\N	\N	\N	\N	\N	653848276	2026-02-19 11:35:53.905504+00
4	587997508	INCOMING	/start	1894	587997508	Vvoyager747	V	K	\N	2026-02-19 12:02:23.963414+00
5	587997508	INCOMING	[unsupported message]	1897	587997508	Vvoyager747	V	K	\N	2026-02-19 12:02:33.947307+00
6	162477653	INCOMING	/start	1898	162477653	SeregaCamp4rest	Sergei Shabalin	\N	\N	2026-02-19 12:16:40.162335+00
7	476021753	INCOMING	привер	1907	476021753	ggEff	Egor	Galaev	\N	2026-02-19 12:58:54.70992+00
8	476021753	OUTGOING	лол	\N	\N	\N	\N	\N	653848276	2026-02-19 12:59:24.16138+00
9	476021753	OUTGOING	пидор	\N	\N	\N	\N	\N	653848276	2026-02-19 18:00:46.998913+00
10	321771876	INCOMING	При покупке билета не указала фамилию и имя .	2012	321771876	NataliaOhdooddi	Natalia	\N	\N	2026-02-19 20:36:02.090208+00
11	321771876	INCOMING	Не страшно же?)	2013	321771876	NataliaOhdooddi	Natalia	\N	\N	2026-02-19 20:36:03.318951+00
12	321771876	OUTGOING	Фио не обязательно , вы один билет в итоге оплатили ?	\N	\N	\N	\N	\N	653848276	2026-02-19 20:58:40.854173+00
13	321771876	INCOMING	Да	2020	321771876	NataliaOhdooddi	Natalia	\N	\N	2026-02-20 04:04:48.321963+00
14	1368670953	INCOMING	[unsupported message]	2023	1368670953	Don_digid0n	Don	Digidon	\N	2026-02-20 10:38:52.056857+00
15	476021753	INCOMING	https://sora.chatgpt.com/p/s_69986061ed4081918f83812b8073ffb6?psh=HXVzZXItWXBOV3B6eFBCNUtMUm1rTnhoSmdEb0d0.nnNHRJdpcGjJ	2030	476021753	ggEff	Egor	Galaev	\N	2026-02-20 13:25:42.688689+00
16	476021753	INCOMING	https://sora.chatgpt.com/p/s_699863324a6c819198c70e95eeea289f?psh=HXVzZXItWXBOV3B6eFBCNUtMUm1rTnhoSmdEb0d0.SiMHBLEKmLwR	2032	476021753	ggEff	Egor	Galaev	\N	2026-02-20 13:36:17.080214+00
17	1368670953	OUTGOING	Добрый день от кого платеж был?	\N	\N	\N	\N	\N	653848276	2026-02-20 14:03:52.933707+00
18	307059155	OUTGOING	Добрый день от кого вы платеж совершали?	\N	\N	\N	\N	\N	653848276	2026-02-20 14:04:26.420565+00
19	1368670953	INCOMING	Добрый день! от меня сегодня	2042	1368670953	Don_digid0n	Don	Digidon	\N	2026-02-20 14:19:58.403254+00
20	1368670953	INCOMING	второй билет взял	2044	1368670953	Don_digid0n	Don	Digidon	\N	2026-02-20 14:20:12.639467+00
21	399445929	INCOMING	/start	2052	399445929	drkdna	Gerrie	van Boven	\N	2026-02-20 21:27:53.795584+00
22	146648183	INCOMING	/start	2060	146648183	Oeric1984	Oeric	\N	\N	2026-02-20 22:01:15.709148+00
23	146648183	INCOMING	[unsupported message]	2063	146648183	Oeric1984	Oeric	\N	\N	2026-02-20 22:03:33.609131+00
24	7278558794	INCOMING	[unsupported message]	2067	7278558794	\N	Billy Milligan	\N	\N	2026-02-20 23:06:45.027388+00
25	438513291	INCOMING	[unsupported message]	2068	438513291	tatadadan	tatadadan	\N	\N	2026-02-21 02:01:33.772107+00
26	300226937	INCOMING	[unsupported message]	2069	300226937	Sammoise	Samwise	Gamgee	\N	2026-02-21 06:50:17.594515+00
27	222083638	INCOMING	/start	2070	222083638	stiiiiilllllll	Димитрий	\N	\N	2026-02-21 07:18:27.79088+00
28	165003638	INCOMING	Stop	2154	165003638	makkesev	Игорь	Бриз	\N	2026-02-21 11:31:55.377024+00
29	902324493	INCOMING	/start	2260	902324493	HeresCo	Access	Service	\N	2026-02-21 12:40:25.588203+00
30	902324493	INCOMING	/start	2263	902324493	HeresCo	Access	Service	\N	2026-02-21 12:41:18.328092+00
31	476021753	INCOMING	/start	2266	476021753	ggEff	Egor	Galaev	\N	2026-02-21 13:00:57.885822+00
32	1007530620	INCOMING	[unsupported message]	2364	1007530620	K_Plotnikoff	K.	Plotnikoff	\N	2026-02-21 17:13:51.806917+00
33	1856273861	INCOMING	[unsupported message]	2369	1856273861	Dj_Fuckir	Юрий Симанов	Dj Fuckir	\N	2026-02-21 20:19:59.374403+00
34	1031329904	INCOMING	[unsupported message]	2612	1031329904	RASSSSSSSSSSSSSUL	Расул	\N	\N	2026-02-23 05:10:31.770119+00
35	807646088	INCOMING	[unsupported message]	2613	807646088	PavlovAlexeyDCM	А	\N	\N	2026-02-23 13:32:50.845107+00
36	966311493	INCOMING	[unsupported message]	2614	966311493	Psyxoz25	Александр	\N	\N	2026-02-24 04:44:51.572133+00
37	307059155	INCOMING	[unsupported message]	2615	307059155	naste_mir	Настя	\N	\N	2026-02-25 07:55:18.376203+00
38	307059155	INCOMING	Хочу купить билнт на space	2616	307059155	naste_mir	Настя	\N	\N	2026-02-25 07:55:18.675231+00
39	307059155	INCOMING	Ау	2617	307059155	naste_mir	Настя	\N	\N	2026-02-25 07:55:19.106822+00
40	307059155	INCOMING	[unsupported message]	2618	307059155	naste_mir	Настя	\N	\N	2026-02-25 07:55:19.622714+00
41	307059155	OUTGOING	Привет, сервер перезапускали , теперь все равотает в штатном режиме	\N	\N	\N	\N	\N	653848276	2026-02-25 07:56:06.349725+00
42	307059155	OUTGOING	Если будут вопросы пишите сюда , поможем	\N	\N	\N	\N	\N	653848276	2026-02-25 07:58:33.851243+00
43	966311493	OUTGOING	бот перезапушен , приложение работает в штатном порядке	\N	\N	\N	\N	\N	653848276	2026-02-25 08:05:16.708482+00
44	807646088	OUTGOING	Бот перезапушен после тех работ	\N	\N	\N	\N	\N	653848276	2026-02-25 08:05:51.597963+00
45	1031329904	OUTGOING	Бот перезапушен, билеты доступны для продажи	\N	\N	\N	\N	\N	653848276	2026-02-25 08:06:20.849807+00
46	476021753	INCOMING	/start	2694	476021753	ggEff	Egor	Galaev	\N	2026-02-25 08:13:10.133959+00
47	476021753	INCOMING	Пизда сковорода	2699	476021753	ggEff	Egor	Galaev	\N	2026-02-25 08:13:20.836421+00
48	476021753	OUTGOING	хуй	\N	\N	\N	\N	\N	653848276	2026-02-25 08:13:37.859283+00
49	307059155	OUTGOING	Вижу у вас еше один заказ ? На какой номер второй переводили?	\N	\N	\N	\N	\N	653848276	2026-02-25 11:08:38.940822+00
50	307059155	INCOMING	не переводила	2743	307059155	naste_mir	Настя	\N	\N	2026-02-25 13:36:01.178707+00
51	714260951	INCOMING	[unsupported message]	2748	714260951	julia_lukashina	Julia	\N	\N	2026-02-25 17:24:18.811487+00
52	307059155	OUTGOING	https://t.me/space4rest	\N	\N	\N	\N	\N	653848276	2026-02-26 18:41:26.597999+00
53	7575255339	INCOMING	[unsupported message]	2755	7575255339	hitechpower88	🍄	\N	\N	2026-02-27 13:41:57.344112+00
54	7575255339	INCOMING	Добрый день , билет купил в подарок	2756	7575255339	hitechpower88	🍄	\N	\N	2026-02-27 13:42:07.33064+00
55	7575255339	OUTGOING	Замечательное решение! qr коды выслали	\N	\N	\N	\N	\N	653848276	2026-02-27 14:40:13.16449+00
56	7575255339	INCOMING	[unsupported message]	2765	7575255339	hitechpower88	🍄	\N	\N	2026-02-27 17:24:10.67414+00
57	7575255339	INCOMING	Еще один , уже себе:)	2766	7575255339	hitechpower88	🍄	\N	\N	2026-02-27 17:24:35.892907+00
58	7575255339	INCOMING	Спасибо большое :)	2772	7575255339	hitechpower88	🍄	\N	\N	2026-02-27 17:33:36.603912+00
59	7575255339	OUTGOING	Вам Спасибо , до встречи на SPACE!	\N	\N	\N	\N	\N	653848276	2026-02-27 17:34:16.028566+00
60	312453330	INCOMING	/start	2778	312453330	Siropov	Sirop	\N	\N	2026-02-28 11:44:57.409932+00
61	337821005	INCOMING	/start	2784	337821005	Alexandr_Shapovalov	Alex	Shapovalov	\N	2026-02-28 17:09:28.099935+00
62	337821005	INCOMING	[unsupported message]	2788	337821005	Alexandr_Shapovalov	Alex	Shapovalov	\N	2026-02-28 17:22:04.447259+00
63	337821005	OUTGOING	Как проверим платеж, билет появится в чате этом и в вашем личном кабинете, Спасибо , до встречи на SPACE	\N	\N	\N	\N	\N	653848276	2026-02-28 18:43:45.697918+00
64	162990073	INCOMING	/start	2794	162990073	Jul_Veselova	Julia	\N	\N	2026-03-01 10:21:55.781703+00
65	476021753	INCOMING	/start	2801	476021753	ggEff	Egor	Galaev	\N	2026-03-01 20:23:43.189593+00
66	863966	INCOMING	/start	2804	863966	Batonrain	Eugen	Batishchev	\N	2026-03-02 07:09:20.035144+00
67	337821005	INCOMING	Проверили ?	2807	337821005	Alexandr_Shapovalov	Alex	Shapovalov	\N	2026-03-02 09:30:28.850068+00
68	337821005	OUTGOING	Ответил вам лс	\N	\N	\N	\N	\N	653848276	2026-03-02 09:31:46.624604+00
69	1872754876	INCOMING	[unsupported message]	2829	1872754876	Annplants1	АnnPlants	\N	\N	2026-03-03 16:51:41.286795+00
70	77785271	INCOMING	/start	2831	77785271	Alova_Snezhana	Алова	Снежана	\N	2026-03-04 09:36:02.261038+00
71	1115067915	INCOMING	/start	2830	1115067915	warriatski	Варя	\N	\N	2026-03-04 09:36:09.523239+00
72	77785271	OUTGOING	Бот запушен после технических работ!	\N	\N	\N	\N	\N	653848276	2026-03-04 09:37:06.561494+00
73	1115067915	OUTGOING	Бот запущен после технических работ	\N	\N	\N	\N	\N	653848276	2026-03-04 09:37:38.903919+00
74	6449701987	INCOMING	供应商品：飞机号  TG号  会员号\n🇺🇸 +1 美国       🇨🇦 +1 加拿大\n🇨🇱 +56 智利          🇮🇩+62-印尼 \n🇧🇷 +55 巴西          🇭🇰+852-香港\n🇮🇳+91-印度          🇦🇷 +54 阿根廷\n🇹🇷+90土耳其       🇻🇳 +84 越南 \n🇬🇧+44~英国         🇲🇲+95缅甸\n🇰🇭+855~柬埔寨   🇳🇵 +977 尼泊尔\n🇵🇹+351-葡萄牙    🇪🇸 +34 西班牙\n🇱🇻+371-拉脱维亚🇯🇵+81-日本\n🇸🇦 +966 沙特阿拉伯🇺🇿+998-乌兹别克斯坦\n🇦🇫+93-阿富汗      🇨🇿 +420-捷克\n🇸🇻+503-萨尔瓦多 🇩🇴 +1829 多米尼加共和国\n🇺🇸+1-美国实卡    🇨🇦+1-加拿大实卡\n\n🦐新号老号二次号出售价格透明不割韭菜\n（招代理）\n（招代理）\n24小时自助取号  @ackeji7_bot\n📣补货通知群： @ackeji8	2844	6449701987	\N	Rajputana	Amit 🚩	\N	2026-03-04 17:50:49.412358+00
75	6449701987	OUTGOING	WHATAFA?	\N	\N	\N	\N	\N	653848276	2026-03-04 17:51:37.084232+00
76	825731816	INCOMING	[unsupported message]	2850	825731816	Dariya_Potapkina	Daria	Potapkina	\N	2026-03-04 20:19:58.289695+00
77	56209897	INCOMING	/start	2853	56209897	Vet_Sychmann	@Vet	\N	\N	2026-03-04 23:21:25.665962+00
78	56209897	INCOMING	[unsupported message]	2856	56209897	Vet_Sychmann	@Vet	\N	\N	2026-03-04 23:23:04.87201+00
79	321237203	INCOMING	/start	2863	321237203	irakotina	Ира	Котина	\N	2026-03-05 17:11:54.785053+00
80	342308291	INCOMING	[unsupported message]	2866	342308291	AndreasRadomirus	Andreas	Sandals	\N	2026-03-05 20:19:52.613497+00
81	8038318279	INCOMING	/start	2867	8038318279	PipindraJo	Гоу	СосаЦа	\N	2026-03-06 06:30:37.716843+00
82	56423163	INCOMING	[unsupported message]	2870	56423163	DikobRaZo	Семён	\N	\N	2026-03-06 09:42:59.077975+00
83	780600864	INCOMING	[unsupported message]	2873	780600864	nazaregolosazovytmenya	sekira♡	\N	\N	2026-03-06 16:09:13.089888+00
84	669730541	INCOMING	[unsupported message]	2874	669730541	Musta_ryssa	Musta	Ryssä	\N	2026-03-06 16:18:23.885445+00
85	49675314	INCOMING	[unsupported message]	2879	49675314	ice_steel	Stem	\N	\N	2026-03-06 17:05:18.245797+00
86	503726802	INCOMING	[unsupported message]	2880	503726802	Kalashnikovaolka	Олька Калашникова	\N	\N	2026-03-06 17:26:57.021731+00
87	300226937	INCOMING	[unsupported message]	2882	300226937	Sammoise	Samwise	Gamgee	\N	2026-03-06 17:57:26.821851+00
88	1119662352	INCOMING	[unsupported message]	2885	1119662352	Spearman1988	артем	ерошин	\N	2026-03-06 18:51:39.885839+00
89	891487411	INCOMING	[unsupported message]	2886	891487411	Whazzupslav	Whatsupslav	Ozhek	\N	2026-03-06 19:04:54.383099+00
90	281767113	INCOMING	[unsupported message]	2887	281767113	Konstantin_inneralchemy	Konstantin	\N	\N	2026-03-06 19:49:12.269375+00
91	120951245	INCOMING	[unsupported message]	2888	120951245	nastasi9i	Anastasiia	\N	\N	2026-03-06 20:55:49.492566+00
92	6029678333	INCOMING	🎉全球TG直登号 协议号批发\n\n🤖取号机器人： @ACkeji6_bot	2889	6029678333	\N	Rahul	Silora	\N	2026-03-07 05:06:45.52197+00
93	76441919	INCOMING	[unsupported message]	2891	76441919	EDarkside	E	R	\N	2026-03-07 05:44:29.508182+00
94	778338820	INCOMING	[unsupported message]	2894	778338820	DCP_PRODuction	Lev	\N	\N	2026-03-07 06:23:06.724291+00
95	329927503	INCOMING	[unsupported message]	2896	329927503	masoqutter	Pavel	Masoqutter	\N	2026-03-07 07:46:37.290377+00
96	309011426	INCOMING	[unsupported message]	2897	309011426	Andastral	And	Bushuev	\N	2026-03-07 08:02:20.413565+00
97	356972906	INCOMING	[unsupported message]	2903	356972906	bjuice25	Иван	\N	\N	2026-03-07 09:26:40.230579+00
98	1560672668	INCOMING	/start	2905	1560672668	Pyryrympympym	ꪖꪀꪀꪊᦓꫝᛕꪖ	\N	\N	2026-03-07 11:32:17.902048+00
99	1560672668	INCOMING	[unsupported message]	2908	1560672668	Pyryrympympym	ꪖꪀꪀꪊᦓꫝᛕꪖ	\N	\N	2026-03-07 11:32:35.127169+00
100	310513187	INCOMING	/start	2911	310513187	Di_maa89	Di	Ma	\N	2026-03-07 14:00:34.849171+00
101	518229679	INCOMING	[unsupported message]	2914	518229679	konstantin_kykaracha	Konstantin	Kykaracha	\N	2026-03-07 14:54:15.921867+00
102	1262024979	INCOMING	[unsupported message]	2915	1262024979	seashell_SG	Seashell	\N	\N	2026-03-07 15:09:34.80266+00
103	846273533	INCOMING	[unsupported message]	2916	846273533	ZverEdition	Neva	\N	\N	2026-03-07 16:12:56.770192+00
104	310513187	INCOMING	[unsupported message]	2918	310513187	Di_maa89	Di	Ma	\N	2026-03-07 16:22:56.745347+00
105	1373951270	INCOMING	/start	2923	1373951270	yaminawa	Katherine 🦇	\N	\N	2026-03-08 06:34:58.369951+00
106	1373951270	INCOMING	[unsupported message]	2927	1373951270	yaminawa	Katherine 🦇	\N	\N	2026-03-08 06:38:29.361671+00
107	356972906	INCOMING	[unsupported message]	2936	356972906	bjuice25	Иван	\N	\N	2026-03-08 16:59:44.193911+00
108	286115324	INCOMING	/start	2938	286115324	Mushroom_Foxy	Mushroom	Foxy	\N	2026-03-08 17:22:39.104569+00
109	286115324	INCOMING	[unsupported message]	2942	286115324	Mushroom_Foxy	Mushroom	Foxy	\N	2026-03-08 18:28:51.866446+00
110	794451988	INCOMING	[unsupported message]	2943	794451988	izzalesaizzagor	izzalesaizzagor	\N	\N	2026-03-08 19:43:38.19997+00
111	146777480	INCOMING	/start	2945	146777480	GambRa_dj	Денис	М	\N	2026-03-08 20:48:16.527623+00
112	996248287	INCOMING	[unsupported message]	2948	996248287	golosvechnosty	Konstantin	\N	\N	2026-03-09 07:48:08.272564+00
113	1601153707	INCOMING	/start	2950	1601153707	nezadano_net	Anna. 💚	Kola 🍀	\N	2026-03-09 10:14:04.152372+00
114	136485518	INCOMING	[unsupported message]	2961	136485518	baby_kills_bambi	Olga	A.	\N	2026-03-10 11:12:46.245719+00
115	323701675	INCOMING	[unsupported message]	2962	323701675	Nostromo_2122	m.	Warsaw	\N	2026-03-13 11:06:16.08689+00
116	290081780	INCOMING	/start	2963	290081780	pavelmagpie	Pavel	Sorokin	\N	2026-03-14 08:25:34.589122+00
117	270661678	INCOMING	[unsupported message]	2966	270661678	iTonyJah	Anton	Mr.Was	\N	2026-03-14 09:37:34.751088+00
118	270661678	INCOMING	[unsupported message]	2968	270661678	iTonyJah	Anton	Mr.Was	\N	2026-03-14 09:41:02.014802+00
119	7768785162	INCOMING	一手机房大量出售+1 +54 +57 +44 +55  +62 +84 +993 +998  tg 直登协议号  冰点价格\n主页tg自助机器人  @tiansession	2970	7768785162	\N	Sakkaravarthi	Sivavishnu	\N	2026-03-15 11:28:11.115756+00
120	530422330	INCOMING	[unsupported message]	2971	530422330	Kristina_Vtornik	Кристина	Vtornik	\N	2026-03-15 14:57:38.412595+00
121	103520300	INCOMING	/start	2972	103520300	psyservice	::psyservice::	\N	\N	2026-03-19 07:15:00.630118+00
122	7107490469	INCOMING	[unsupported message]	2975	7107490469	\N	Warrior	Tilda	\N	2026-03-20 03:11:53.307065+00
123	254603892	INCOMING	[unsupported message]	2976	254603892	maxim_klinkov	Maxim	Klinkov	\N	2026-03-23 06:33:35.697738+00
124	1380528668	INCOMING	[unsupported message]	2981	1380528668	Alexandergypsy	ALEXANDER	\N	\N	2026-03-23 20:46:18.322272+00
125	1	INCOMING	[unsupported message]	1	1	\N	Test	\N	\N	2026-04-28 16:02:16.177302+00
126	1	INCOMING	[unsupported message]	1	1	\N	Test	\N	\N	2026-04-28 16:02:30.983921+00
127	1	INCOMING	/start	2	1	\N	Test	\N	\N	2026-04-28 16:02:44.223723+00
128	5807833884	INCOMING	/start	3868	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:43.704818+00
129	5807833884	INCOMING	买世界杯来意昂体育	3869	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.028017+00
130	5807833884	INCOMING	体育电子棋牌彩票真人	3870	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.140005+00
131	5807833884	INCOMING	不计输赢日反水1.1%	3871	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.24646+00
132	5807833884	INCOMING	亏损返还15%到30%	3872	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.355963+00
133	5807833884	INCOMING	福利频道 @K5115	3873	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.46975+00
134	5807833884	INCOMING	阁主本人 @XXCC	3874	5807833884	vngtqpj6ez	Khushali	\N	\N	2026-06-29 09:15:44.570748+00
135	989974215	INCOMING	/start	3881	989974215	Polyashkam	Полина	Летучева	\N	2026-06-29 09:15:44.672553+00
136	735013400	INCOMING	/start	3882	735013400	valteRRsas	🥵💔	\N	\N	2026-06-29 09:15:44.872948+00
137	448820020	INCOMING	/start	3883	448820020	Auzlee	Auzlee	\N	\N	2026-06-29 09:15:45.074465+00
138	465046556	INCOMING	[unsupported message]	3884	465046556	EasyEsther	Esther	\N	\N	2026-06-29 09:15:45.272433+00
139	1187694359	INCOMING	[unsupported message]	3886	1187694359	galaumerenkova	Галина	Умеренкова	\N	2026-06-29 09:15:45.276772+00
140	1030962280	INCOMING	/start	3887	1030962280	\N	Ыыы	\N	\N	2026-06-29 09:15:45.283096+00
141	1978259843	INCOMING	/start	3891	1978259843	\N	Владимир	Bob	\N	2026-06-29 09:15:45.566651+00
142	458893487	INCOMING	/start	3892	458893487	kriss_68_rus	Кристина	Гульева	\N	2026-06-29 09:15:45.76519+00
143	142988617	INCOMING	/start	3893	142988617	zenkrat	Zenkratov	\N	\N	2026-06-29 09:15:45.987855+00
144	513732504	INCOMING	/start	3894	513732504	Evgesha_604	April cat	\N	\N	2026-06-29 09:15:46.2898+00
145	513732504	INCOMING	[unsupported message]	3896	513732504	Evgesha_604	April cat	\N	\N	2026-06-29 09:15:46.579341+00
146	476021753	INCOMING	привет	3923	476021753	ggEff	Egor	Galaev	\N	2026-06-29 09:40:50.765862+00
147	476021753	OUTGOING	привет	\N	\N	\N	\N	\N	653848276	2026-06-29 09:41:12.483228+00
148	81614209	INCOMING	/start	3926	81614209	oDislaff	oDislaff	\N	\N	2026-06-29 10:31:40.569683+00
149	81614209	OUTGOING	СПЕЦИАЛЬНОЕ ПРЕДЛОЖЕНИЕ ДЛЯ КОМПАНИЙ 10 чел за 60000!	\N	\N	\N	\N	\N	653848276	2026-06-29 10:34:01.980994+00
150	133407627	INCOMING	/start	3933	133407627	sad_mercury	Alexey	Filippov	\N	2026-06-29 11:24:25.189824+00
151	133407627	OUTGOING	СПЕЦИАЛЬНОЕ ПРЕДЛОЖЕНИЕ ДЛЯ КОМПАНИЙ 10 чел за 60000!	\N	\N	\N	\N	\N	653848276	2026-06-29 11:27:13.982461+00
152	546657879	INCOMING	[unsupported message]	3937	546657879	stanislavfedorchuk	Stanislav	\N	\N	2026-06-29 12:14:52.734095+00
153	1214070866	INCOMING	/start	3938	1214070866	iluha5315	El	\N	\N	2026-06-29 13:17:29.37908+00
154	177900395	INCOMING	/start	3941	177900395	rodriguez_sbg	Rodion	Rodriguez	\N	2026-06-29 13:20:04.045288+00
155	1659954889	INCOMING	[unsupported message]	3944	1659954889	AnzhelaWs	AnzhelaWs	\N	\N	2026-06-29 16:37:26.415727+00
156	1054702841	INCOMING	/start	3945	1054702841	Anastasiaa2728	Анастасия	\N	\N	2026-06-29 17:25:04.233163+00
157	479244500	INCOMING	/start	3948	479244500	klean88	Каляка	Klein	\N	2026-06-30 05:10:57.40215+00
158	8063688141	INCOMING	/start	3951	8063688141	Mrakto	Hanzik	\N	\N	2026-06-30 05:44:51.148706+00
159	430935922	INCOMING	[unsupported message]	3955	430935922	tevortho	Екатерина	\N	\N	2026-06-30 09:14:17.458304+00
160	430935922	INCOMING	[unsupported message]	3958	430935922	tevortho	Екатерина	\N	\N	2026-06-30 09:14:38.31646+00
161	1958754600	INCOMING	/start	3964	1958754600	Thesamurai666	Mark	Alexsandrowitch	\N	2026-06-30 14:29:21.730365+00
162	8577781893	INCOMING	[unsupported message]	3967	8577781893	ultio_contesto	John	Dow	\N	2026-06-30 14:29:41.707057+00
163	705880150	INCOMING	[unsupported message]	3972	705880150	PolIgorya	Pol	Igorya	\N	2026-06-30 15:47:49.652211+00
164	222088473	INCOMING	/start	3973	222088473	lalinok_li	Li	\N	\N	2026-06-30 19:19:42.553835+00
165	520208648	INCOMING	/start	3976	520208648	\N	Mr.	Hedgehog	\N	2026-06-30 20:46:23.641778+00
166	1278765183	INCOMING	/start	3979	1278765183	mfriida	Farida 🦋	\N	\N	2026-07-01 06:37:53.614163+00
167	388060547	INCOMING	[unsupported message]	3983	388060547	Bushemi13	Vitaly Bushemi	\N	\N	2026-07-01 07:46:21.652196+00
168	388060547	INCOMING	[unsupported message]	3988	388060547	Bushemi13	Vitaly Bushemi	\N	\N	2026-07-01 07:49:02.224691+00
169	388060547	INCOMING	[unsupported message]	3991	388060547	Bushemi13	Vitaly Bushemi	\N	\N	2026-07-01 07:51:43.61721+00
170	689377563	INCOMING	/start	3994	689377563	FFadeeVV	Александр.😉	\N	\N	2026-07-01 07:57:43.48192+00
171	1695671884	INCOMING	/start	4000	1695671884	SilentShrine	A	R1Play	\N	2026-07-01 10:23:16.066207+00
172	81650381	INCOMING	/start	4003	81650381	hodislav	Слава	\N	\N	2026-07-01 14:34:27.483422+00
173	1980232238	INCOMING	Start	4006	1980232238	omnia_floont	omnia_floont	\N	\N	2026-07-01 17:15:38.422452+00
174	1518204487	INCOMING	[unsupported message]	4008	1518204487	Alex_Grilanse	Alex	Grilanse	\N	2026-07-01 18:33:24.245386+00
175	5042942435	INCOMING	[unsupported message]	4009	5042942435	YanPivCof	𝕐𝕒𝕟 ♪	कॉफ़ीवबीर	\N	2026-07-01 18:46:42.311262+00
176	175185867	INCOMING	[unsupported message]	4010	175185867	denchik_dizzya	Denchik	Dizzya	\N	2026-07-01 18:53:49.775627+00
179	1296832351	INCOMING	/start	4015	1296832351	LLLCCCRAZ	Ivan.O	\N	\N	2026-07-01 19:25:14.095429+00
180	471200455	INCOMING	[unsupported message]	4018	471200455	azrax81	Алексей	\N	\N	2026-07-01 19:44:37.881685+00
177	6210727148	INCOMING	[unsupported message]	4011	6210727148	Finallynormalpeople	Евгений	\N	\N	2026-07-01 18:56:01.176656+00
178	955043848	INCOMING	/start	4012	955043848	kosyrevala	Любовь	Косырева	\N	2026-07-01 19:20:29.187564+00
181	40810031	INCOMING	[unsupported message]	4020	40810031	nord1dea	Nikolay	Antonets	\N	2026-07-01 20:26:46.152077+00
182	1512497258	INCOMING	/start	4023	1512497258	Riba_nozh	Сергей	Киселев	\N	2026-07-02 01:06:12.760577+00
183	1241769461	INCOMING	/start	4026	1241769461	lesovoyy	Илья Лесовой	\N	\N	2026-07-02 06:42:05.807338+00
184	5972551518	INCOMING	[unsupported message]	4029	5972551518	Fedoryagov	Ягов	Фёдор	\N	2026-07-02 07:13:13.701636+00
185	902640946	INCOMING	[unsupported message]	4030	902640946	Lasos777	Ласось💩	\N	\N	2026-07-02 08:23:10.79794+00
186	1253945817	INCOMING	/start	4031	1253945817	Mi_r_u_mi_r	Миру Мир!	\N	\N	2026-07-02 09:50:22.373665+00
187	437202248	INCOMING	/start	4035	437202248	Usinstudio888	Екатерина НАТУРАЛЬНЫЕ Камни Браслеты Usinstudio.ru	\N	\N	2026-07-02 10:26:41.138304+00
188	1115446705	INCOMING	[unsupported message]	4038	1115446705	Kirill_Va	Кирилл🦕	\N	\N	2026-07-02 11:25:18.828902+00
189	352684960	INCOMING	/start	4039	352684960	santovva	Anton	Santowa	\N	2026-07-02 12:53:42.99485+00
190	375375596	INCOMING	/start	4042	375375596	Regwoman	Reg	Woman🌙	\N	2026-07-02 14:51:35.799377+00
191	528560758	INCOMING	/start	4045	528560758	ilya_sun	Илья	\N	\N	2026-07-02 17:45:16.857657+00
192	6415872464	INCOMING	[unsupported message]	4048	6415872464	white_banshi	White	Banshi	\N	2026-07-02 17:53:38.385652+00
\.


--
-- Data for Name: admin_broadcast_jobs; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.admin_broadcast_jobs (id, broadcast_id, target_user_id, status, attempts, last_error, created_at, updated_at) FROM stdin;
9	4	323	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:13.509276+00
12	4	179	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:25.834111+00
17	4	47	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:40.360371+00
22	4	9	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:54.116609+00
28	4	7	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:07.360977+00
152	4	399	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:06.881372+00
153	4	412	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:11.357519+00
154	4	350	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:11.733086+00
155	4	387	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:12.705004+00
156	4	1	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:13.245074+00
157	4	541	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:17.622527+00
158	4	133	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:17.73885+00
159	4	254	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:18.433053+00
186	5	132	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:35.375224+00
191	5	192	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:46.075519+00
195	5	137	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:56.24405+00
200	5	212	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.374373+00
205	5	728	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:10.38626+00
257	5	309	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:21.050947+00
309	5	357	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:22.31815+00
266	5	292	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:34.815117+00
267	5	293	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:38.170437+00
268	5	294	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:38.430409+00
270	5	377	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:45.170288+00
271	5	650	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:48.494127+00
272	5	329	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:48.630332+00
274	5	66	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.096032+00
275	5	255	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.241075+00
276	5	574	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.356797+00
277	5	892	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.476094+00
278	5	485	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.62262+00
279	5	532	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.780608+00
114	4	335	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:07.317122+00
115	4	404	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:07.964681+00
116	4	532	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:12.009527+00
117	4	337	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:16.12904+00
118	4	549	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:20.120863+00
119	4	382	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:20.512829+00
120	4	214	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:21.628927+00
121	4	386	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:21.726912+00
122	4	358	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:21.821979+00
123	4	349	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:26.129113+00
124	4	336	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:26.206429+00
125	4	340	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:26.588655+00
126	4	479	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:26.96877+00
127	4	334	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:27.48487+00
128	4	485	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:28.508966+00
129	4	344	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:32.214304+00
130	4	368	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:32.632459+00
131	4	380	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:32.919658+00
132	4	355	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:33.18971+00
133	4	389	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:33.271584+00
134	4	365	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:37.300999+00
135	4	199	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:37.884939+00
136	4	269	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:38.396975+00
137	4	346	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:42.64919+00
138	4	3	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:42.761238+00
139	4	308	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:42.911977+00
140	4	357	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:47.273205+00
141	4	360	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:47.712778+00
142	4	361	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:48.188842+00
143	4	552	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:48.334845+00
144	4	576	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:48.764954+00
145	4	2	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:48.839184+00
146	4	341	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:49.137889+00
147	4	379	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:54.753045+00
148	4	237	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:55.202403+00
149	4	369	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:59.004747+00
150	4	582	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:59.090405+00
151	4	383	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:14:01.40927+00
280	5	951	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:52.898095+00
281	5	549	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:56.289915+00
282	5	382	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:56.447676+00
283	5	214	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:56.563846+00
284	5	386	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:56.689656+00
160	5	231	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:33.667981+00
161	5	56	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:36.962935+00
162	5	256	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:37.079858+00
163	5	374	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:40.367757+00
164	5	473	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:43.67943+00
165	5	782	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:43.815791+00
166	5	697	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:47.104128+00
167	5	548	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:47.213591+00
5	4	473	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:05.627047+00
6	4	474	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:05.727694+00
7	4	61	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:09.062308+00
215	5	233	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:21.698272+00
219	5	226	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:32.713526+00
226	5	244	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:43.615935+00
230	5	250	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:53.813839+00
235	5	300	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:04.494919+00
245	5	765	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:12.480733+00
306	5	346	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:15.491884+00
307	5	703	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:15.617963+00
308	5	625	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:18.95098+00
310	5	360	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:22.446704+00
311	5	633	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:25.81435+00
312	5	611	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:25.984407+00
313	5	361	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.181027+00
314	5	587	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.324106+00
315	5	399	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.439402+00
316	5	674	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.547092+00
317	5	552	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.682389+00
318	5	576	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:26.826451+00
437	5	864	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:31.539138+00
295	5	380	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:07.739882+00
296	5	730	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:07.86067+00
297	5	355	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:07.989171+00
8	4	548	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:09.145646+00
10	4	178	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:18.492658+00
11	4	8	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:22.036981+00
13	4	51	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:30.725317+00
298	5	199	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:08.13635+00
299	5	815	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:08.267378+00
101	4	322	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:22.877037+00
102	4	292	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:27.131835+00
301	5	389	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:11.702669+00
302	5	340	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:11.831478+00
303	5	138	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:11.943236+00
304	5	269	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:12.051128+00
305	5	48	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:12.184038+00
319	5	238	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:27.042021+00
320	5	379	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:30.664481+00
321	5	210	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:30.918043+00
322	5	308	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:31.106639+00
323	5	766	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:31.246156+00
324	5	237	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:31.367982+00
325	5	369	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:34.941425+00
326	5	582	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:35.208027+00
327	5	754	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:35.479847+00
328	5	636	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:35.798976+00
329	5	383	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:35.960058+00
330	5	350	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:36.172834+00
331	5	387	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:36.338468+00
332	5	654	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:36.440028+00
334	5	341	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:43.005407+00
335	5	133	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:43.15546+00
336	5	254	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:43.266891+00
337	5	659	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:46.585329+00
338	5	660	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:46.703749+00
339	5	829	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:46.843718+00
340	5	676	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:46.950489+00
341	5	831	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:47.067754+00
1	4	231	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:08:52.295358+00
2	4	56	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:08:57.568604+00
3	4	256	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:08:57.730928+00
4	4	374	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:01.692907+00
14	4	315	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:31.588831+00
15	4	573	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:35.980863+00
16	4	145	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:36.47295+00
18	4	134	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:40.906894+00
19	4	180	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:44.884856+00
20	4	204	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:45.308733+00
21	4	187	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:50.172922+00
23	4	188	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:57.545152+00
24	4	124	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:09:57.852696+00
25	4	132	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:01.405119+00
26	4	65	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:01.981066+00
27	4	190	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:02.200569+00
29	4	191	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:10.925246+00
30	4	192	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:18.081172+00
32	4	58	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:23.325016+00
33	4	43	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:28.513195+00
34	4	198	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:32.197052+00
342	5	731	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:47.169554+00
93	4	307	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:02.956911+00
94	4	298	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:03.388806+00
95	4	348	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:03.868913+00
96	4	309	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:08.765458+00
97	4	273	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:12.989751+00
98	4	286	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:17.31379+00
99	4	314	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:17.872908+00
100	4	288	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:18.002616+00
286	5	349	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:00.328477+00
287	5	336	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:00.444024+00
288	5	224	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:00.56191+00
289	5	479	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:00.688294+00
290	5	334	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:00.811067+00
103	4	293	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:30.733931+00
104	4	294	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:34.209118+00
105	4	296	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:34.469536+00
106	4	325	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:40.925129+00
107	4	278	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:50.333299+00
108	4	377	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:54.340511+00
109	4	329	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:54.752689+00
110	4	351	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:12:59.137273+00
111	4	66	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:00.541365+00
112	4	255	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:00.739814+00
113	4	574	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:13:01.854452+00
31	4	193	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:22.707219+00
35	4	200	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:35.893005+00
36	4	137	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:36.38067+00
37	4	205	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:36.928873+00
38	4	224	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:37.824461+00
39	4	578	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:38.307588+00
40	4	212	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:38.759711+00
41	4	209	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:39.18396+00
42	4	210	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:42.761185+00
43	4	207	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:43.084672+00
44	4	343	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:43.193759+00
45	4	264	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:43.464659+00
46	4	238	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:43.554147+00
47	4	524	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:48.352935+00
48	4	217	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:49.152929+00
49	4	258	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:49.980684+00
50	4	232	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:50.145116+00
51	4	247	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:50.367254+00
52	4	215	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:50.816529+00
53	4	48	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:51.357186+00
54	4	281	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:51.563458+00
55	4	233	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:55.776943+00
56	4	225	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:10:59.901224+00
57	4	227	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:03.793382+00
58	4	213	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:04.006342+00
59	4	484	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:04.244919+00
60	4	226	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:07.980342+00
61	4	239	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:08.093137+00
62	4	236	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:12.218844+00
63	4	242	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:16.253186+00
64	4	243	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:19.437303+00
65	4	244	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:23.206096+00
66	4	268	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:27.997128+00
67	4	261	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:31.360957+00
68	4	245	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:31.766393+00
69	4	250	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:36.084998+00
70	4	253	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:36.183309+00
71	4	252	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:40.01485+00
72	4	331	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:40.542364+00
73	4	276	failed	3	telegram sendMessage status 400	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:45.108644+00
74	4	300	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:48.649161+00
75	4	295	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:48.949679+00
76	4	321	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:49.380109+00
77	4	318	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:49.814465+00
78	4	313	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:50.230325+00
79	4	274	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:50.492727+00
80	4	319	failed	3	telegram sendMessage status 403	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:54.705009+00
81	4	272	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:54.847491+00
82	4	138	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:55.078833+00
83	4	384	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:55.184559+00
84	4	324	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:55.90093+00
85	4	317	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:56.307803+00
86	4	251	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:56.666995+00
87	4	375	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:56.821409+00
88	4	282	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:57.212775+00
89	4	283	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:57.469639+00
90	4	311	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:58.020926+00
91	4	305	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:58.364768+00
92	4	312	sent	1	\N	2026-02-25 08:08:45.987688+00	2026-02-25 08:11:58.58193+00
333	5	541	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:39.742868+00
343	5	337	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:50.454334+00
368	5	690	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:26.95125+00
369	5	692	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:27.074395+00
370	5	61	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:30.518065+00
371	5	719	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:30.661436+00
372	5	3	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:30.78606+00
373	5	724	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:30.920028+00
374	5	740	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:31.135838+00
375	5	384	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:31.252365+00
376	5	788	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:31.378614+00
377	5	272	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:31.497198+00
378	5	412	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:34.919254+00
379	5	794	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:35.172293+00
380	5	790	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:35.305883+00
381	5	798	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:35.429686+00
382	5	652	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:35.591682+00
383	5	803	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:35.752892+00
384	5	774	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:39.035952+00
260	5	273	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:24.608571+00
261	5	286	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:27.849054+00
262	5	314	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:27.954048+00
263	5	283	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:28.109943+00
264	5	288	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:28.234664+00
385	5	954	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:39.139605+00
386	5	807	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:39.24342+00
387	5	808	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:42.550868+00
388	5	830	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:42.663038+00
389	5	834	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:42.778246+00
390	5	835	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:42.895373+00
391	5	809	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:46.202795+00
392	5	816	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:46.32391+00
393	5	632	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:46.473892+00
394	5	837	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:49.967795+00
395	5	838	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:50.18848+00
396	5	839	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:50.569597+00
397	5	840	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:50.813735+00
398	5	824	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:50.961661+00
399	5	843	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.229222+00
400	5	844	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.346798+00
401	5	124	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.537583+00
402	5	848	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.699341+00
403	5	850	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.84493+00
404	5	606	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:54.985824+00
405	5	854	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:55.16859+00
406	5	859	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:58.612831+00
407	5	820	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:58.749661+00
408	5	862	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:58.858952+00
409	5	858	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:58.963476+00
410	5	251	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:59.081488+00
411	5	404	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:59.209507+00
412	5	865	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:02.462207+00
413	5	866	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:02.574338+00
414	5	897	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:05.86175+00
415	5	620	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:06.017918+00
416	5	871	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:06.171988+00
417	5	872	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:06.291255+00
418	5	874	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:09.553672+00
419	5	875	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:13.232724+00
420	5	877	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:13.614461+00
421	5	882	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:16.886241+00
422	5	899	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:17.012048+00
423	5	883	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:17.138072+00
424	5	884	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.445264+00
425	5	936	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.549418+00
426	5	935	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.655495+00
427	5	928	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.77018+00
428	5	2	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.865769+00
429	5	912	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:20.975993+00
430	5	913	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:21.082371+00
431	5	956	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:24.327286+00
432	5	918	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:24.448163+00
433	5	215	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:24.561782+00
434	5	957	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:27.805435+00
435	5	920	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:31.158847+00
436	5	922	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:31.336634+00
438	5	873	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:31.846779+00
439	5	826	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:31.995672+00
440	5	931	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:32.125638+00
441	5	932	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:32.227801+00
442	5	933	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:32.328205+00
443	5	958	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:35.631992+00
445	5	1	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:39.289966+00
364	5	713	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:16.208026+00
365	5	688	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:19.942614+00
366	5	351	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:23.501143+00
367	5	687	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:26.839661+00
444	5	959	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:38:39.185357+00
360	5	733	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:12.334201+00
291	5	800	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:04.119283+00
361	5	315	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:12.466836+00
170	5	8	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:57.276867+00
362	5	685	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:12.57166+00
363	5	710	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:12.692652+00
178	5	47	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:15.200284+00
179	5	573	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:18.493506+00
180	5	134	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:18.653833+00
181	5	180	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:22.019396+00
182	5	204	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:22.150366+00
183	5	187	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:25.492007+00
184	5	9	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:28.813579+00
168	5	323	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:50.508075+00
169	5	178	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:32:53.887015+00
171	5	179	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:01.025626+00
172	5	51	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:04.948034+00
173	5	698	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:05.094345+00
174	5	886	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:08.353962+00
175	5	58	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:08.483109+00
176	5	145	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:08.605955+00
177	5	198	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:11.904492+00
185	5	188	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:32.1139+00
187	5	65	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:35.502438+00
188	5	190	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:35.608168+00
189	5	7	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:38.990913+00
190	5	191	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:42.636913+00
192	5	193	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:49.367483+00
193	5	43	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:52.701453+00
194	5	200	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:56.026554+00
196	5	205	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:56.447304+00
197	5	670	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:33:59.741241+00
198	5	699	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.118692+00
199	5	578	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.234855+00
201	5	484	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.496712+00
202	5	887	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.621065+00
203	5	207	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:03.749494+00
204	5	900	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:07.07363+00
206	5	940	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:10.501638+00
207	5	524	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:13.795887+00
208	5	209	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:13.905499+00
209	5	258	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:14.038402+00
210	5	232	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:14.653177+00
211	5	247	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:14.753943+00
212	5	217	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:14.858416+00
213	5	712	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:18.255733+00
214	5	343	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:18.357307+00
216	5	225	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:25.354423+00
217	5	227	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:28.719764+00
218	5	213	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:29.056793+00
220	5	715	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:32.937333+00
221	5	239	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:33.100418+00
222	5	264	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:33.213038+00
223	5	236	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:33.421656+00
224	5	242	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:36.824254+00
225	5	243	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:40.111253+00
227	5	268	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:46.917145+00
228	5	261	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:50.17228+00
229	5	245	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:50.284396+00
231	5	253	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:53.924097+00
232	5	252	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:57.324622+00
233	5	701	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:34:57.563108+00
234	5	276	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:01.196028+00
236	5	671	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:04.662811+00
237	5	321	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:04.816236+00
238	5	296	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:04.929136+00
239	5	313	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:05.03814+00
240	5	888	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:05.216667+00
241	5	318	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:05.340679+00
242	5	274	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:05.433668+00
243	5	950	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:05.518797+00
244	5	319	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:08.804477+00
246	5	324	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:12.665408+00
247	5	317	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:12.839381+00
248	5	375	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:12.995145+00
249	5	295	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:13.171956+00
250	5	282	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:13.318277+00
251	5	311	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:13.540639+00
252	5	305	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:13.684348+00
253	5	312	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:13.861932+00
254	5	307	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:17.547617+00
255	5	298	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:17.650794+00
256	5	348	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:17.761055+00
258	5	331	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:21.167861+00
259	5	755	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:21.325685+00
265	5	322	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:31.514926+00
269	5	325	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:41.795594+00
273	5	776	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:51.9731+00
285	5	358	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:35:56.896337+00
292	5	673	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:04.231328+00
293	5	344	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:07.515934+00
294	5	368	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:07.633934+00
300	5	365	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:11.5902+00
344	5	832	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:50.567232+00
345	5	952	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:50.694102+00
346	5	734	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:53.940147+00
347	5	281	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:54.093394+00
348	5	735	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:54.217101+00
349	5	772	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:54.323209+00
350	5	738	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:57.705291+00
351	5	335	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:36:57.83258+00
352	5	278	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:01.160077+00
353	5	678	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:04.656457+00
354	5	704	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:04.775297+00
355	5	760	failed	3	telegram sendMessage status 403	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:08.068992+00
356	5	679	failed	3	telegram sendMessage status 400	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:11.442645+00
357	5	695	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:11.661807+00
358	5	707	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:11.827961+00
359	5	474	sent	1	\N	2026-05-13 10:32:20.833676+00	2026-05-13 10:37:12.108585+00
\.


--
-- Data for Name: admin_broadcasts; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.admin_broadcasts (id, admin_user_id, audience, payload, status, created_at, updated_at) FROM stdin;
1	1	selected	{"message": "Здравствуйте, видим у вас 2 заказа , получили подтверждение платежа по одному , пожалуйста подтвердите 2 й , напишите @space4rest если возникнут вопросы."}	done	2026-02-19 09:37:15.990208+00	2026-02-19 09:37:22.543321+00
2	1	selected	{"message": "qweqwe"}	done	2026-02-19 10:37:58.220237+00	2026-02-19 10:38:00.911819+00
3	1	selected	{"message": "PRIVET"}	done	2026-02-21 12:03:04.304797+00	2026-02-21 12:03:09.184727+00
4	1	all	{"message": "Привет. Бот обновлен , работает в штатном режиме, билетов остается мало скоро стартанем 2 ю волну! Всех с Праздниками!"}	failed	2026-02-25 08:08:45.983584+00	2026-02-25 08:14:18.436187+00
5	1	all	{"message": "Сервис перезапущен , Успей купить билеты со скидкой по промкоду ПОБЕДА!"}	failed	2026-05-13 10:32:20.826656+00	2026-05-13 10:38:39.292897+00
\.


--
-- Data for Name: admin_event_parser_events; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.admin_event_parser_events (id, source_id, source_type, input, name, date_time, location, description, links, status, parser_error, parsed_at, imported_event_id, imported_by, imported_at, created_at, updated_at) FROM stdin;
1	1	auto	@anatmanfest	20.03. Shiva Moon by ChillOutPlanet Events & Anatman	2026-02-20 14:03:07+00		20.03. Shiva Moon by ChillOutPlanet Events & Anatman\nПредупреждение! Вторая сотня билетов по френдли прайсу первой волны подходит к концу. Мы любим плавность процесса, поэтому оставим нынешнюю цену до 23.59 этого воскресенья (22 Февраля).\n↗️С понедельника- прайс ап!\nСоветуем не откладывать на потом, клуб не резиновый, в предпродаже число билетов ограничено во имя комфорта посетителей.\n➡️Ваши билеты тут\n➡️Вся информация по Shiva Moon тут	{https://t.me/anatmanfest,https://t.me/anatmanfest/1081,http://www.shivamoon2026.ru/,https://ticket.chilloutplanet.ru/events/20260320/,https://shivamoon2026.ru/,https://cdn4.telesco.pe/file/aEp5hq2l0pKCw0zZI7WEkG_RY9eiOHhBAeiVur904-geU8D-76jcVVsEpKmVUYzXo1eFpL4JUROatXixDH3RonRbsKO3zy3wWqrtbq5Z6jSOp6WYxiC4b5h0v-5ug2HhSQL_Z0bTN8W2InJQV5hINk1Tq_fTI6nFKDOh942h27riqdB94aPdd3ge1X2LjxSu3fcoJ5eHPaJ0Mfvmm1iq_AURum5ZMEdrkkEo7AM2BKbOdYE9QxHHflp6tFk5n5DVyhXlIK-QCUc1ctpovLz_ceikQ2qrC2FtiKoQc1QvBiL8lxP5kgI_FJa-8MPy6XSSKlGHEu4qkE4XYp5J0zBxpg.jpg}	pending	\N	2026-02-20 15:37:33.845596+00	\N	\N	\N	2026-02-20 15:37:33.845596+00	2026-02-20 15:37:33.845596+00
2	1	auto	@anatmanfest	Тибетские практики во многом завязаны на тему смерти. Для буддист	2026-02-20 08:51:42+00		Тибетские практики во многом завязаны на тему смерти. Для буддиста это не мрачная тема, а центральная. Если ты принимаешь идею, что поток сознания после смерти продолжается, тогда главный вопрос жизни звучит очень практично: в каком состоянии ума ты подойдешь к моменту умирания, и куда этот поток дальше пойдет.\nВ тибетской традиции это проработано особенно глубоко. Вы, наверное, знаете про Тибетскую книгу мертвых, “Бардо Тодол”, но по факту там целая большая система знаний и практик про умирание, переходные состояния и перерождение. Условно говоря, тибетцы подробно разбирали карту смерти так же внимательно, как другие традиции разбирали карту медитации.\nСмысл в том, что в процессе умирания и после него возникают особые состояния сознания. В момент распада привычной структуры ума могут открываться очень сильные “окна” для узнавания природы ума. В эти моменты можно освободиться, если есть навык присутствия и если сознание не схлопывается в панику и цепляние.\nИменно поэтому практика нужна заранее. Ты тренируешь внимание, устойчивость и узнавание не ради “духовного имиджа”, а чтобы в самый важный момент не потерять себя.\nЧеловеческое рождение в буддизме считается самым ценным для практики. У человека достаточно страдания, чтобы искать выход, и достаточно ясности, чтобы учиться. У животных страдание тоже есть, иногда даже больше, но возможностей для осознанной практики почти нет. Поэтому человеческая жизнь считается редким шансом.\nПри этом человек в буддийской картине и самый перспективный, и самый рискованный. У него есть свобода воли, а значит он может накопить очень много благой кармы, и может накопить много тяжелой. Животному почти невозможно достичь полного пробуждения, потому что для этого нужны понимание, обучение и осознанная практика. С другой стороны, у животного меньше пространства для осознанного неправильного морального выбора, чем у человека. И в ады ему тоже попасть не так просто.\nА человеку и высокие возможности доступны, и тяжелые падения тоже очень даже доступны... Набухался, убил кого-то и привет 10000 лет адов :). Поэтому базовая этика в буддизме настолько важна. Даже если человек не уходит глубоко в медитацию, уже сама нормальная человеческая жизнь без жестокости, подлости и сознательного вреда создает основу для более благоприятного перерождения.\nА дальше начинается уже “апгрейд”. Любая связь с учением усиливает шансы: слушал наставления, размышлял, практиковал, держал обеты, делал практики очищения, развивал сострадание, делал накопление заслуги. Все это в традиционной логике меняет траекторию потока сознания.\nЕсть и специальные практики, связанные со смертью. Например, пхова, практика переноса сознания. Это, да простят меня адепты, “чит-код”, и в каком-то смысле понятно почему: это действительно метод, заточенный под критический момент. Но в нормальной традиционной подаче это все равно часть пути, а не магическая кнопка.\nА дзогчен - это практика, где человек учится узнавать природу ума уже при жизни, чтобы потом узнать ее и в момент смерти. В дзогчене это ключевая идея: узнавание ригпа сейчас, стабилизация этого узнавания, и перенос этой способности через все состояния, включая умирание.\nЕсли совсем просто, логика такая. Хорошая человеческая жизнь дает шанс на хорошее перерождение. Практика дает шанс на еще более благоприятную траекторию. Глубокая практика дает шанс выйти из самой игры.\n(на картинке триптих из Банкокского MOCA, они метров 6 высотой, поэтому там мелко, но имеет смысл порассматривать :) )	{https://t.me/anatmanfest,https://t.me/anatmanfest/1080,https://cdn4.telesco.pe/file/RFrVSE2UfLDblNjp4NJzYOq43GymcjF9pxsdGnZkC9D1NSmNQaboPEw0ajYWotYJltA1zpClHccYkAs-u7KN71pNeWrO1m8scupZCrae_wuFYS1NaRk2FtSu1S5fTTwVuk-Du6qEWoO8LQmiDtP14jHMOhP9i0wroP-psKqva4zja-rhq7CdD3eAKB7VLYVozFcedNW4zSQB3vx6XhGkkpEmD9YtTLeycAsB8SzjJLwzCrej4YoAFpKWMbss88cgRexE852I6W2dqURm4yymc38mNsZpX7L_UFjX8VNKXvKOtdMl_vIh2QhPd7r-gYdzKX26RhmdB6Zuc5k8WHH0KQ.jpg}	imported	\N	2026-02-20 15:37:33.848995+00	\N	1	2026-02-20 15:38:33.873875+00	2026-02-20 15:37:33.848995+00	2026-02-20 15:38:33.873875+00
3	\N	auto	https://t.me/c/1137838000/19377	Fast. Secure. Powerful.	\N		Fast. Secure. Powerful.	{https://t.me/c/1137838000,https://telegram.org/img/t_logo_2x.png}	pending	\N	2026-02-21 11:24:18.280699+00	\N	\N	\N	2026-02-21 11:24:18.280699+00	2026-02-21 11:24:18.280699+00
4	2	auto	https://t.me/c/1137838000/19770	Fast. Secure. Powerful.	\N		Fast. Secure. Powerful.	{https://t.me/c/1137838000,https://telegram.org/img/t_logo_2x.png}	pending	\N	2026-03-01 20:25:58.768625+00	\N	\N	\N	2026-03-01 20:25:58.768625+00	2026-03-01 20:25:58.768625+00
5	\N	telegram	https://t.me/c/1137838000/19770	Fast. Secure. Powerful.	\N		Fast. Secure. Powerful.	{https://t.me/c/1137838000,https://telegram.org/img/t_logo_2x.png}	pending	\N	2026-03-01 20:26:18.506729+00	\N	\N	\N	2026-03-01 20:26:18.506729+00	2026-03-01 20:26:18.506729+00
\.


--
-- Data for Name: admin_event_parser_sources; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.admin_event_parser_sources (id, source_type, input, title, is_active, last_parsed_at, created_by, created_at, updated_at) FROM stdin;
1	auto	@anatmanfest	\N	f	2026-02-20 15:37:33.852141+00	1	2026-02-20 15:37:23.321287+00	2026-03-01 20:25:51.799424+00
2	auto	https://t.me/c/1137838000/19770	\N	f	2026-03-01 20:25:58.773138+00	1	2026-03-01 20:25:28.952705+00	2026-03-01 20:26:53.198344+00
\.


--
-- Data for Name: event_comments; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.event_comments (id, event_id, user_id, body, created_at) FROM stdin;
7	6	138	ое	2026-02-13 17:26:57.338286+00
9	3	1	ПОЕХАЛИ , ВСЕХ С ДНЁМ ВЛЮБЛЕННЫХ!	2026-02-14 11:00:18.254662+00
11	3	255	уиии🌲🦋🌷	2026-02-14 18:07:07.51201+00
12	3	318	👾 Да будет транц!	2026-02-15 03:24:30.994149+00
13	3	399	я перевел деньги) где транзакции? куда кинуть чек?))	2026-02-19 11:52:49.839613+00
16	3	412	Прямо в бота @spacetickets_bot, в приложении во вкладке Профиль увидите QR	2026-02-20 14:37:29.428872+00
18	3	936	Добрый день!не работает промик,пишет usage limit reached	2026-05-10 07:42:51.386939+00
19	3	1	Попробуйте еще раз, обновил!	2026-05-10 08:34:17.272662+00
20	3	1032	перевёл денег на билет. Буду готовиться и настраиваться на веселье.	2026-05-17 00:12:34.727992+00
21	3	1032	показывает, что билет есть, а его статус ожидает оплату. Скинул в бота подтверждения перевода в pdf, а так же скрин.	2026-05-17 00:23:36.099415+00
22	3	1	Проверьте ваш аккаунт все должно прилететь!	2026-05-17 16:37:11.559879+00
23	3	1109	Оплатила, кинула в бот, а в ответ тишина 🔇. как быстро придёт qr?	2026-05-22 13:51:16.843126+00
24	3	3	kyky	2026-06-25 21:03:33.994434+00
\.


--
-- Data for Name: event_likes; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.event_likes (event_id, user_id, created_at) FROM stdin;
3	1	2026-02-10 09:18:25.921998+00
3	412	2026-02-20 15:05:04.580749+00
3	3	2026-02-20 15:24:55.814573+00
3	2	2026-02-21 12:30:52.527792+00
14	2	2026-02-21 12:30:56.779131+00
13	2	2026-02-21 12:30:58.39513+00
14	1	2026-02-21 12:39:11.901225+00
13	1	2026-02-21 12:39:15.876342+00
13	3	2026-02-21 12:41:00.994445+00
13	412	2026-02-21 12:45:53.359842+00
14	412	2026-02-21 12:45:55.249612+00
3	138	2026-02-21 13:43:01.457041+00
13	541	2026-02-21 14:30:04.414761+00
16	1	2026-02-21 21:25:24.10184+00
16	207	2026-02-21 23:14:34.003414+00
13	199	2026-02-22 14:47:53.559227+00
3	295	2026-02-25 08:12:51.310234+00
13	611	2026-02-28 11:45:54.552581+00
3	620	2026-02-28 17:07:35.356676+00
3	687	2026-03-06 16:49:49.594422+00
3	606	2026-03-07 16:24:29.192669+00
3	766	2026-03-09 07:50:36.164583+00
\.


--
-- Data for Name: event_media; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.event_media (id, event_id, url, type, created_at) FROM stdin;
1	3	http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg	image	2026-02-10 09:17:46.38126+00
8	13	http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg	image	2026-02-21 11:29:37.838295+00
9	14	http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg	image	2026-02-21 12:23:25.670013+00
10	15	http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png	image	2026-02-21 13:17:05.563184+00
11	16	http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg	image	2026-02-21 21:15:47.395453+00
12	16	http://minio:9000/gigme/events/2026/02/21/1771708484006532833-scaled_IMG_3805.png	image	2026-02-21 21:15:47.395453+00
13	18	http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg	image	2026-02-21 23:22:47.919022+00
14	18	http://minio:9000/gigme/events/2026/02/21/1771716103341123644-scaled_IMG_3808.jpeg	image	2026-02-21 23:22:47.919022+00
\.


--
-- Data for Name: event_participants; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.event_participants (event_id, user_id, status, joined_at) FROM stdin;
3	2	joined	2026-02-12 10:38:08.648254+00
3	65	joined	2026-02-12 15:05:22.011045+00
3	1	joined	2026-02-13 10:01:15.703024+00
6	138	joined	2026-02-13 17:20:22.072131+00
7	138	joined	2026-02-13 17:29:57.076354+00
6	1	joined	2026-02-13 18:03:00.550426+00
3	3	joined	2026-02-14 06:16:00.837878+00
3	205	joined	2026-02-14 11:51:19.801741+00
3	204	joined	2026-02-14 11:53:50.75954+00
3	209	joined	2026-02-14 11:55:09.62914+00
3	217	joined	2026-02-14 13:41:32.007932+00
3	288	joined	2026-02-14 16:09:52.800885+00
3	255	joined	2026-02-14 18:06:18.267463+00
3	308	joined	2026-02-14 20:12:40.549602+00
3	311	joined	2026-02-14 20:55:53.687563+00
3	318	joined	2026-02-15 03:24:37.657828+00
3	329	joined	2026-02-15 09:39:12.184169+00
3	368	joined	2026-02-17 06:56:47.235918+00
3	399	joined	2026-02-19 11:52:17.243851+00
3	404	joined	2026-02-19 12:17:39.788756+00
3	412	joined	2026-02-20 14:38:36.563951+00
3	474	joined	2026-02-20 20:44:30.935224+00
13	1	joined	2026-02-21 11:29:37.845588+00
14	412	joined	2026-02-21 12:23:25.679431+00
15	412	joined	2026-02-21 13:17:05.570002+00
15	138	joined	2026-02-21 13:42:05.278361+00
14	251	joined	2026-02-21 15:57:56.896183+00
16	1	joined	2026-02-21 21:15:47.403175+00
18	1	joined	2026-02-21 23:22:47.926297+00
3	133	joined	2026-02-22 02:16:13.817219+00
13	199	joined	2026-02-22 14:47:32.290798+00
13	611	joined	2026-02-28 11:45:39.474071+00
3	620	joined	2026-02-28 17:22:37.373576+00
3	652	joined	2026-03-03 12:21:32.297122+00
3	660	joined	2026-03-04 20:23:42.588262+00
3	278	joined	2026-03-06 16:03:37.722697+00
3	687	joined	2026-03-06 16:44:36.377343+00
3	695	joined	2026-03-06 18:21:09.001979+00
3	699	joined	2026-03-06 19:00:45.790793+00
3	61	joined	2026-03-07 06:34:55.386605+00
3	606	joined	2026-03-07 16:25:23.759947+00
3	740	joined	2026-03-08 13:08:38.54179+00
3	766	joined	2026-03-09 07:50:38.699236+00
3	875	joined	2026-04-14 13:42:44.287698+00
3	1032	joined	2026-05-17 00:07:29.633306+00
3	1109	joined	2026-05-22 11:38:27.02622+00
3	1393	joined	2026-06-20 16:15:30.895158+00
3	831	joined	2026-06-24 12:16:25.145562+00
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.events (id, creator_user_id, title, description, starts_at, ends_at, location, address_label, capacity, is_hidden, promoted_until, created_at, updated_at, filters, contact_telegram, contact_whatsapp, contact_wechat, contact_fb_messenger, contact_snapchat, is_private, access_key, links, is_landing_published) FROM stdin;
6	138	Пошли за Пивом!	Гдебы ты не был пора по ПИВУ!	2026-02-13 18:19:00+00	2026-02-13 18:19:00+00	0101000020E6100000172448F0590F41400120F98C2B404640	44.50133, 34.11993	\N	f	\N	2026-02-13 17:20:22.067086+00	2026-02-13 17:20:22.067086+00	{bar}	ффф	\N	\N	\N	\N	f	\N	{}	f
7	138	Самое время	Те кто будет создавать мСбытия в придожении , будут получать токены , которые можно будет обменять на пиво на SPACE 2026	2026-02-13 18:28:00+00	2026-02-13 18:28:00+00	0101000020E6100000D98430116B5A404081D4FFB208A64740	47.29714, 32.70639	\N	f	\N	2026-02-13 17:29:57.070801+00	2026-02-13 17:29:57.070801+00	{party,fun}	space4rest	\N	\N	\N	\N	f	\N	{}	f
13	1	☄️10 YEARS of PRALAYAH ☄️	SONUS RESONANCE собирает Label party, посвященную 10-летию PRALAYAH RECORDS с мощнейшим Forest составом из России, Индии и Северной Македонии!\n\nНа 2-х танцполах раскачивать пространство будет Чистый, Мощный и Детализированный звук \nL-ACOUSTICS📣\n\n🎟 КУПИТЬ БИЛЕТ 🎟\n\n🎫 Ticket in TELEGRAM🎫\n\nhttps://t.me/SONUSRESONANCE	2026-03-28 17:26:00+00	2026-04-29 12:27:00+00	0101000020E610000063807B9074CD42407AC797A214E24B40	55.76625, 37.60512	\N	f	\N	2026-02-21 11:29:37.838295+00	2026-02-21 11:29:37.838295+00	{}	@atremtabooo	\N	\N	\N	\N	f	\N	{}	f
14	412	Масленница	Гуляем по Набережной , Едим блины, пьем Грок! Присоединяйтесь!	2026-02-21 13:21:00+00	2026-02-21 17:21:00+00	0101000020E61000007A867E85C01541405972524E9A3F4640	44.49690, 34.16994	\N	f	\N	2026-02-21 12:23:25.670013+00	2026-02-21 12:23:25.670013+00	{dating,travel}	ggeff	\N	\N	\N	\N	f	\N	{}	f
15	412	Поход на Гору Медведь	Идем завтра с Тимохой	2026-02-22 14:15:00+00	2026-02-22 14:15:00+00	0101000020E6100000389967699A294140F70CB547ED484640	44.56974, 34.32502	\N	f	\N	2026-02-21 13:17:05.563184+00	2026-02-21 13:17:05.563184+00	{travel}	@yalta_gid	\N	\N	\N	\N	f	\N	{}	f
3	1	SPACE 31-3 AUG	🎧 🎧 SONIC STAGE🎧🎧  \n\nNECROPSYCHO 🇧🇷\nADANSONIA 🇦🇷  \nDEL TORTO 🇧🇷  \nNOISE GUST 🇯🇵  \nCHRONOMATIC & DISSOCIACTIVE — 3H LIVE  \nPROPAGUL — LIVE \nMIK-HA  \nKNOCKKNOCK \nUNDER THE ROOTS — LIVE  \nUGORIAN  \nHARE  \nWIRD SYSTEM  \nANTONIO  \nCHANGA  \nLYNOXOD & STEALTH \n\n🪩🪩 LENSOUND STAGE🪩🪩\n\nDENIS KAZNACHEEV\nXANDER VASILIEV modular live\nNIKITA ZABELIN\nANRILOV\nYUKA (SEMANTICA REC)   \nOID  \nROMA PTASHENKO  \nALEXANDER KNIGA  \nSHU  \nBRYLEV & LANY  \nHELLPER  \nWAS  \nLANSKOY  \nCHILIT NA VAIBE  \nMAGIN\n\n✨✨ SPACE STAGE ✨✨\n\nTaboo\nIAN E-NZO\nEvan\nPir Pir\nBASIL\nRodzie\nGambRa\nChanga\nTaboo feat Ivadjima\nNut Harvested\nKEIJU  \nPSYNA\nGo & Ama Dj's\nMescalita\nOK\nBaranowski\nTakso\nJohzef	2026-07-31 09:15:00+00	2026-08-03 09:15:00+00	0101000020E61000005C7347FFCB513E4015A930B610FA4D40	\N	1000	f	\N	2026-02-10 09:17:46.38126+00	2026-06-25 19:49:14.923652+00	{party}	@space4rest	\N	\N	\N	\N	f	\N	{}	t
16	1	Тишина	ТИШИНА — это больше, чем просто магазин виниловых пластинок.\n\nЭто место, где звук становится искусством, а музыка — образом жизни.\n\nМы открыли наше пространство, чтобы вернуть культуру вдумчивого прослушивания — ту самую магию, когда опускается игла, и комната наполняется теплом живого звука. В ТИШИНе вы найдете не только тщательно отобранные виниловые издания, но и высококачественную аудиоаппаратуру, которая раскрывает музыку во всей глубине и деталях.	2026-02-21 22:15:00+00	\N	0101000020E61000006F638FCE317B34404D402DE92B5C4B40	54.72009, 20.48123	\N	f	\N	2026-02-21 21:15:47.395453+00	2026-02-21 21:15:47.395453+00	{business,travel}	tishna_vinyl	\N	\N	\N	\N	f	\N	{}	f
18	1	Bustation	https://t.me/Bustation2	2026-02-22 00:22:00+00	\N	0101000020E6100000A6F685D8B780344054ABC0918E5A4B40	54.70748, 20.50281	\N	f	\N	2026-02-21 23:22:47.919022+00	2026-02-21 23:22:47.919022+00	{bar}	bus	\N	\N	\N	\N	f	\N	{}	f
\.


--
-- Data for Name: landing_content; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.landing_content (id, hero_eyebrow, hero_title, hero_description, hero_primary_cta_label, about_title, about_description, partners_title, partners_description, footer_text, updated_by, created_at, updated_at, sonic_stage_title, sonic_stage_description, sonic_stage_image_url, lensound_stage_title, lensound_stage_description, lensound_stage_image_url, space_stage_title, space_stage_description, space_stage_image_url) FROM stdin;
1		SPACE 31-3 AUG 2026		Купить билет					SPACE APP	1	2026-02-10 11:42:49.437362+00	2026-06-25 19:00:23.846137+00	SONIC STAGE	ADANSONIA 🇦🇷\nDEL TORTO 🇧🇷\nNOISE GUST 🇯🇵\nCHRONOMATIC & DISSOCIACTIVE — 3H LIVE\nPROPAGUL — LIVE\nMIK-HA\nKNOCKKNOCK\nUNDER THE ROOTS — LIVE\nUGORIAN\nHARE\nWIRD SYSTEM\nANTONIO\nCHANGA\nLYNOXOD & STEALTH		LENSOUND STAGE	DENIS KAZNACHEEV\nXANDER VASILIEV modular live\nNIKITA ZABELIN\nANRILOV\nYUKA (SEMANTICA REC)\nOID\nROMA PTASHENKO\nALEXANDER KNIGA\nSHU\nBRYLEV & LANY\nHELLPER\nWAS\nLANSKOY\nCHILIT NA VAIBE\nMAGIN		SPACE STAGE	Taboo\nIAN E-NZO\nEvan\nPir Pir\nBASIL\nRodzie\nGambRa\nChanga\nTaboo feat Ivadjima\nNut Harvested\nKEIJU\nPSYNA\nGo & Ama Dj's\nMescalita\nOK\nBaranowski\nTaks	
\.


--
-- Data for Name: notification_jobs; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.notification_jobs (id, user_id, event_id, kind, run_at, payload, status, attempts, last_error, created_at, updated_at) FROM stdin;
1242	133	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-22 02:16:13.825913+00	2026-02-22 02:16:13.825913+00
24	1	3	comment_added	2026-02-10 21:49:28.035623+00	{"title": "SPACE", "comment": "ggjdjnxnnx", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "ＳP Λ C Ξ"}	sent	0	\N	2026-02-10 21:49:28.036927+00	2026-02-10 21:49:36.018676+00
66	51	6	event_created	2026-02-13 17:26:37.895476+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:46.025264+00
26	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-11 07:46:26.745812+00	2026-02-11 07:46:26.745812+00
130	3	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 06:16:00.846705+00	2026-02-14 06:16:00.846705+00
28	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-11 07:46:28.72428+00	2026-02-11 07:46:28.72428+00
105	1	6	joined	2026-02-13 18:03:00.554372+00	{"title": "Пошли за Пивом!", "eventId": 6}	sent	0	\N	2026-02-13 18:03:00.555405+00	2026-02-13 18:03:04.096485+00
59	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-13 10:01:15.710688+00	2026-02-13 10:01:15.710688+00
25	1	3	joined	2026-02-11 07:46:26.741107+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-11 07:46:26.74199+00	2026-02-11 07:46:31.649721+00
27	1	3	joined	2026-02-11 07:46:28.721564+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-11 07:46:28.721809+00	2026-02-11 07:46:32.080862+00
58	1	3	joined	2026-02-13 10:01:15.706259+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-13 10:01:15.707168+00	2026-02-13 10:01:25.984989+00
31	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-11 07:47:59.21123+00	2026-02-11 07:47:59.21123+00
129	3	3	joined	2026-02-14 06:16:00.841577+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 06:16:00.842701+00	2026-02-14 06:16:04.084893+00
1241	133	3	joined	2026-02-22 02:16:13.820486+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-22 02:16:13.821604+00	2026-02-22 02:16:24.137493+00
29	1	3	comment_added	2026-02-11 07:47:53.49102+00	{"title": "SPACE", "comment": "vfdlkfjdldfkvjd", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "ＳP Λ C Ξ"}	sent	0	\N	2026-02-11 07:47:53.492126+00	2026-02-11 07:48:02.831593+00
30	1	3	joined	2026-02-11 07:47:59.207724+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-11 07:47:59.208037+00	2026-02-11 07:48:02.91175+00
33	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-11 17:25:56.999001+00	2026-02-11 17:25:56.999001+00
32	1	3	joined	2026-02-11 17:25:56.994311+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-11 17:25:56.995348+00	2026-02-11 17:26:03.965587+00
34	1	3	comment_added	2026-02-11 18:22:58.504346+00	{"title": "SPACE", "comment": "сбвьвьчьч", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "ＳP Λ C Ξ"}	sent	0	\N	2026-02-11 18:22:58.505412+00	2026-02-11 18:23:09.230073+00
36	2	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-12 10:38:08.656084+00	2026-02-12 10:38:08.656084+00
35	2	3	joined	2026-02-12 10:38:08.65145+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-12 10:38:08.652498+00	2026-02-12 10:38:15.853503+00
37	1	3	comment_added	2026-02-12 15:05:08.491586+00	{"title": "SPACE", "comment": "ghybb", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Алиса Малыгина"}	sent	0	\N	2026-02-12 15:05:08.492353+00	2026-02-12 15:05:13.341114+00
39	65	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-12 15:05:22.016917+00	2026-02-12 15:05:22.016917+00
38	65	3	joined	2026-02-12 15:05:22.013136+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-12 15:05:22.013957+00	2026-02-12 15:05:23.711041+00
17	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-10 09:17:46.39702+00	2026-02-10 09:17:46.39702+00
40	1	3	comment_added	2026-02-12 21:52:48.577395+00	{"title": "SPACE", "comment": "Ура ура ура", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "ＳP Λ C Ξ"}	sent	0	\N	2026-02-12 21:52:48.578314+00	2026-02-12 21:52:56.986739+00
42	1	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-12 21:53:33.231624+00	2026-02-12 21:53:33.231624+00
11	2	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:03.46338+00
12	3	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:05.015013+00
13	7	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:05.608696+00
14	1	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:07.062823+00
15	9	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:07.972816+00
16	8	3	event_created	2026-02-10 09:17:46.391053+00	{"title": "SPACE", "eventId": 3, "photoUrl": "http://minio:9000/gigme/events/2026/02/10/1770714997161436823-IMG_3668.jpeg", "startsAt": "2026-07-31T09:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api"}	sent	0	\N	2026-02-10 09:17:46.392174+00	2026-02-10 09:18:09.113006+00
41	1	3	joined	2026-02-12 21:53:33.228506+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-12 21:53:33.228715+00	2026-02-12 21:53:37.10804+00
136	1	3	comment_added	2026-02-14 11:00:18.257169+00	{"title": "SPACE", "comment": "ПОЕХАЛИ , ВСЕХ С ДНЁМ ВЛЮБЛЕННЫХ!", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "ＳP Λ C Ξ"}	sent	0	\N	2026-02-14 11:00:18.257795+00	2026-02-14 11:00:37.001328+00
138	205	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 11:51:19.808709+00	2026-02-14 11:51:19.808709+00
82	2	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:43.580644+00
341	204	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:14.604759+00
152	1	3	comment_added	2026-02-14 18:07:07.514876+00	{"title": "SPACE", "comment": "уиии🌲🦋🌷", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "kishori_floweret"}	sent	0	\N	2026-02-14 18:07:07.515553+00	2026-02-14 18:07:08.517513+00
161	329	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-15 09:39:12.193309+00	2026-02-15 09:39:12.193309+00
89	3	7	event_created	2026-02-13 17:36:09.478259+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:16.626107+00
64	61	6	event_created	2026-02-13 17:26:34.931195+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:42.880506+00
65	3	6	event_created	2026-02-13 17:26:36.935337+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:45.447869+00
67	47	6	event_created	2026-02-13 17:26:38.59921+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:47.157717+00
68	48	6	event_created	2026-02-13 17:26:39.688482+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:47.944644+00
74	9	6	event_created	2026-02-13 17:26:40.747505+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:48.102982+00
170	404	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-19 12:17:39.79666+00	2026-02-19 12:17:39.79666+00
87	132	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:04.906032+00
88	138	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:05.86963+00
1243	199	13	joined	2026-02-22 14:47:32.294998+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13}	sent	0	\N	2026-02-22 14:47:32.296126+00	2026-02-22 14:47:33.880524+00
169	404	3	joined	2026-02-19 12:17:39.791913+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-19 12:17:39.793032+00	2026-02-19 12:17:47.325662+00
1244	199	13	reminder_60m	2026-03-28 16:26:00+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13}	sent	0	\N	2026-02-22 14:47:32.299838+00	2026-03-28 16:26:09.640327+00
1114	7	18	event_created	2026-02-21 23:29:59.493983+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:02.423755+00
1246	611	13	reminder_60m	2026-03-28 16:26:00+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13}	sent	0	\N	2026-02-28 11:45:39.482957+00	2026-03-28 16:26:09.788869+00
1116	192	18	event_created	2026-02-21 23:30:02.041953+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:04.811696+00
786	323	16	event_created	2026-02-21 21:22:14.069659+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:19.775657+00
137	205	3	joined	2026-02-14 11:51:19.804567+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 11:51:19.805393+00	2026-02-14 11:51:20.785241+00
792	47	16	event_created	2026-02-21 21:22:19.704065+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:25.072378+00
794	180	16	event_created	2026-02-21 21:22:20.797462+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:26.624627+00
139	204	3	joined	2026-02-14 11:59:52.112788+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-02-14 11:53:50.762256+00	2026-02-14 11:59:52.829075+00
145	217	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 13:41:32.016558+00	2026-02-14 13:41:32.016558+00
144	217	3	joined	2026-02-14 13:41:32.011384+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 13:41:32.012546+00	2026-02-14 13:41:37.089565+00
149	295	3	payment_confirmed	2026-02-14 17:06:15.601488+00	{"title": "SPACE", "amount": "5000.00", "eventId": 3, "orderId": "be316b60-9982-4b17-8d01-83ae67104eef", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-02-14 17:00:09.364792+00	2026-02-14 17:06:16.25251+00
140	204	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 11:53:50.764699+00	2026-02-14 11:53:50.764699+00
151	255	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 18:06:18.27406+00	2026-02-14 18:06:18.27406+00
154	308	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 20:12:40.557286+00	2026-02-14 20:12:40.557286+00
150	255	3	joined	2026-02-14 18:06:18.270465+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 18:06:18.271489+00	2026-02-14 18:06:28.168509+00
529	214	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:33.351988+00
62	8	6	event_created	2026-02-13 17:26:35.652213+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:43.341092+00
63	56	6	event_created	2026-02-13 17:26:36.418548+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:44.175713+00
153	308	3	joined	2026-02-14 20:12:40.552757+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 20:12:40.553872+00	2026-02-14 20:12:41.93389+00
1245	611	13	joined	2026-02-28 11:45:39.477158+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13}	sent	0	\N	2026-02-28 11:45:39.478018+00	2026-02-28 11:45:44.019228+00
160	329	3	joined	2026-02-15 09:39:12.187972+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-15 09:39:12.189204+00	2026-02-15 09:39:22.140245+00
90	51	7	event_created	2026-02-13 17:36:10.470468+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:17.169923+00
78	7	6	event_created	2026-02-13 17:26:50.972984+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:58.705016+00
79	43	6	event_created	2026-02-13 17:26:51.717932+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	failed	3	telegram sendMessage status 400	2026-02-13 17:20:22.074751+00	2026-02-13 17:26:59.297559+00
83	138	6	comment_added	2026-02-13 17:26:57.342081+00	{"title": "Пошли за Пивом!", "comment": "ое", "eventId": 6, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "iMania"}	sent	0	\N	2026-02-13 17:26:57.342749+00	2026-02-13 17:26:59.749516+00
91	47	7	event_created	2026-02-13 17:36:11.108393+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:18.32197+00
92	48	7	event_created	2026-02-13 17:36:13.978301+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:19.025994+00
165	399	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-19 11:52:17.252298+00	2026-02-19 11:52:17.252298+00
800	132	16	event_created	2026-02-21 21:22:25.614309+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:33.172087+00
164	399	3	joined	2026-02-19 11:58:35.106496+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-02-19 11:52:17.248356+00	2026-02-19 11:58:35.795206+00
69	132	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:36.256492+00
70	133	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:36.623888+00
71	134	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:36.87144+00
72	58	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:37.759877+00
73	66	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:38.687423+00
75	1	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:39.749105+00
76	137	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:39.959127+00
77	65	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:40.595051+00
80	138	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:42.415698+00
319	1	3	comment_added	2026-02-20 14:37:29.431954+00	{"title": "SPACE", "comment": "Прямо в бота @spacetickets_bot, в приложении во вкладке Профиль увидите QR", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Space Main"}	sent	0	\N	2026-02-20 14:37:29.432763+00	2026-02-20 14:37:33.583301+00
142	209	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 11:55:09.636822+00	2026-02-14 11:55:09.636822+00
81	124	6	event_created	2026-02-13 17:20:22.073867+00	{"title": "Пошли за Пивом!", "eventId": 6, "startsAt": "2026-02-13T18:19:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.50133, 34.11993"}	sent	0	\N	2026-02-13 17:20:22.074751+00	2026-02-13 17:20:42.805318+00
156	311	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 20:55:53.695092+00	2026-02-14 20:55:53.695092+00
360	205	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:30.028994+00
155	311	3	joined	2026-02-14 20:55:53.690961+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 20:55:53.691821+00	2026-02-14 20:56:03.180496+00
163	368	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-17 06:56:47.243928+00	2026-02-17 06:56:47.243928+00
141	209	3	joined	2026-02-14 12:01:12.447626+00	{"title": "SPACE", "eventId": 3}	sent	2	\N	2026-02-14 11:55:09.633358+00	2026-02-14 12:01:13.25447+00
448	485	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:48.764036+00
84	8	7	event_created	2026-02-13 17:36:12.038376+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:19.825663+00
85	56	7	event_created	2026-02-13 17:36:13.030399+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:20.625924+00
86	61	7	event_created	2026-02-13 17:36:13.638353+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:20.978033+00
162	368	3	joined	2026-02-17 06:56:47.239234+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-17 06:56:47.240307+00	2026-02-17 06:56:53.746594+00
458	360	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:59.667614+00
166	1	3	comment_added	2026-02-19 11:52:49.843806+00	{"title": "SPACE", "comment": "я перевел деньги) где транзакции? куда кинуть чек?))", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "V K"}	sent	0	\N	2026-02-19 11:52:49.84509+00	2026-02-19 11:53:03.949625+00
775	138	15	reminder_60m	2026-02-22 13:15:00+00	{"title": "Поход на Гору Медведь", "eventId": 15}	sent	0	\N	2026-02-21 13:42:05.285504+00	2026-02-22 13:15:09.449023+00
773	138	15	reminder_60m	2026-02-22 13:15:00+00	{"title": "Поход на Гору Медведь", "eventId": 15}	sent	0	\N	2026-02-21 13:18:33.940665+00	2026-02-22 13:15:09.925329+00
1248	620	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-28 17:22:37.376952+00	2026-02-28 17:22:37.376952+00
804	7	16	event_created	2026-02-21 21:22:26.596554+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:35.10404+00
807	193	16	event_created	2026-02-21 21:22:29.364714+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:40.287088+00
1110	132	18	event_created	2026-02-21 23:29:57.92988+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:01.107226+00
830	225	16	event_created	2026-02-21 21:22:39.380058+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:48.491925+00
1247	620	3	joined	2026-02-28 17:22:37.375049+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-28 17:22:37.375408+00	2026-02-28 17:22:39.781321+00
1140	225	18	event_created	2026-02-21 23:30:11.307997+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:21.210351+00
1252	660	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-04 20:23:42.593231+00	2026-03-04 20:23:42.593231+00
1251	660	3	joined	2026-03-04 20:23:42.589924+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-03-04 20:23:42.590324+00	2026-03-04 20:23:44.65804+00
1254	278	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-06 16:03:37.726347+00	2026-03-06 16:03:37.726347+00
442	337	13	event_created	2026-02-21 11:37:46.852486+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:49.469014+00
321	412	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-20 14:38:36.570776+00	2026-02-20 14:38:36.570776+00
157	1	3	comment_added	2026-02-15 03:24:30.997743+00	{"title": "SPACE", "comment": "👾 Да будет транц!", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Oleg 53"}	sent	0	\N	2026-02-15 03:24:30.998708+00	2026-02-15 03:24:32.987688+00
159	318	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-15 03:24:37.662358+00	2026-02-15 03:24:37.662358+00
379	484	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:46.513666+00
1250	652	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-03 12:21:32.301026+00	2026-03-03 12:21:32.301026+00
97	9	7	event_created	2026-02-13 17:36:14.46986+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:21.793898+00
158	318	3	joined	2026-02-15 03:24:37.660004+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-15 03:24:37.660225+00	2026-02-15 03:24:43.14079+00
101	7	7	event_created	2026-02-13 17:36:24.813831+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:32.01761+00
102	43	7	event_created	2026-02-13 17:36:25.307855+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	failed	3	telegram sendMessage status 400	2026-02-13 17:29:57.079235+00	2026-02-13 17:36:32.509607+00
93	133	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:09.774316+00
94	134	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:09.935181+00
95	58	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:10.70221+00
96	66	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:11.245632+00
1148	242	18	event_created	2026-02-21 23:30:19.185514+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:28.16614+00
98	1	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:12.226813+00
99	137	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:12.762535+00
100	65	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:13.739242+00
168	399	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-19 11:53:25.698007+00	2026-02-19 11:53:25.698007+00
148	288	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-14 16:09:52.805594+00	2026-02-14 16:09:52.805594+00
103	124	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:16.593412+00
104	2	7	event_created	2026-02-13 17:29:57.078138+00	{"title": "Самое время", "eventId": 7, "startsAt": "2026-02-13T18:28:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "47.29714, 32.70639"}	sent	0	\N	2026-02-13 17:29:57.079235+00	2026-02-13 17:30:18.335204+00
147	288	3	joined	2026-02-14 16:09:52.802869+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-02-14 16:09:52.803414+00	2026-02-14 16:10:03.238867+00
843	261	16	event_created	2026-02-21 21:22:57.744399+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:08.73729+00
320	412	3	joined	2026-02-20 14:44:44.989337+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-02-20 14:38:36.567512+00	2026-02-20 14:44:45.625902+00
383	236	13	event_created	2026-02-21 11:36:52.172825+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:52.878113+00
167	399	3	joined	2026-02-19 11:59:35.403653+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-02-19 11:53:25.693965+00	2026-02-19 11:59:36.252151+00
1249	652	3	joined	2026-03-03 12:27:37.366127+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-03-03 12:21:32.299668+00	2026-03-03 12:27:37.975246+00
398	295	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:08.782382+00
431	278	13	event_created	2026-02-21 11:37:47.351374+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:50.41347+00
894	532	16	event_created	2026-02-21 21:23:29.929366+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:40.671413+00
324	474	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-02-20 20:44:30.942582+00	2026-02-20 20:44:30.942582+00
1253	278	3	joined	2026-03-06 16:09:40.670262+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-03-06 16:03:37.72438+00	2026-03-06 16:09:42.047506+00
323	474	3	joined	2026-02-20 20:50:41.856907+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-02-20 20:44:30.9394+00	2026-02-20 20:50:42.818561+00
842	268	16	event_created	2026-02-21 21:22:56.602554+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:08.327519+00
1108	188	18	event_created	2026-02-21 23:29:56.709767+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:59.97656+00
1115	191	18	event_created	2026-02-21 23:30:00.998837+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:03.83394+00
878	322	16	event_created	2026-02-21 21:23:19.62223+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:30.981652+00
880	293	16	event_created	2026-02-21 21:23:22.19064+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:32.935878+00
883	325	16	event_created	2026-02-21 21:23:22.580882+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:34.090101+00
1141	227	18	event_created	2026-02-21 23:30:13.157941+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:22.402788+00
1131	524	18	event_created	2026-02-21 23:30:14.71833+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:24.48501+00
1155	250	18	event_created	2026-02-21 23:30:28.197934+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:32.699924+00
1231	369	18	event_created	2026-02-21 23:31:37.353935+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:47.51544+00
1236	412	18	event_created	2026-02-21 23:31:38.864073+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:49.05184+00
549	315	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:51.3586+00
420	286	13	event_created	2026-02-21 11:37:42.120517+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:45.545315+00
774	138	15	joined	2026-02-21 13:42:05.281493+00	{"title": "Поход на Гору Медведь", "eventId": 15}	sent	0	\N	2026-02-21 13:42:05.281748+00	2026-02-21 13:42:13.002989+00
896	549	16	event_created	2026-02-21 21:23:32.3385+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:42.240678+00
845	250	16	event_created	2026-02-21 21:22:58.499213+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:10.323635+00
914	357	16	event_created	2026-02-21 21:23:45.749647+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:56.001058+00
1255	278	3	payment_confirmed	2026-03-06 16:12:51.295797+00	{"title": "SPACE", "amount": "9200.00", "eventId": 3, "orderId": "a05893ee-a7ed-4cc7-95f5-ecfc912332a7", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-03-06 16:06:49.029642+00	2026-03-06 16:12:52.361252+00
1153	261	18	event_created	2026-02-21 23:30:25.95683+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:31.599464+00
1200	349	18	event_created	2026-02-21 23:31:11.162024+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:13.524944+00
1201	335	18	event_created	2026-02-21 23:31:12.682286+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:14.609429+00
1203	532	18	event_created	2026-02-21 23:31:14.442096+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:15.384825+00
1220	346	18	event_created	2026-02-21 23:31:23.110167+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:32.970603+00
425	322	13	event_created	2026-02-21 11:37:42.540879+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:46.093521+00
1223	357	18	event_created	2026-02-21 23:31:24.693973+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:34.736982+00
577	296	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:15.299685+00
930	541	16	event_created	2026-02-21 21:23:51.342228+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:24:01.336056+00
776	358	14	joined	2026-02-21 14:24:57.391485+00	{"title": "Масленница", "eventId": 14}	sent	0	\N	2026-02-21 14:24:57.39272+00	2026-02-21 14:25:06.316585+00
1257	687	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-06 16:44:36.381315+00	2026-03-06 16:44:36.381315+00
1239	541	18	event_created	2026-02-21 23:31:40.595286+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:49.933934+00
787	178	16	event_created	2026-02-21 21:22:15.071503+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:20.89282+00
788	8	16	event_created	2026-02-21 21:22:16.286336+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:22.014895+00
789	179	16	event_created	2026-02-21 21:22:17.326955+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:23.203907+00
422	315	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:32.767911+00
423	288	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:33.385406+00
424	318	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:34.44564+00
1256	687	3	joined	2026-03-06 16:50:43.985671+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-03-06 16:44:36.379502+00	2026-03-06 16:50:44.338489+00
1277	344	3	payment_confirmed	2026-05-16 12:28:53.665124+00	{"title": "SPACE", "amount": "11000.00", "eventId": 3, "orderId": "cad81c77-7492-43c3-a813-1aae18b8da5d", "currency": "RUB"}	failed	3	telegram sendMessage status 403	2026-05-16 12:22:43.9405+00	2026-05-16 12:28:54.041025+00
1259	695	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-06 18:21:09.005196+00	2026-03-06 18:21:09.005196+00
432	377	13	event_created	2026-02-21 11:37:45.528178+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:48.255263+00
514	210	14	event_created	2026-02-21 12:30:28.474889+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:37.880359+00
1258	695	3	joined	2026-03-06 18:21:09.003378+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-03-06 18:21:09.003707+00	2026-03-06 18:21:15.545325+00
343	9	13	event_created	2026-02-21 11:36:24.344774+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:26.803963+00
1279	1032	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-05-17 00:07:29.644115+00	2026-05-17 00:07:29.644115+00
777	251	14	joined	2026-02-21 15:57:56.900819+00	{"title": "Масленница", "eventId": 14}	sent	0	\N	2026-02-21 15:57:56.901991+00	2026-02-21 15:57:58.947602+00
1278	1032	3	joined	2026-05-17 00:07:29.637386+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-05-17 00:07:29.638702+00	2026-05-17 00:07:33.906195+00
428	294	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:38.576973+00
429	296	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:39.066088+00
441	336	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:43.467416+00
443	382	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:45.604491+00
444	255	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:46.234322+00
445	386	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:46.761216+00
446	340	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:47.417282+00
447	479	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:48.300248+00
457	357	13	event_created	2026-02-21 11:38:01.27984+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:03.354149+00
1261	699	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-06 19:00:45.794199+00	2026-03-06 19:00:45.794199+00
1197	351	18	event_created	2026-02-21 23:31:09.702269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:12.271143+00
347	132	13	event_created	2026-02-21 11:36:27.217291+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:32.580942+00
582	329	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:19.819234+00
583	389	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:20.633441+00
1260	699	3	joined	2026-03-06 19:06:46.605649+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-03-06 19:00:45.792843+00	2026-03-06 19:06:47.204415+00
1170	274	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:34.454755+00
1280	1	3	comment_added	2026-05-17 00:12:34.73563+00	{"title": "SPACE", "comment": "перевёл денег на билет. Буду готовиться и настраиваться на веселье.", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Kostyarich"}	sent	0	\N	2026-05-17 00:12:34.737034+00	2026-05-17 00:12:52.930245+00
449	344	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:49.603421+00
451	355	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:51.213394+00
452	358	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:52.525376+00
454	368	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:54.46573+00
1281	1	3	comment_added	2026-05-17 00:23:36.103855+00	{"title": "SPACE", "comment": "показывает, что билет есть, а его статус ожидает оплату. Скинул в бота подтверждения перевода в pdf, а так же скрин.", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Kostyarich"}	sent	0	\N	2026-05-17 00:23:36.104289+00	2026-05-17 00:23:43.625072+00
456	308	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:58.129875+00
1196	329	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:58.858122+00
1198	66	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:01.514278+00
1199	255	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:02.374155+00
1202	404	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:05.863268+00
1263	61	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-07 06:34:55.389635+00	2026-03-07 06:34:55.389635+00
461	379	13	event_created	2026-02-21 11:38:12.750879+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:15.211202+00
584	66	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:21.239014+00
585	349	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:22.012683+00
471	412	13	event_created	2026-02-21 11:38:14.576631+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:16.92174+00
351	7	13	event_created	2026-02-21 11:36:28.493364+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:33.740557+00
1262	61	3	joined	2026-03-07 06:41:05.172566+00	{"title": "SPACE", "eventId": 3}	failed	3	telegram sendMessage status 400	2026-03-07 06:34:55.388265+00	2026-03-07 06:41:05.788632+00
419	348	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:30.606624+00
421	314	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:32.067544+00
459	361	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:00.125129+00
462	237	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:03.744735+00
464	399	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:05.997991+00
465	341	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:07.001853+00
466	350	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:08.025924+00
467	387	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:08.33548+00
468	254	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:09.101397+00
469	383	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:09.665376+00
470	2	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:10.669574+00
472	133	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:12.337982+00
1264	61	3	payment_confirmed	2026-03-07 06:52:46.961232+00	{"title": "SPACE", "amount": "9200.00", "eventId": 3, "orderId": "a91884f3-49f2-44bc-be06-1aec61654126", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-03-07 06:46:36.38554+00	2026-03-07 06:52:47.575343+00
415	309	13	event_created	2026-02-21 11:37:30.267079+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:33.500019+00
418	273	13	event_created	2026-02-21 11:37:31.269813+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:34.031333+00
426	292	13	event_created	2026-02-21 11:37:43.251202+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:47.051534+00
430	325	13	event_created	2026-02-21 11:37:44.223252+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:47.675472+00
589	337	14	event_created	2026-02-21 12:31:34.975724+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:37.210996+00
427	293	13	event_created	2026-02-21 11:37:44.876382+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:48.813572+00
587	404	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:23.902934+00
450	351	13	event_created	2026-02-21 11:37:58.374185+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:01.563552+00
453	365	13	event_created	2026-02-21 11:37:58.887642+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:02.467538+00
588	336	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:24.514078+00
590	382	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:27.163208+00
591	255	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:27.8067+00
1265	687	3	payment_confirmed	2026-03-07 08:49:49.641949+00	{"title": "SPACE", "amount": "4600.00", "eventId": 3, "orderId": "0a70c9ad-4279-4dcf-b7d8-3c01ae069593", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-03-07 08:43:48.205527+00	2026-03-07 08:49:50.213656+00
352	191	13	event_created	2026-02-21 11:36:29.964748+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:34.19193+00
358	200	13	event_created	2026-02-21 11:36:35.728909+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:36.547805+00
377	227	13	event_created	2026-02-21 11:36:48.173874+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:50.505044+00
386	244	13	event_created	2026-02-21 11:37:04.528789+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:06.4278+00
392	250	13	event_created	2026-02-21 11:37:06.370913+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:10.060561+00
1267	606	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-07 16:25:23.762966+00	2026-03-07 16:25:23.762966+00
1266	606	3	joined	2026-03-07 16:25:23.76136+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-03-07 16:25:23.761676+00	2026-03-07 16:25:25.270205+00
593	269	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:28.942669+00
594	334	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:29.458795+00
1282	1	3	comment_added	2026-05-17 16:37:11.569309+00	{"title": "SPACE", "comment": "Проверьте ваш аккаунт все должно прилететь!", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": ". ."}	sent	0	\N	2026-05-17 16:37:11.573038+00	2026-05-17 16:37:16.944556+00
326	56	13	event_created	2026-02-21 11:36:14.669046+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:16.45195+00
328	374	13	event_created	2026-02-21 11:36:15.673538+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:17.66902+00
329	473	13	event_created	2026-02-21 11:36:16.851364+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:18.627818+00
330	61	13	event_created	2026-02-21 11:36:17.844819+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:19.746442+00
331	323	13	event_created	2026-02-21 11:36:18.832909+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:21.83637+00
332	178	13	event_created	2026-02-21 11:36:20.18089+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:23.564489+00
335	51	13	event_created	2026-02-21 11:36:22.274869+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:27.848235+00
338	47	13	event_created	2026-02-21 11:36:23.092937+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:28.852386+00
344	188	13	event_created	2026-02-21 11:36:26.407019+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:35.018605+00
455	346	13	event_created	2026-02-21 11:38:00.739922+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:04.271243+00
463	369	13	event_created	2026-02-21 11:38:13.28484+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:38:16.436494+00
599	351	14	event_created	2026-02-21 12:31:46.207902+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:48.134958+00
596	479	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:31.491271+00
1268	351	3	payment_confirmed	2026-03-08 09:40:06.418039+00	{"title": "SPACE", "amount": "9200.00", "eventId": 3, "orderId": "ae0625d7-7740-4ebc-a68e-9d074fc1c6ec", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-03-08 09:34:01.369447+00	2026-03-08 09:40:06.791401+00
597	485	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:32.482519+00
598	344	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:33.550866+00
1283	776	3	payment_confirmed	2026-05-21 06:30:09.449643+00	{"title": "SPACE", "amount": "6000.00", "eventId": 3, "orderId": "f2fe886e-6d0d-424c-9d0e-abf52bf990ff", "currency": "RUB"}	failed	3	telegram sendMessage status 400	2026-05-21 06:24:01.259092+00	2026-05-21 06:30:10.08158+00
1270	740	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-08 13:08:38.545358+00	2026-03-08 13:08:38.545358+00
1269	740	3	joined	2026-03-08 13:08:38.543395+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-03-08 13:08:38.543856+00	2026-03-08 13:08:39.472668+00
1285	1109	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-05-22 11:38:27.033072+00	2026-05-22 11:38:27.033072+00
417	313	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:29.100025+00
334	179	13	event_created	2026-02-21 11:36:21.685036+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:26.270391+00
433	380	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:50.323773+00
601	358	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:37.246848+00
1284	1109	3	joined	2026-05-22 11:40:31.736353+00	{"title": "SPACE", "eventId": 3}	sent	1	\N	2026-05-22 11:38:27.029171+00	2026-05-22 11:40:31.976756+00
1187	322	18	event_created	2026-02-21 23:31:00.141069+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:04.087363+00
1188	292	18	event_created	2026-02-21 23:31:01.706249+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:05.252207+00
1189	293	18	event_created	2026-02-21 23:31:04.04247+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:06.839902+00
1192	325	18	event_created	2026-02-21 23:31:04.909717+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:08.248212+00
1193	278	18	event_created	2026-02-21 23:31:06.374331+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:09.59212+00
1194	377	18	event_created	2026-02-21 23:31:07.910138+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:10.871792+00
1190	294	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:52.626413+00
1191	296	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:52.776918+00
333	8	13	event_created	2026-02-21 11:36:20.702991+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:25.164572+00
1272	766	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-03-09 07:50:38.701765+00	2026-03-09 07:50:38.701765+00
1271	766	3	joined	2026-03-09 07:50:38.700332+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-03-09 07:50:38.700621+00	2026-03-09 07:50:41.39495+00
604	346	14	event_created	2026-02-21 12:31:47.231682+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:49.058201+00
654	43	15	event_created	2026-02-21 13:25:16.921227+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:24.213896+00
603	368	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:38.703152+00
605	308	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:40.803524+00
1286	1	3	comment_added	2026-05-22 13:51:16.845711+00	{"title": "SPACE", "comment": "Оплатила, кинула в бот, а в ответ тишина 🔇. как быстро придёт qr?", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Окси"}	sent	0	\N	2026-05-22 13:51:16.846401+00	2026-05-22 13:51:33.170179+00
607	360	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:42.71489+00
376	225	13	event_created	2026-02-21 11:36:49.91287+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:51.236882+00
923	1	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:42.166233+00
924	254	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:42.606794+00
388	268	13	event_created	2026-02-21 11:37:05.2398+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:07.476515+00
925	399	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:43.023019+00
1274	875	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-04-14 13:42:44.290829+00	2026-04-14 13:42:44.290829+00
927	350	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:44.294768+00
928	387	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:44.753031+00
929	383	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:44.873975+00
922	369	16	event_created	2026-02-21 21:23:49.042993+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:59.192167+00
926	412	16	event_created	2026-02-21 21:23:50.030116+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:59.917941+00
1273	875	3	joined	2026-04-14 13:42:44.289268+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-04-14 13:42:44.289568+00	2026-04-14 13:42:44.981945+00
1288	1393	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-06-20 16:15:30.901032+00	2026-06-20 16:15:30.901032+00
1287	1393	3	joined	2026-06-20 16:15:30.8974+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-06-20 16:15:30.898618+00	2026-06-20 16:15:36.167419+00
1275	1	3	comment_added	2026-05-10 07:42:51.392153+00	{"title": "SPACE", "comment": "Добрый день!не работает промик,пишет usage limit reached", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "Александра"}	sent	0	\N	2026-05-10 07:42:51.392533+00	2026-05-10 07:43:01.660289+00
610	341	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:45.438034+00
1290	831	3	reminder_60m	2026-07-31 08:15:00+00	{"title": "SPACE", "eventId": 3}	pending	0	\N	2026-06-24 12:16:25.153942+00	2026-06-24 12:16:25.153942+00
1289	831	3	joined	2026-06-24 12:16:25.14988+00	{"title": "SPACE", "eventId": 3}	sent	0	\N	2026-06-24 12:16:25.151048+00	2026-06-24 12:16:30.493481+00
1291	1	3	payment_confirmed	2026-06-24 12:22:40.772895+00	{"title": "SPACE", "amount": "6500.00", "eventId": 3, "orderId": "0e240352-58d9-4356-b8e3-53a68cee5e45", "currency": "RUB"}	sent	1	\N	2026-06-24 12:20:35.967447+00	2026-06-24 12:22:41.080861+00
779	56	16	event_created	2026-02-21 21:21:59.606175+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:04.395353+00
781	374	16	event_created	2026-02-21 21:22:00.725389+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:06.074711+00
782	473	16	event_created	2026-02-21 21:22:01.842314+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:07.649995+00
784	61	16	event_created	2026-02-21 21:22:12.878148+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:18.774142+00
780	256	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:15:58.045043+00
783	474	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:00.791018+00
785	548	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:02.223098+00
791	145	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:09.051154+00
793	134	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:10.737136+00
795	204	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:11.577949+00
796	187	16	event_created	2026-02-21 21:22:21.954428+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:28.384962+00
1276	1	3	comment_added	2026-05-10 08:34:17.274+00	{"title": "SPACE", "comment": "Попробуйте еще раз, обновил!", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": ". ."}	sent	0	\N	2026-05-10 08:34:17.274249+00	2026-05-10 08:34:23.567827+00
613	237	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:48.234504+00
1292	1431	3	payment_confirmed	2026-06-25 07:54:45.846183+00	{"title": "SPACE", "amount": "7000.00", "eventId": 3, "orderId": "dae6f0ae-3b24-4c7c-ace4-8efec152bc1e", "currency": "RUB"}	failed	3	telegram sendMessage status 400: {"ok":false,"error_code":400,"description":"Bad Request: chat not found"}	2026-06-25 07:48:36.143752+00	2026-06-25 07:54:46.146117+00
532	242	14	event_created	2026-02-21 12:30:44.267014+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:53.718535+00
798	188	16	event_created	2026-02-21 21:22:24.462328+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:31.00985+00
805	191	16	event_created	2026-02-21 21:22:27.387387+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:36.226203+00
806	192	16	event_created	2026-02-21 21:22:28.440055+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:38.744317+00
799	124	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:17.20309+00
614	369	14	event_created	2026-02-21 12:31:51.742458+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:53.901116+00
801	199	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:18.349575+00
802	65	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:18.515033+00
803	190	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:18.822771+00
808	58	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:23.991071+00
812	137	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:27.842661+00
813	205	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:28.250658+00
810	198	16	event_created	2026-02-21 21:22:33.08764+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:42.429683+00
811	200	16	event_created	2026-02-21 21:22:34.10591+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:43.101051+00
1293	1	3	comment_added	2026-06-25 21:03:33.997138+00	{"title": "SPACE 31-3 AUG", "comment": "kyky", "eventId": 3, "apiBaseUrl": "https://spacefestival.fun/api", "commenterName": "HeresCo Service"}	sent	0	\N	2026-06-25 21:03:33.997893+00	2026-06-25 21:03:50.672406+00
815	224	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:29.267306+00
816	212	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:29.526966+00
576	294	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:14.25851+00
615	399	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:50.643122+00
616	350	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:52.127345+00
618	254	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:53.921581+00
619	383	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:55.495437+00
620	2	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:56.607803+00
621	133	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:57.25912+00
674	225	15	event_created	2026-02-21 13:25:23.299203+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:31.292331+00
487	47	14	event_created	2026-02-21 12:30:04.743138+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:07.349635+00
492	9	14	event_created	2026-02-21 12:30:09.123772+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:13.175083+00
533	243	14	event_created	2026-02-21 12:30:45.807875+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:54.163254+00
534	244	14	event_created	2026-02-21 12:30:46.765713+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:55.647801+00
536	268	14	event_created	2026-02-21 12:30:47.629416+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:56.470004+00
562	307	14	event_created	2026-02-21 12:31:04.24236+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:05.928261+00
575	293	14	event_created	2026-02-21 12:31:16.689517+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:18.663838+00
578	325	14	event_created	2026-02-21 12:31:23.361335+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:34.329729+00
581	380	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:19.259042+00
473	1	13	reminder_60m	2026-03-28 16:26:00+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13}	sent	0	\N	2026-02-21 11:29:37.864219+00	2026-03-28 16:26:09.941246+00
818	210	16	event_created	2026-02-21 21:22:36.274378+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:44.317636+00
526	227	14	event_created	2026-02-21 12:30:40.96192+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:51.190714+00
528	226	14	event_created	2026-02-21 12:30:41.759049+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:52.344046+00
544	276	14	event_created	2026-02-21 12:30:51.713425+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:02.38786+00
545	300	14	event_created	2026-02-21 12:30:52.504689+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:03.830812+00
460	1	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:32:00.893188+00
579	278	14	event_created	2026-02-21 12:31:21.355597+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:22.746261+00
580	377	14	event_created	2026-02-21 12:31:22.507556+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:23.290364+00
434	329	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:51.426631+00
435	389	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:52.114089+00
436	66	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:53.067553+00
437	334	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:54.099089+00
682	243	15	event_created	2026-02-21 13:25:31.698801+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:36.895091+00
685	268	15	event_created	2026-02-21 13:25:35.517713+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:38.593776+00
686	261	15	event_created	2026-02-21 13:25:37.17875+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:40.071149+00
689	250	15	event_created	2026-02-21 13:25:38.620646+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:41.18593+00
622	48	14	joined	2026-02-21 12:25:22.829626+00	{"title": "Масленница", "eventId": 14}	sent	0	\N	2026-02-21 12:25:22.830498+00	2026-02-21 12:25:57.532428+00
820	238	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:32.086802+00
439	335	13	event_created	2026-02-21 11:36:13.26908+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:15.563879+00
340	180	13	event_created	2026-02-21 11:36:24.745676+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:29.59942+00
640	187	15	event_created	2026-02-21 13:25:04.962613+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:13.520945+00
493	188	14	event_created	2026-02-21 12:30:10.206726+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:14.215868+00
496	132	14	event_created	2026-02-21 12:30:11.166797+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:14.951364+00
500	7	14	event_created	2026-02-21 12:30:12.142984+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:17.118075+00
694	276	15	event_created	2026-02-21 13:25:42.270871+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:54.064136+00
505	43	14	event_created	2026-02-21 12:30:15.611072+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:25.750417+00
586	335	14	event_created	2026-02-21 12:31:24.303977+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:35.086781+00
440	404	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:56.450085+00
606	357	14	event_created	2026-02-21 12:31:47.963649+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:49.694558+00
327	256	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:59.205192+00
612	412	14	event_created	2026-02-21 12:31:49.4646+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:51.607507+00
336	331	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:08.320034+00
337	145	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:09.353097+00
339	134	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:11.6306+00
592	386	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:28.31437+00
595	340	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:30.435011+00
600	355	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:36.446244+00
608	361	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:43.671768+00
609	1	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:44.673224+00
602	365	14	event_created	2026-02-21 12:31:48.793503+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:50.481193+00
342	187	13	event_created	2026-02-21 11:36:25.428852+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:30.347837+00
353	192	13	event_created	2026-02-21 11:36:31.259401+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:35.864873+00
354	193	13	event_created	2026-02-21 11:36:32.04531+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:38.160493+00
356	43	13	event_created	2026-02-21 11:36:32.983517+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:38.535876+00
345	138	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:18.233788+00
346	124	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:18.975171+00
348	199	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:20.643112+00
349	65	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:21.33377+00
350	190	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:21.782697+00
355	58	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:26.301923+00
359	137	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:29.265902+00
357	198	13	event_created	2026-02-21 11:36:34.604748+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:39.223734+00
365	210	13	event_created	2026-02-21 11:36:36.640975+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:39.983883+00
482	178	14	event_created	2026-02-21 12:30:02.58385+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:07.769768+00
375	233	13	event_created	2026-02-21 11:36:48.917301+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:52.221288+00
611	379	14	event_created	2026-02-21 12:31:50.127247+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:52.823969+00
361	48	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:31.342277+00
362	224	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:31.791814+00
363	207	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:33.256493+00
1105	204	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:33.414123+00
364	209	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:34.514747+00
366	343	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:35.963042+00
367	281	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:36.686122+00
368	212	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:37.842327+00
369	217	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:38.434774+00
370	213	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:39.105698+00
371	258	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:40.013867+00
372	238	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:40.626087+00
373	232	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:41.817218+00
374	215	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:42.60681+00
378	474	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:45.631103+00
1294	1514	3	payment_confirmed	2026-06-29 07:36:16.637805+00	{"title": "SPACE 31-3 AUG", "amount": "6500.00", "eventId": 3, "orderId": "0afe14a6-36c3-4e89-975c-0e6b32f56294", "currency": "RUB"}	failed	3	telegram sendMessage status 400: {"ok":false,"error_code":400,"description":"Bad Request: chat not found"}	2026-06-29 07:30:15.745567+00	2026-06-29 07:36:16.893858+00
824	232	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:34.354748+00
485	51	14	event_created	2026-02-21 12:30:04.357256+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:08.597807+00
574	292	14	event_created	2026-02-21 12:31:15.299503+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:17.850819+00
380	226	13	event_created	2026-02-21 11:36:51.146817+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:53.864239+00
384	242	13	event_created	2026-02-21 11:36:52.600657+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:55.440389+00
385	243	13	event_created	2026-02-21 11:37:03.405696+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:08.880127+00
381	214	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:47.892598+00
382	239	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:49.238076+00
387	264	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:56.078046+00
389	261	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:58.081289+00
390	245	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:30:58.880965+00
391	247	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:00.525942+00
393	251	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:02.374306+00
394	253	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:03.686086+00
395	252	13	event_created	2026-02-21 11:37:07.390542+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:10.944728+00
396	276	13	event_created	2026-02-21 11:37:08.276961+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:12.041565+00
397	300	13	event_created	2026-02-21 11:37:09.063296+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 403	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:12.678707+00
413	307	13	event_created	2026-02-21 11:37:29.511521+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:37:34.743803+00
652	193	15	event_created	2026-02-21 13:25:15.562863+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:22.814661+00
399	321	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:10.414295+00
400	3	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:11.499788+00
401	317	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:12.183476+00
402	272	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:13.256823+00
403	384	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:14.454009+00
404	319	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:15.152298+00
405	269	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:16.275304+00
406	274	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:16.991797+00
407	375	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:17.965521+00
408	282	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:18.844296+00
409	283	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:19.801836+00
410	311	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:20.653492+00
411	305	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:22.249742+00
412	312	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:23.342049+00
414	298	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:25.382395+00
416	324	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:31:27.783689+00
438	349	13	event_created	2026-02-21 11:29:37.847334+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	sent	0	\N	2026-02-21 11:29:37.848517+00	2026-02-21 11:29:54.764536+00
764	412	15	event_created	2026-02-21 13:26:43.564936+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:52.324064+00
325	231	13	event_created	2026-02-21 11:36:23.714464+00	{"title": "☄️10 YEARS of PRALAYAH ☄️", "eventId": 13, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771673374264956158-scaled_2026-02-21-14.29.21.jpg", "startsAt": "2026-03-28T17:26:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "55.76625, 37.60512"}	failed	3	telegram sendMessage status 400	2026-02-21 11:29:37.848517+00	2026-02-21 11:36:31.636361+00
655	198	15	event_created	2026-02-21 13:25:18.347141+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:25.914049+00
656	200	15	event_created	2026-02-21 13:25:19.423251+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:26.652653+00
673	233	15	event_created	2026-02-21 13:25:22.337411+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:30.304671+00
829	233	16	event_created	2026-02-21 21:22:38.408646+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:47.604549+00
827	48	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:35.128092+00
828	281	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:35.291132+00
832	213	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:38.907175+00
833	484	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:39.335934+00
835	214	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:40.240811+00
836	239	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:40.699324+00
831	227	16	event_created	2026-02-21 21:22:40.73346+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:49.459465+00
834	226	16	event_created	2026-02-21 21:22:41.360817+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:50.199997+00
837	236	16	event_created	2026-02-21 21:22:52.34603+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:02.039717+00
838	242	16	event_created	2026-02-21 21:22:53.520416+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:03.498252+00
754	357	15	event_created	2026-02-21 13:26:30.058615+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:38.664976+00
1088	56	18	event_created	2026-02-21 23:29:34.939311+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:42.082814+00
1089	256	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:17.350237+00
681	242	15	event_created	2026-02-21 13:25:30.63392+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:35.796485+00
840	244	16	event_created	2026-02-21 21:22:55.424757+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:07.138012+00
692	252	15	event_created	2026-02-21 13:25:40.458485+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:42.219595+00
847	252	16	event_created	2026-02-21 21:22:59.782518+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:11.399585+00
722	292	15	event_created	2026-02-21 13:25:52.582338+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:05.668508+00
728	377	15	event_created	2026-02-21 13:25:57.420234+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:09.994247+00
737	337	15	event_created	2026-02-21 13:26:02.890751+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:13.921112+00
841	264	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:46.254979+00
844	245	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:48.918992+00
846	253	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:50.622903+00
848	331	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:52.235425+00
851	295	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:55.296723+00
849	276	16	event_created	2026-02-21 21:23:01.330398+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:12.775592+00
850	300	16	event_created	2026-02-21 21:23:02.526286+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:13.846927+00
475	56	14	event_created	2026-02-21 12:29:57.905441+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:03.553103+00
477	374	14	event_created	2026-02-21 12:29:59.005412+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:05.032296+00
617	387	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:52.963238+00
478	473	14	event_created	2026-02-21 12:30:00.19123+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:05.591603+00
480	61	14	event_created	2026-02-21 12:30:00.958635+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:06.47738+00
626	374	15	event_created	2026-02-21 13:24:46.799216+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:24:56.360715+00
627	473	15	event_created	2026-02-21 13:24:48.195161+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:24:57.724843+00
629	61	15	event_created	2026-02-21 13:24:49.963081+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:24:58.56434+00
630	323	15	event_created	2026-02-21 13:24:51.659119+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:24:59.583712+00
641	9	15	event_created	2026-02-21 13:25:06.583158+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:15.070504+00
642	188	15	event_created	2026-02-21 13:25:07.911682+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:16.846545+00
645	132	15	event_created	2026-02-21 13:25:09.136563+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:18.128394+00
476	256	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:23:41.73001+00
649	7	15	event_created	2026-02-21 13:25:10.174972+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:18.988132+00
650	191	15	event_created	2026-02-21 13:25:12.566768+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:20.155961+00
479	474	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:23:45.181898+00
486	145	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:23:51.789816+00
488	134	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:23:53.748656+00
680	236	15	event_created	2026-02-21 13:25:28.626887+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:34.647106+00
491	187	14	event_created	2026-02-21 12:30:08.449885+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:18.909964+00
854	317	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:56.043854+00
856	272	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:57.347051+00
857	138	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:57.586961+00
858	384	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:57.875142+00
506	198	14	event_created	2026-02-21 12:30:16.474496+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:22.560985+00
507	200	14	event_created	2026-02-21 12:30:17.228034+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:23.113752+00
502	192	14	event_created	2026-02-21 12:30:13.889876+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:24.185046+00
503	193	14	event_created	2026-02-21 12:30:14.646908+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:24.708561+00
490	204	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:23:56.951638+00
494	138	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:01.352866+00
495	124	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:02.154444+00
497	199	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:03.681787+00
498	65	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:04.406621+00
499	190	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:05.185757+00
504	58	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:10.613919+00
508	137	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:13.900903+00
511	207	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:16.42369+00
512	212	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:16.949716+00
675	227	15	event_created	2026-02-21 13:25:24.830257+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:32.284879+00
860	274	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:58.49615+00
481	323	14	event_created	2026-02-21 12:30:01.918862+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:09.593984+00
524	233	14	event_created	2026-02-21 12:30:28.923417+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:39.062618+00
525	225	14	event_created	2026-02-21 12:30:39.939412+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:57.986056+00
510	224	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:15.945765+00
513	209	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:17.934707+00
515	281	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:19.833852+00
516	343	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:20.502044+00
517	217	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:21.277743+00
518	213	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:21.922714+00
519	258	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:22.753633+00
520	238	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:23.671515+00
521	232	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:24.780303+00
522	215	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:25.606693+00
523	48	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:27.096897+00
527	484	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:31.176151+00
683	244	15	event_created	2026-02-21 13:25:33.946745+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:37.963063+00
700	319	15	event_created	2026-02-21 13:25:45.346917+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:56.200582+00
862	282	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:59.073924+00
863	283	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:59.570862+00
864	311	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:59.914796+00
531	236	14	event_created	2026-02-21 12:30:43.235195+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:58.63596+00
537	261	14	event_created	2026-02-21 12:30:48.616258+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:59.243541+00
540	250	14	event_created	2026-02-21 12:30:49.987206+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:00.534604+00
543	252	14	event_created	2026-02-21 12:30:50.961755+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:01.549537+00
530	239	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:34.68649+00
535	264	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:39.385992+00
538	245	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:41.881511+00
539	247	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:42.650152+00
541	251	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:44.331037+00
542	253	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:45.083937+00
546	295	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:48.542514+00
547	321	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:49.319192+00
548	3	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:50.046197+00
866	312	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:00.819047+00
551	319	14	event_created	2026-02-21 12:31:03.484147+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:05.36664+00
565	309	14	event_created	2026-02-21 12:31:17.386101+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:19.406059+00
568	273	14	event_created	2026-02-21 12:31:18.960296+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:20.00612+00
550	317	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:51.903109+00
552	272	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:53.13798+00
553	384	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:53.885213+00
554	331	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:54.753363+00
555	274	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:55.458298+00
556	375	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:56.834881+00
557	282	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:57.255336+00
558	283	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:58.08541+00
559	311	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:58.974357+00
560	305	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:59.563106+00
561	312	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:00.24649+00
563	298	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:02.524764+00
564	348	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:03.494508+00
566	324	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:05.918557+00
567	313	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:06.878104+00
723	293	15	event_created	2026-02-21 13:25:53.569203+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:06.495562+00
870	309	16	event_created	2026-02-21 21:23:06.962338+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:17.467371+00
484	179	14	event_created	2026-02-21 12:30:03.4028+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:10.065795+00
474	231	14	event_created	2026-02-21 12:30:05.566717+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:10.790865+00
509	205	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:24:15.061462+00
868	298	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:02.670846+00
570	314	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:09.901194+00
571	288	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:10.815002+00
572	318	14	event_created	2026-02-21 12:23:25.681747+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	sent	0	\N	2026-02-21 12:23:25.682947+00	2026-02-21 12:25:11.39878+00
869	348	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:03.086841+00
483	8	14	event_created	2026-02-21 12:30:06.366854+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:12.45183+00
489	180	14	event_created	2026-02-21 12:30:07.654157+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:20.537972+00
871	315	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:04.919045+00
724	294	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:36.726957+00
872	324	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:05.323798+00
501	191	14	event_created	2026-02-21 12:30:12.754785+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 400	2026-02-21 12:23:25.682947+00	2026-02-21 12:30:26.705473+00
569	286	14	event_created	2026-02-21 12:31:19.608256+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:20.623087+00
573	322	14	event_created	2026-02-21 12:31:20.389599+00	{"title": "Масленница", "eventId": 14, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771676598398519930-scaled_4.jpeg", "startsAt": "2026-02-21T13:21:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.49690, 34.16994"}	failed	3	telegram sendMessage status 403	2026-02-21 12:23:25.682947+00	2026-02-21 12:31:21.73269+00
1099	51	18	event_created	2026-02-21 23:29:38.585916+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:44.279665+00
814	207	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:28.839904+00
817	209	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:29.919015+00
819	343	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:31.866824+00
822	217	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:33.490974+00
823	258	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:33.934898+00
825	247	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:34.766808+00
826	215	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:34.99106+00
873	313	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:05.810834+00
876	314	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:08.542504+00
877	288	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:09.262973+00
778	231	16	event_created	2026-02-21 21:21:58.432533+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:03.11237+00
790	51	16	event_created	2026-02-21 21:22:18.82654+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:24.426392+00
797	9	16	event_created	2026-02-21 21:22:23.170728+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:29.673825+00
809	43	16	event_created	2026-02-21 21:22:31.842161+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:41.235649+00
821	524	16	event_created	2026-02-21 21:22:37.422295+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:22:46.091032+00
874	273	16	event_created	2026-02-21 21:23:17.810371+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:28.94795+00
875	286	16	event_created	2026-02-21 21:23:18.420075+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:29.873762+00
839	243	16	event_created	2026-02-21 21:22:54.258403+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:05.034185+00
1102	47	18	event_created	2026-02-21 23:29:39.273155+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:45.335563+00
1106	187	18	event_created	2026-02-21 23:29:53.44983+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:57.463697+00
1107	9	18	event_created	2026-02-21 23:29:55.525813+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:58.595132+00
1101	145	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:29.76993+00
1103	134	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:31.814114+00
1109	124	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:38.250019+00
1111	199	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:39.900064+00
1112	65	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:40.710237+00
1113	190	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:41.092113+00
1118	58	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:47.209958+00
767	350	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:40.733944+00
852	321	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:55.522929+00
853	318	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:55.831108+00
859	251	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:58.332983+00
861	375	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:16:58.947693+00
865	305	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:00.398917+00
771	412	15	reminder_60m	2026-02-22 13:21:10.755214+00	{"title": "Поход на Гору Медведь", "eventId": 15}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.586998+00	2026-02-22 13:21:11.382191+00
1120	198	18	event_created	2026-02-21 23:30:03.57506+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:05.92362+00
1121	200	18	event_created	2026-02-21 23:30:08.326044+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:19.16353+00
881	294	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:14.39549+00
625	256	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:23.17375+00
882	296	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:14.610697+00
628	474	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:26.414379+00
635	145	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:33.075737+00
855	319	16	event_created	2026-02-21 21:23:03.343648+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:15.057992+00
867	307	16	event_created	2026-02-21 21:23:05.136029+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:16.500363+00
879	292	16	event_created	2026-02-21 21:23:20.730219+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:31.856609+00
884	278	16	event_created	2026-02-21 21:23:25.11991+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:35.005259+00
885	377	16	event_created	2026-02-21 21:23:26.219295+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:35.873327+00
895	337	16	event_created	2026-02-21 21:23:31.138408+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:41.399249+00
638	180	15	event_created	2026-02-21 13:25:04.121941+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:12.36033+00
1123	205	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:52.685952+00
1124	224	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:53.606209+00
888	351	16	event_created	2026-02-21 21:23:27.108905+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:37.215535+00
887	329	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:20.334902+00
889	66	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:22.158895+00
890	255	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:22.770345+00
893	404	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:25.162042+00
639	204	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:38.236852+00
897	382	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:30.35068+00
643	138	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:44.211524+00
644	124	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:44.826149+00
892	335	16	event_created	2026-02-21 21:23:29.105313+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:39.360506+00
646	199	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:48.080512+00
647	65	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:48.704748+00
648	190	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:50.060196+00
653	58	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:55.17221+00
663	210	15	event_created	2026-02-21 13:25:20.482291+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:29.215834+00
899	336	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:30.757257+00
900	340	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:31.197165+00
657	137	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:01.517199+00
658	205	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:02.544084+00
659	207	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:03.869568+00
660	224	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:04.55175+00
661	212	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:05.644032+00
662	209	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:07.608615+00
664	343	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:09.585341+00
665	238	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:10.967544+00
666	217	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:12.232534+00
667	213	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:13.49407+00
668	258	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:14.60134+00
669	232	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:15.945837+00
670	215	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:16.84385+00
671	48	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:18.704488+00
672	281	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:20.492524+00
907	365	16	event_created	2026-02-21 21:23:43.250399+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:53.798802+00
677	226	15	event_created	2026-02-21 13:25:26.367033+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:33.652009+00
902	485	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:31.514517+00
903	344	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:31.95081+00
904	368	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:32.514855+00
905	355	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:32.814532+00
906	389	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:33.234738+00
908	334	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:34.639109+00
909	358	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:35.038811+00
676	484	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:25.708034+00
678	214	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:28.435698+00
679	239	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:30.084207+00
684	264	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:39.980227+00
687	245	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:45.612276+00
688	247	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:46.841131+00
690	251	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:49.405873+00
691	253	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:51.148289+00
693	331	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:54.076276+00
911	346	16	event_created	2026-02-21 21:23:44.366186+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:54.726591+00
695	300	15	event_created	2026-02-21 13:25:43.499801+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:55.051949+00
710	307	15	event_created	2026-02-21 13:25:46.763112+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:57.708194+00
696	295	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:56.723541+00
697	321	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:57.406028+00
698	318	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:58.764216+00
699	317	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:18:59.651975+00
701	272	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:02.480024+00
702	384	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:03.587936+00
703	274	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:04.686599+00
704	375	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:06.092408+00
705	282	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:07.467784+00
706	283	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:09.174977+00
707	311	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:11.088135+00
708	305	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:12.679287+00
709	312	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:14.380127+00
711	298	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:16.975989+00
712	348	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:18.855905+00
1129	343	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:57.415712+00
913	308	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:36.318879+00
915	360	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:37.9509+00
916	361	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:38.451019+00
637	134	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:17:35.187967+00
917	552	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:38.835979+00
918	2	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:38.942524+00
714	315	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:22.031818+00
715	324	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:22.739898+00
716	313	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:23.967404+00
719	314	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:28.241962+00
720	288	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:30.670481+00
651	192	15	event_created	2026-02-21 13:25:14.291874+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:21.308281+00
772	138	15	joined	2026-02-21 13:18:33.936111+00	{"title": "Поход на Гору Медведь", "eventId": 15}	sent	0	\N	2026-02-21 13:18:33.937058+00	2026-02-21 13:19:34.593381+00
725	296	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:37.938961+00
713	309	15	event_created	2026-02-21 13:25:48.045384+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:59.404249+00
717	273	15	event_created	2026-02-21 13:25:48.914796+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:00.879177+00
718	286	15	event_created	2026-02-21 13:25:50.306472+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:02.481687+00
721	322	15	event_created	2026-02-21 13:25:51.780626+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:03.907198+00
920	379	16	event_created	2026-02-21 21:23:47.89359+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 400	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:57.972119+00
921	237	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:40.982726+00
727	278	15	event_created	2026-02-21 13:25:56.189358+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:08.883738+00
734	349	15	event_created	2026-02-21 13:25:58.836965+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:11.080603+00
735	335	15	event_created	2026-02-21 13:26:01.190474+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:12.840573+00
729	380	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:43.735782+00
730	329	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:44.873798+00
731	389	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:46.796119+00
732	66	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:47.531364+00
733	255	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:49.199804+00
736	404	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:53.579937+00
738	382	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:56.303637+00
739	386	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:57.016816+00
740	269	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:19:58.240411+00
741	336	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:00.17186+00
742	340	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:01.999707+00
743	479	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:03.055519+00
744	334	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:04.779552+00
755	360	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:22.411161+00
756	361	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:24.674042+00
757	2	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:26.607748+00
758	341	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:27.952012+00
760	1	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:31.084032+00
761	237	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:33.292083+00
747	351	15	event_created	2026-02-21 13:26:14.606741+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:24.990021+00
750	365	15	event_created	2026-02-21 13:26:16.019105+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 403	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:26.412722+00
931	133	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:46.893918+00
752	346	15	event_created	2026-02-21 13:26:27.750596+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:37.346093+00
759	379	15	event_created	2026-02-21 13:26:31.818808+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:39.856501+00
762	369	15	event_created	2026-02-21 13:26:42.774448+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:50.888644+00
746	344	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:07.672882+00
748	355	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:10.169391+00
749	358	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:11.787464+00
751	368	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:15.467525+00
753	308	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:18.528137+00
763	383	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:35.424177+00
886	380	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:19.599214+00
898	386	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:30.606835+00
901	479	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:31.349149+00
1133	258	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:00.581999+00
891	349	16	event_created	2026-02-21 21:23:27.840825+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	failed	3	telegram sendMessage status 403	2026-02-21 21:15:47.405966+00	2026-02-21 21:23:38.241511+00
765	254	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:38.086601+00
766	399	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:39.408782+00
768	387	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:41.963715+00
769	3	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:43.403786+00
770	133	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:44.83744+00
624	56	15	event_created	2026-02-21 13:24:45.550972+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:24:55.266218+00
631	178	15	event_created	2026-02-21 13:24:53.823349+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:00.652412+00
632	8	15	event_created	2026-02-21 13:24:55.24193+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:03.272299+00
633	179	15	event_created	2026-02-21 13:24:57.209897+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:05.097033+00
634	51	15	event_created	2026-02-21 13:24:59.051148+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:07.367976+00
636	47	15	event_created	2026-02-21 13:25:01.263116+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:08.904344+00
623	231	15	event_created	2026-02-21 13:25:02.991063+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:25:09.846062+00
726	325	15	event_created	2026-02-21 13:25:54.648564+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	failed	3	telegram sendMessage status 400	2026-02-21 13:17:05.57288+00	2026-02-21 13:26:07.525522+00
745	485	15	event_created	2026-02-21 13:17:05.571739+00	{"title": "Поход на Гору Медведь", "eventId": 15, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771679819297410281-scaled_bg3.png", "startsAt": "2026-02-22T14:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "44.56974, 34.32502"}	sent	0	\N	2026-02-21 13:17:05.57288+00	2026-02-21 13:20:06.499473+00
910	269	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:35.278963+00
912	3	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:36.154636+00
919	341	16	event_created	2026-02-21 21:15:47.40496+00	{"title": "Тишина", "eventId": 16, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771708478369494826-scaled_IMG_3804.jpeg", "startsAt": "2026-02-21T22:15:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.72009, 20.48123"}	sent	0	\N	2026-02-21 21:15:47.405966+00	2026-02-21 21:17:39.260989+00
1139	233	18	event_created	2026-02-21 23:30:09.580941+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:20.104776+00
1144	226	18	event_created	2026-02-21 23:30:16.586355+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:26.136059+00
1147	236	18	event_created	2026-02-21 23:30:17.821768+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:27.051172+00
1149	243	18	event_created	2026-02-21 23:30:20.993633+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:29.026776+00
1135	247	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:01.090776+00
1136	215	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:01.192549+00
1137	48	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:01.505964+00
1138	281	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:01.926718+00
1142	213	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:06.822288+00
1143	484	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:08.03871+00
1145	214	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:10.322733+00
1146	239	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:10.726127+00
1152	268	18	event_created	2026-02-21 23:30:25.162151+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:30.715204+00
1157	252	18	event_created	2026-02-21 23:30:29.990077+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:33.810544+00
1159	276	18	event_created	2026-02-21 23:30:31.590075+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:34.879819+00
1160	300	18	event_created	2026-02-21 23:30:32.372832+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:35.955934+00
1165	319	18	event_created	2026-02-21 23:30:33.199315+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:36.952707+00
1151	264	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:18.146382+00
1154	245	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:21.396804+00
1156	253	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:23.558025+00
1158	331	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:26.085996+00
1161	295	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:29.194478+00
1162	321	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:29.862118+00
1163	318	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:30.502034+00
1164	317	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:31.398061+00
1166	272	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:32.262131+00
1167	138	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:33.030097+00
1168	384	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:33.482105+00
1169	251	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:34.310165+00
1087	231	18	event_created	2026-02-21 23:29:42.437895+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:47.799785+00
1177	307	18	event_created	2026-02-21 23:30:44.428087+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:48.435579+00
1180	309	18	event_created	2026-02-21 23:30:46.318031+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:50.560766+00
1183	273	18	event_created	2026-02-21 23:30:47.723008+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:51.394849+00
1184	286	18	event_created	2026-02-21 23:30:49.187147+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:52.95626+00
1092	474	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:19.935143+00
1171	375	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:34.950073+00
1172	282	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:35.090461+00
1173	283	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:35.782134+00
1174	311	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:36.234127+00
1175	305	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:36.870096+00
1176	312	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:36.943299+00
1178	298	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:39.366208+00
1179	348	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:39.941905+00
1181	324	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:42.346114+00
1182	313	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:42.745071+00
1185	314	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:47.17413+00
1186	288	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:47.814146+00
1094	548	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:21.962204+00
1093	61	18	event_created	2026-02-21 23:29:44.973795+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:49.751768+00
1095	323	18	event_created	2026-02-21 23:29:46.797917+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:51.095921+00
1096	178	18	event_created	2026-02-21 23:29:48.361974+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:53.125142+00
1100	315	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:29.382381+00
1122	137	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:52.029357+00
1125	212	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:54.286053+00
1126	209	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:54.954148+00
1128	207	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:57.023239+00
1130	238	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:23:58.278085+00
1132	217	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:00.202193+00
1134	232	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:00.898016+00
1097	8	18	event_created	2026-02-21 23:29:49.889243+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:54.404719+00
1098	179	18	event_created	2026-02-21 23:29:51.157319+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:56.041759+00
1117	193	18	event_created	2026-02-21 23:30:05.430454+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:06.682226+00
1119	43	18	event_created	2026-02-21 23:30:07.199205+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:18.075914+00
1127	210	18	event_created	2026-02-21 23:30:13.804721+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:23.180701+00
1150	244	18	event_created	2026-02-21 23:30:23.142174+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:30:29.842285+00
1205	549	18	event_created	2026-02-21 23:31:20.710146+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:28.599793+00
1216	365	18	event_created	2026-02-21 23:31:21.930016+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 403	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:30.900721+00
1206	382	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:11.110122+00
1207	386	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:11.642398+00
1208	336	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:12.042172+00
1209	340	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:12.458174+00
1210	479	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:12.934095+00
1211	485	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:13.414071+00
1212	344	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:13.994374+00
1213	368	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:14.534354+00
1214	355	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:15.082357+00
1215	389	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:15.220557+00
1217	334	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:17.706251+00
1218	358	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:17.853186+00
1219	269	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:18.438196+00
1221	3	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:20.262211+00
1222	308	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:20.682132+00
1204	337	18	event_created	2026-02-21 23:31:18.694044+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:27.013327+00
1229	379	18	event_created	2026-02-21 23:31:35.832204+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:31:46.551898+00
1195	380	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:24:58.214189+00
1224	360	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:22.933701+00
1225	361	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:23.015394+00
1226	552	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:23.4741+00
1227	2	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:23.867195+00
1228	341	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:24.55607+00
1230	237	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:26.470028+00
1232	383	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:28.371165+00
1233	254	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:28.444856+00
1234	1	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:29.318016+00
1235	399	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:30.058094+00
1237	350	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:31.089486+00
1238	387	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:32.042013+00
1240	133	18	event_created	2026-02-21 23:22:47.928269+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	sent	0	\N	2026-02-21 23:22:47.929265+00	2026-02-21 23:25:33.834051+00
1090	374	18	event_created	2026-02-21 23:29:37.061994+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:43.106197+00
1104	180	18	event_created	2026-02-21 23:29:41.545899+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:46.395826+00
1091	473	18	event_created	2026-02-21 23:29:43.936535+00	{"title": "Bustation", "eventId": 18, "photoUrl": "http://minio:9000/gigme/events/2026/02/21/1771716101713842877-scaled_IMG_3806.jpeg", "startsAt": "2026-02-22T00:22:00.000Z", "apiBaseUrl": "https://spacefestival.fun/api", "addressLabel": "54.70748, 20.50281"}	failed	3	telegram sendMessage status 400	2026-02-21 23:22:47.929265+00	2026-02-21 23:29:48.645559+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.order_items (id, order_id, item_type, product_id, product_ref, quantity, unit_price_cents, line_total_cents, meta_json, created_at) FROM stdin;
2	7efc7010-5da9-4c9a-9241-e6e60d3a10e2	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 11:54:52.07225+00
3	bd328e17-14da-4a01-8dd6-fef503988fbe	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 12:00:25.156081+00
4	f22be794-32aa-4a0a-a9bb-c5613be51a96	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 12:01:56.901521+00
5	0d1e78dd-4282-404c-8bab-d7d7090d82f4	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 13:52:07.801861+00
6	c346f744-ec97-4276-8829-1c68703f0315	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 14:11:18.711123+00
8	be316b60-9982-4b17-8d01-83ae67104eef	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-14 16:50:25.846296+00
9	69c74d6e-c804-4928-b734-a3391640112f	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-15 03:22:51.579215+00
10	b44ba145-0a44-40e3-85ea-2e172f822b5b	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-17 17:23:23.20965+00
11	aa09e3e1-3ae2-4670-a56e-a6857b705c4d	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-19 09:20:04.309993+00
12	a2139c42-09c7-4e74-8c48-127f7136b90d	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-19 09:28:08.533822+00
16	b2b2dd7a-4ac1-4403-8983-d400c1701c00	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-19 11:50:45.157442+00
17	a8fa67ed-27ac-4ac6-a885-a4049dfc6df3	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-20 11:05:08.294549+00
18	e4681fe4-9346-423b-8525-64ab3b4e6a2d	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-20 11:42:57.640715+00
20	e7dfb063-9a7c-4ba3-b044-26cc2bcb2783	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-20 21:37:13.803305+00
21	280398e0-3572-4a34-a4b3-6bf46066a46a	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-20 22:03:41.694531+00
23	eac41a7a-d4fe-4996-b2ab-7463c09ef3f1	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-25 11:00:43.738335+00
25	9227cccc-2f83-4e32-9a79-d960b5da4b72	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-25 17:23:11.532731+00
26	e15f599e-da23-4c3f-85c6-de93e1d424d5	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-27 13:40:50.422309+00
27	5af4bdb8-d627-451f-b6d2-8d2106fc8ebb	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-27 17:23:48.496656+00
28	c79bcd8a-9622-4ffa-81fc-f8f0c1741128	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-02-28 17:19:05.409558+00
32	dfbd52ba-c68d-4da2-9605-b5ece89d1193	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	3	500000	1500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-04 23:18:06.223169+00
33	a05893ee-a7ed-4cc7-95f5-ecfc912332a7	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-06 15:58:48.834834+00
34	d99efd31-b24c-4fb4-b3a3-055e7c8c9af9	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-06 16:08:38.694904+00
35	0a70c9ad-4279-4dcf-b7d8-3c01ae069593	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-06 16:38:37.184433+00
36	1095dfe4-41aa-4a3c-ac72-7a185f551f86	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-06 17:56:23.001573+00
37	34ac1591-a2b4-4702-aeca-139c9328faa3	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-06 18:18:01.060816+00
38	a91884f3-49f2-44bc-be06-1aec61654126	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-07 06:41:35.364537+00
39	5537ec32-c138-4fbb-b4cb-c5651ad130da	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-07 11:30:56.452006+00
40	b8f8abdd-657c-48eb-90d7-0c64b4bb39a2	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-07 16:21:26.132099+00
41	6beb44ab-939e-428e-9130-f369bf5bf8f6	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 06:37:30.043889+00
42	ae0625d7-7740-4ebc-a68e-9d074fc1c6ec	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 08:11:36.08667+00
43	234970fe-2761-433c-9a1d-0888f096569c	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 11:05:45.504983+00
44	5fc5bf35-c2f2-46be-9b0e-f02b839915f9	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 16:59:47.959246+00
45	306edbfe-0fc1-44de-94f4-66814ef2ac91	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	1	500000	500000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 18:27:11.099943+00
46	c1bfbac7-41dc-416e-897f-2d156d4cfe1c	TICKET	8459aa0d-0376-449a-a310-af640087c7c8	SINGLE	2	500000	1000000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-08 20:25:41.323883+00
47	233e0295-afc2-4b53-bcd4-de58ccf66645	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-14 09:40:29.708107+00
48	375697b5-9c62-4aa8-9950-b094308d53fc	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-03-22 20:11:28.042809+00
50	ff9e95d3-fd26-49c8-8a84-d8804aa50432	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-09 15:06:31.812305+00
51	16cdbbaa-67bb-46df-a624-1a13f1721c17	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-10 08:34:38.664298+00
52	425b82df-11ae-4344-8185-066de39aec31	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-13 10:51:20.555077+00
53	284e5ef2-85f3-4e36-beb2-cde3dd5d58d9	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-13 15:23:52.808964+00
58	5c83fbe5-206c-4e2f-9b13-3be9028d3f6c	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-16 15:48:44.211789+00
59	58df1160-42a8-444f-8163-cc0c5e096075	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 00:06:06.829159+00
60	27af3a9f-cf21-4274-8de2-07e9105afc11	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 10:15:00.380576+00
61	a2aeb09a-523f-49de-b465-0db59a1e0e75	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 10:23:27.031971+00
62	4a6d58f8-3961-4add-abc6-ff73f5f7cdb2	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 10:24:15.485632+00
63	acd10364-1fec-4863-8147-751445be21dd	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 10:25:39.549733+00
64	258fb17b-fea1-4755-b9ee-e6e74f460a8f	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 14:53:14.275906+00
65	79123277-59c3-4f80-8442-40a3b3423cda	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-17 14:55:37.647825+00
66	7f60f4df-53c6-4275-ad23-979fd4532749	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-05-18 19:53:35.575573+00
68	8ec79aa3-8e1c-47a8-985d-fe034425095a	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-05-19 16:02:16.477343+00
67	102cf71c-16d0-4c9e-ac7f-871eca176aa5	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-05-19 08:00:20.824007+00
57	70c3708e-6b7f-4fd5-b2d9-3751bc6d5eb1	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-05-16 13:07:53.332832+00
69	06030764-bce2-47db-a612-f6ebce438c76	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-20 13:19:32.531643+00
70	b76fda27-0478-4901-b6ce-53e3ce9cb6b3	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	2	650000	1300000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-20 17:57:09.627384+00
71	f2fe886e-6d0d-424c-9d0e-abf52bf990ff	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-21 05:54:35.815086+00
72	1a0d3e3c-7097-4f04-8f7a-2fc604b3d438	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-21 07:40:10.687376+00
73	008e6d98-071d-4577-8d5f-c8880777aa7f	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-22 12:58:47.189934+00
74	f826428f-03f1-42e7-8b49-9cece6730c32	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-27 15:02:53.608635+00
75	9b07ada7-8913-4db0-bbb7-a293b6c366c1	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-28 08:50:30.342119+00
76	9b07ada7-8913-4db0-bbb7-a293b6c366c1	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-05-28 08:50:30.342119+00
77	64412946-5c27-46db-962a-fc166e755820	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	2	650000	1300000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-29 18:17:34.048437+00
78	2161e1f9-98b1-48d9-92aa-f569d032cc79	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-31 20:03:16.902788+00
79	07085ac8-d7d2-4b1e-a7ad-ca46945ed43f	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	1	650000	650000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-05-31 20:27:22.274237+00
81	5d4f35b5-e05a-48b6-8137-471f5922faac	TICKET	7595df6d-8ded-4936-a436-f62644a1446b	SINGLE	2	650000	1300000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-02 11:09:54.374339+00
82	ac046f2f-1295-4e9b-a0a7-2a1215b023ff	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-03 09:17:07.117367+00
83	3bedd49b-a3cf-4a53-8b78-3adf98d5c139	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-06 15:09:13.235209+00
84	0bca65cc-5f14-4b7a-9060-1b8941db9262	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-07 19:23:45.80263+00
85	537832a4-56e6-4552-950e-d79cfb84fc6d	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-07 19:31:20.341646+00
86	d924c5d6-b661-440a-869a-5b6c54184a01	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-07 19:35:04.985576+00
87	c72b494d-782b-419d-8588-05eb52a753a4	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-08 08:22:58.841585+00
88	6ffe4c06-075c-48ec-82a4-1afe7a1ed8e4	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-16 19:59:39.120309+00
89	d7f760d8-0790-4357-9885-6723cba3e511	TRANSFER	4b22e975-cdae-4b7d-a89d-89de825e101a	BACK	1	250000	250000	{"info": {"time": "16.20", "notes": "", "pickupPoint": ""}, "name": "SPACE-СПБ", "direction": "BACK"}	2026-06-17 09:30:27.473983+00
90	0cb9482b-0b83-4148-9e4f-7bf4ef323598	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-19 15:33:59.291115+00
91	70213cfc-1133-4145-82c5-3be1a17a78bc	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-19 18:32:51.688694+00
92	42c93b49-bf85-4a17-bab6-ed769ba68c01	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-20 05:13:22.686611+00
93	f3212eeb-429b-40f4-8d78-e60acd3116c7	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-06-20 09:03:57.03701+00
94	7a66a0ab-1101-4ee9-a6a9-dd2d4ec58ba7	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-23 03:12:38.83204+00
95	480803e9-9dbd-42b9-95ac-2240fb75682c	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-23 15:06:13.525739+00
96	b22cab67-a900-4c06-bd8c-737fd1b82128	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-24 04:41:08.282637+00
97	e71876a8-6650-43de-9ab7-1245de79badc	TRANSFER	b8aed809-f1a5-458e-a517-2175ade76493	ROUNDTRIP	3	450000	1350000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ladoga"}, "name": "Трансфер СПБ-SPACE-СПБ", "direction": "ROUNDTRIP"}	2026-06-24 11:35:40.926409+00
98	d9168caf-e58e-4404-b483-6bcd7f893be9	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	2	250000	500000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-06-24 11:35:56.236815+00
100	96e120d3-c4d3-4226-b443-7bbded3b14a1	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-24 12:23:33.49121+00
102	9e1924e8-7315-44a4-a7f9-346c42cb0cf5	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-24 14:20:38.585784+00
103	bf7f830c-4aec-413f-84c3-54ed245f89d8	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	2	250000	500000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-06-24 17:03:46.199558+00
104	1a16e5bd-3859-4c1a-8ef0-d30f689571b1	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-24 17:04:47.732891+00
105	dae6f0ae-3b24-4c7c-ace4-8efec152bc1e	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-25 02:46:31.383476+00
106	dba9d347-0afc-45fd-b031-45f7b7d33f8e	TRANSFER	b8aed809-f1a5-458e-a517-2175ade76493	ROUNDTRIP	1	450000	450000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ladoga"}, "name": "Трансфер СПБ-SPACE-СПБ", "direction": "ROUNDTRIP"}	2026-06-25 12:19:05.265142+00
107	58ce170e-785e-4715-bfc1-f47fd28669cb	TRANSFER	222e1b0c-129d-4e34-98f8-f83c5c642dd9	THERE	1	250000	250000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}, "name": "Трансфер СПБ-SPACE", "direction": "THERE"}	2026-06-27 06:10:49.349542+00
110	6b7b9cf5-4d2d-424a-bde5-50cdca8f581f	TRANSFER	b8aed809-f1a5-458e-a517-2175ade76493	ROUNDTRIP	1	450000	450000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ladoga"}, "name": "Трансфер СПБ-SPACE-СПБ", "direction": "ROUNDTRIP"}	2026-06-29 05:07:09.720651+00
111	0afe14a6-36c3-4e89-975c-0e6b32f56294	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-29 07:17:30.078849+00
112	5a7c8e7b-227d-4f4f-a007-06bb884d01a8	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-29 09:07:37.65498+00
113	bec29e45-540c-48f6-be25-1fa5b9eb70ba	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-06-29 11:16:55.737965+00
114	d70845a4-b6a1-4696-9674-1e9d8ceae5f7	TICKET	0041797b-c408-4083-a5ef-975bfcab8800	GROUP2	2	1350000	2700000	{"groupSize": 2, "ticketType": "GROUP2"}	2026-06-30 09:12:49.640751+00
115	3482c81c-7abe-4f0a-884d-6b7ccd20ba5d	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-07-01 07:44:51.631743+00
116	a5d981a8-0829-427e-afa2-cf60add58892	TRANSFER	b8aed809-f1a5-458e-a517-2175ade76493	ROUNDTRIP	1	450000	450000	{"info": {"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ladoga"}, "name": "Трансфер СПБ-SPACE-СПБ", "direction": "ROUNDTRIP"}	2026-07-01 08:05:15.005056+00
117	aab3dec7-2c37-4e00-9e4d-37aa82fbe704	TICKET	bd76d662-f425-418d-a10f-cab4a6d9acab	SINGLE	1	700000	700000	{"groupSize": 1, "ticketType": "SINGLE"}	2026-07-01 19:59:06.42173+00
118	1d54ef8f-cb6b-4838-b955-6dea05945a45	TICKET	102c4c03-67f7-4e77-84f9-a7df4b14b2de	GROUP10	1	6000000	6000000	{"groupSize": 10, "ticketType": "GROUP10"}	2026-07-02 10:18:21.601314+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.orders (id, user_id, event_id, status, payment_method, payment_reference, payment_notes, promo_code_id, subtotal_cents, discount_cents, total_cents, currency, confirmed_at, canceled_at, redeemed_at, confirmed_by, canceled_by, canceled_reason, created_at, updated_at) FROM stdin;
5fc5bf35-c2f2-46be-9b0e-f02b839915f9	335	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-09 11:02:45.413226+00	\N	\N	1	\N	\N	2026-03-08 16:59:47.959246+00	2026-03-09 11:02:45.413226+00
306edbfe-0fc1-44de-94f4-66814ef2ac91	754	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	40000	460000	RUB	2026-03-09 11:03:59.688008+00	\N	\N	1	\N	\N	2026-03-08 18:27:11.099943+00	2026-03-09 11:03:59.688008+00
a05893ee-a7ed-4cc7-95f5-ecfc912332a7	278	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-06 16:06:48.495675+00	\N	\N	1	\N	\N	2026-03-06 15:58:48.834834+00	2026-03-06 16:06:48.495675+00
f22be794-32aa-4a0a-a9bb-c5613be51a96	212	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-14 12:30:19.75547+00	\N	\N	1	\N	\N	2026-02-14 12:01:56.901521+00	2026-02-14 12:30:19.75547+00
bd328e17-14da-4a01-8dd6-fef503988fbe	204	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-14 12:30:23.326016+00	\N	\N	1	\N	\N	2026-02-14 12:00:25.156081+00	2026-02-14 12:30:23.326016+00
7efc7010-5da9-4c9a-9241-e6e60d3a10e2	209	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-14 12:30:25.595443+00	\N	\N	1	\N	\N	2026-02-14 11:54:52.07225+00	2026-02-14 12:30:25.595443+00
d99efd31-b24c-4fb4-b3a3-055e7c8c9af9	315	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-06 16:24:20.362532+00	\N	\N	1	\N	\N	2026-03-06 16:08:38.694904+00	2026-03-06 16:24:20.362532+00
c346f744-ec97-4276-8829-1c68703f0315	255	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-14 14:58:16.75233+00	\N	\N	1	\N	\N	2026-02-14 14:11:18.711123+00	2026-02-14 14:58:16.75233+00
0d1e78dd-4282-404c-8bab-d7d7090d82f4	217	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-14 14:58:24.537359+00	\N	\N	1	\N	\N	2026-02-14 13:52:07.801861+00	2026-02-14 14:58:24.537359+00
3bedd49b-a3cf-4a53-8b78-3adf98d5c139	1202	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-06 15:35:21.908388+00	\N	\N	1	\N	\N	2026-06-06 15:09:13.235209+00	2026-06-06 15:35:21.908388+00
be316b60-9982-4b17-8d01-83ae67104eef	295	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-14 17:00:08.766303+00	\N	\N	1	\N	\N	2026-02-14 16:50:25.846296+00	2026-02-14 17:00:08.766303+00
69c74d6e-c804-4928-b734-a3391640112f	318	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-16 10:22:38.391702+00	\N	\N	1	\N	\N	2026-02-15 03:22:51.579215+00	2026-02-16 10:22:38.391702+00
70213cfc-1133-4145-82c5-3be1a17a78bc	975	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	\N	2026-06-20 09:05:55.635831+00	\N	\N	1	\N	2026-06-19 18:32:51.688694+00	2026-06-20 09:05:55.635831+00
b44ba145-0a44-40e3-85ea-2e172f822b5b	375	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-17 17:49:42.156306+00	\N	\N	1	\N	\N	2026-02-17 17:23:23.20965+00	2026-02-17 17:49:42.156306+00
a2139c42-09c7-4e74-8c48-127f7136b90d	215	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-19 09:30:23.312683+00	\N	\N	1	\N	\N	2026-02-19 09:28:08.533822+00	2026-02-19 09:30:23.312683+00
6ffe4c06-075c-48ec-82a4-1afe7a1ed8e4	1277	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	50000	650000	RUB	2026-06-16 20:10:11.928352+00	\N	\N	1	\N	\N	2026-06-16 19:59:39.120309+00	2026-06-16 20:10:11.928352+00
7a66a0ab-1101-4ee9-a6a9-dd2d4ec58ba7	1287	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	50000	650000	RUB	2026-06-23 09:41:24.990704+00	\N	\N	1	\N	\N	2026-06-23 03:12:38.83204+00	2026-06-23 09:41:24.990704+00
b2b2dd7a-4ac1-4403-8983-d400c1701c00	399	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-19 12:22:40.471807+00	\N	\N	1	\N	\N	2026-02-19 11:50:45.157442+00	2026-02-19 12:22:40.471807+00
d9168caf-e58e-4404-b483-6bcd7f893be9	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-06-24 11:36:19.939134+00	\N	\N	1	\N	\N	2026-06-24 11:35:56.236815+00	2026-06-24 11:36:19.939134+00
e71876a8-6650-43de-9ab7-1245de79badc	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1350000	0	1350000	RUB	2026-06-24 11:36:28.272181+00	\N	\N	1	\N	\N	2026-06-24 11:35:40.926409+00	2026-06-24 11:36:28.272181+00
aa09e3e1-3ae2-4670-a56e-a6857b705c4d	215	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	\N	2026-02-20 07:11:02.923805+00	\N	\N	1	\N	2026-02-19 09:20:04.309993+00	2026-02-20 07:11:02.923805+00
1a16e5bd-3859-4c1a-8ef0-d30f689571b1	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	ff6c6341-f541-4678-95f5-56997e62f889	700000	50000	650000	RUB	2026-06-24 17:05:11.257017+00	\N	\N	1	\N	\N	2026-06-24 17:04:47.732891+00	2026-06-24 17:05:11.257017+00
e4681fe4-9346-423b-8525-64ab3b4e6a2d	209	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-20 14:21:19.765849+00	\N	\N	1	\N	\N	2026-02-20 11:42:57.640715+00	2026-02-20 14:21:19.765849+00
a8fa67ed-27ac-4ac6-a885-a4049dfc6df3	340	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	\N	2026-02-20 17:34:34.937563+00	\N	\N	1	Не подтвержден	2026-02-20 11:05:08.294549+00	2026-02-20 17:34:34.937563+00
58ce170e-785e-4715-bfc1-f47fd28669cb	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-06-27 06:11:16.576326+00	\N	\N	1	\N	\N	2026-06-27 06:10:49.349542+00	2026-06-27 06:11:16.576326+00
e7dfb063-9a7c-4ba3-b044-26cc2bcb2783	474	3	PAID	USDT	\N	waiting_for_manual_confirmation	\N	1000000	0	1000000	RUB	2026-02-20 21:38:23.215538+00	\N	\N	1	\N	\N	2026-02-20 21:37:13.803305+00	2026-02-20 21:38:23.215538+00
6b7b9cf5-4d2d-424a-bde5-50cdca8f581f	1226	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	450000	0	450000	RUB	2026-06-29 06:32:33.229699+00	\N	\N	1	\N	\N	2026-06-29 05:07:09.720651+00	2026-06-29 06:32:33.229699+00
280398e0-3572-4a34-a4b3-6bf46066a46a	479	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-20 22:05:54.562957+00	\N	\N	1	\N	\N	2026-02-20 22:03:41.694531+00	2026-02-20 22:05:54.562957+00
bec29e45-540c-48f6-be25-1fa5b9eb70ba	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	ff6c6341-f541-4678-95f5-56997e62f889	700000	50000	650000	RUB	2026-06-29 11:17:30.320651+00	\N	\N	1	\N	\N	2026-06-29 11:16:55.737965+00	2026-06-29 11:17:30.320651+00
eac41a7a-d4fe-4996-b2ab-7463c09ef3f1	340	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-25 11:02:03.828939+00	\N	\N	1	\N	\N	2026-02-25 11:00:43.738335+00	2026-02-25 11:02:03.828939+00
a5d981a8-0829-427e-afa2-cf60add58892	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	a1c7a311-685d-4f13-ad74-6e255cb2b8ad	450000	50000	400000	RUB	2026-07-01 08:05:42.725524+00	\N	\N	1	\N	\N	2026-07-01 08:05:15.005056+00	2026-07-01 08:05:42.725524+00
9227cccc-2f83-4e32-9a79-d960b5da4b72	274	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-25 17:24:46.876775+00	\N	\N	1	\N	\N	2026-02-25 17:23:11.532731+00	2026-02-25 17:24:46.876775+00
e15f599e-da23-4c3f-85c6-de93e1d424d5	224	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-27 14:33:45.765139+00	\N	\N	1	\N	\N	2026-02-27 13:40:50.422309+00	2026-02-27 14:33:45.765139+00
5af4bdb8-d627-451f-b6d2-8d2106fc8ebb	224	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-02-27 17:33:27.764393+00	\N	\N	1	\N	\N	2026-02-27 17:23:48.496656+00	2026-02-27 17:33:27.764393+00
c79bcd8a-9622-4ffa-81fc-f8f0c1741128	620	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-03-02 09:34:34.092248+00	\N	\N	1	\N	\N	2026-02-28 17:19:05.409558+00	2026-03-02 09:34:34.092248+00
dfbd52ba-c68d-4da2-9605-b5ece89d1193	587	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1500000	0	1500000	RUB	2026-03-05 07:07:43.286321+00	\N	\N	1	\N	\N	2026-03-04 23:18:06.223169+00	2026-03-05 07:07:43.286321+00
a91884f3-49f2-44bc-be06-1aec61654126	61	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-07 06:46:35.855708+00	\N	\N	1	\N	\N	2026-03-07 06:41:35.364537+00	2026-03-07 06:46:35.855708+00
34ac1591-a2b4-4702-aeca-139c9328faa3	695	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	40000	460000	RUB	2026-03-07 08:43:34.477825+00	\N	\N	1	\N	\N	2026-03-06 18:18:01.060816+00	2026-03-07 08:43:34.477825+00
1095dfe4-41aa-4a3c-ac72-7a185f551f86	484	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-07 08:43:41.762265+00	\N	\N	1	\N	\N	2026-03-06 17:56:23.001573+00	2026-03-07 08:43:41.762265+00
0a70c9ad-4279-4dcf-b7d8-3c01ae069593	687	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	40000	460000	RUB	2026-03-07 08:43:47.961958+00	\N	\N	1	\N	\N	2026-03-06 16:38:37.184433+00	2026-03-07 08:43:47.961958+00
5537ec32-c138-4fbb-b4cb-c5651ad130da	724	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	40000	460000	RUB	2026-03-07 12:07:10.388172+00	\N	\N	1	\N	\N	2026-03-07 11:30:56.452006+00	2026-03-07 12:07:10.388172+00
b8f8abdd-657c-48eb-90d7-0c64b4bb39a2	606	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-07 18:25:38.752306+00	\N	\N	1	\N	\N	2026-03-07 16:21:26.132099+00	2026-03-07 18:25:38.752306+00
ae0625d7-7740-4ebc-a68e-9d074fc1c6ec	351	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-08 09:34:00.494619+00	\N	\N	1	\N	\N	2026-03-08 08:11:36.08667+00	2026-03-08 09:34:00.494619+00
6beb44ab-939e-428e-9130-f369bf5bf8f6	740	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	40000	460000	RUB	2026-03-08 09:53:16.50379+00	\N	\N	1	\N	\N	2026-03-08 06:37:30.043889+00	2026-03-08 09:53:16.50379+00
234970fe-2761-433c-9a1d-0888f096569c	281	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-08 14:00:04.191099+00	\N	\N	1	\N	\N	2026-03-08 11:05:45.504983+00	2026-03-08 14:00:04.191099+00
c1bfbac7-41dc-416e-897f-2d156d4cfe1c	272	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1000000	80000	920000	RUB	2026-03-09 10:57:56.661517+00	\N	\N	1	\N	\N	2026-03-08 20:25:41.323883+00	2026-03-09 10:57:56.661517+00
233e0295-afc2-4b53-bcd4-de58ccf66645	790	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	0	650000	RUB	2026-03-14 12:11:13.585001+00	\N	\N	1	\N	\N	2026-03-14 09:40:29.708107+00	2026-03-14 12:11:13.585001+00
375697b5-9c62-4aa8-9950-b094308d53fc	803	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	0	650000	RUB	2026-03-23 18:19:52.029884+00	\N	\N	1	\N	\N	2026-03-22 20:11:28.042809+00	2026-03-23 18:19:52.029884+00
ff9e95d3-fd26-49c8-8a84-d8804aa50432	936	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-10 08:36:27.706848+00	\N	\N	1	\N	\N	2026-05-09 15:06:31.812305+00	2026-05-10 08:36:27.706848+00
d924c5d6-b661-440a-869a-5b6c54184a01	1190	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-08 10:44:35.174545+00	2026-06-08 13:29:46.971895+00	\N	1	1	\N	2026-06-07 19:35:04.985576+00	2026-06-08 13:29:46.971895+00
537832a4-56e6-4552-950e-d79cfb84fc6d	1190	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-08 11:11:28.159519+00	2026-06-08 13:30:15.402207+00	\N	1	1	\N	2026-06-07 19:31:20.341646+00	2026-06-08 13:30:15.402207+00
0bca65cc-5f14-4b7a-9060-1b8941db9262	1190	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-08 11:11:02.513862+00	2026-06-08 13:30:36.386046+00	\N	1	1	\N	2026-06-07 19:23:45.80263+00	2026-06-08 13:30:36.386046+00
d7f760d8-0790-4357-9885-6723cba3e511	334	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-06-17 09:31:36.917469+00	\N	\N	1	\N	\N	2026-06-17 09:30:27.473983+00	2026-06-17 09:31:36.917469+00
42c93b49-bf85-4a17-bab6-ed769ba68c01	975	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-20 09:04:41.564645+00	\N	\N	1	\N	\N	2026-06-20 05:13:22.686611+00	2026-06-20 09:04:41.564645+00
70c3708e-6b7f-4fd5-b2d9-3751bc6d5eb1	215	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-05-16 13:24:18.10967+00	\N	\N	1	\N	\N	2026-05-16 13:07:53.332832+00	2026-05-16 13:24:18.10967+00
5c83fbe5-206c-4e2f-9b13-3be9028d3f6c	334	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	0	650000	RUB	2026-05-16 16:36:57.960406+00	\N	\N	1	\N	\N	2026-05-16 15:48:44.211789+00	2026-05-16 16:36:57.960406+00
480803e9-9dbd-42b9-95ac-2240fb75682c	253	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	50000	650000	RUB	2026-06-23 15:06:38.861881+00	\N	\N	1	\N	\N	2026-06-23 15:06:13.525739+00	2026-06-23 15:06:38.861881+00
dae6f0ae-3b24-4c7c-ace4-8efec152bc1e	1431	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-25 07:48:36.121852+00	\N	\N	1	\N	\N	2026-06-25 02:46:31.383476+00	2026-06-25 07:48:36.121852+00
9e1924e8-7315-44a4-a7f9-346c42cb0cf5	1	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	\N	2026-06-28 15:08:50.615046+00	\N	\N	1486	test	2026-06-24 14:20:38.585784+00	2026-06-28 15:08:50.615046+00
7f60f4df-53c6-4275-ad23-979fd4532749	2	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-05-18 19:54:49.508022+00	\N	\N	1	\N	\N	2026-05-18 19:53:35.575573+00	2026-05-18 19:54:49.508022+00
0afe14a6-36c3-4e89-975c-0e6b32f56294	1514	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	4db26f93-28d5-41a4-8c55-ffaa642ba2e3	700000	50000	650000	RUB	2026-06-29 07:30:15.726612+00	2026-06-29 11:17:21.566596+00	\N	1	1	Error	2026-06-29 07:17:30.078849+00	2026-06-29 11:17:21.566596+00
102cf71c-16d0-4c9e-ac7f-871eca176aa5	217	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-05-19 08:04:50.34429+00	\N	\N	1	\N	\N	2026-05-19 08:00:20.824007+00	2026-05-19 08:04:50.34429+00
8ec79aa3-8e1c-47a8-985d-fe034425095a	334	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-05-19 16:43:38.015531+00	\N	\N	1	\N	\N	2026-05-19 16:02:16.477343+00	2026-05-19 16:43:38.015531+00
d70845a4-b6a1-4696-9674-1e9d8ceae5f7	1000	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	2700000	0	2700000	RUB	2026-06-30 10:01:41.558816+00	\N	\N	1	\N	\N	2026-06-30 09:12:49.640751+00	2026-06-30 10:01:41.558816+00
06030764-bce2-47db-a612-f6ebce438c76	1083	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	0	650000	RUB	2026-05-20 13:26:07.550953+00	\N	\N	1	\N	\N	2026-05-20 13:19:32.531643+00	2026-05-20 13:26:07.550953+00
aab3dec7-2c37-4e00-9e4d-37aa82fbe704	269	3	PAID	PHONE	\N	waiting_for_manual_confirmation	fe039733-193f-48a8-ab88-918a000321d0	700000	700000	0	RUB	2026-07-01 20:38:26.273634+00	\N	\N	1	\N	\N	2026-07-01 19:59:06.42173+00	2026-07-01 20:38:26.273634+00
f826428f-03f1-42e7-8b49-9cece6730c32	952	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	0	650000	RUB	2026-05-28 08:30:07.06885+00	\N	\N	1	\N	\N	2026-05-27 15:02:53.608635+00	2026-05-28 08:30:07.06885+00
64412946-5c27-46db-962a-fc166e755820	1162	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1300000	0	1300000	RUB	2026-05-29 20:46:40.445551+00	\N	\N	1	\N	\N	2026-05-29 18:17:34.048437+00	2026-05-29 20:46:40.445551+00
2161e1f9-98b1-48d9-92aa-f569d032cc79	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	711dff27-b8d9-4925-bc5a-e0aca783c597	650000	149500	500500	RUB	2026-05-31 20:03:36.630296+00	\N	\N	1	\N	\N	2026-05-31 20:03:16.902788+00	2026-05-31 20:03:36.630296+00
acd10364-1fec-4863-8147-751445be21dd	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 10:28:24.02505+00	\N	\N	1	\N	\N	2026-05-17 10:25:39.549733+00	2026-05-17 10:28:24.02505+00
16cdbbaa-67bb-46df-a624-1a13f1721c17	935	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-11 07:55:58.810263+00	\N	\N	1	\N	\N	2026-05-10 08:34:38.664298+00	2026-05-11 07:55:58.810263+00
425b82df-11ae-4344-8185-066de39aec31	968	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-13 11:07:23.812528+00	\N	\N	1	\N	\N	2026-05-13 10:51:20.555077+00	2026-05-13 11:07:23.812528+00
284e5ef2-85f3-4e36-beb2-cde3dd5d58d9	978	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-13 16:23:08.744539+00	\N	\N	1	\N	\N	2026-05-13 15:23:52.808964+00	2026-05-13 16:23:08.744539+00
58df1160-42a8-444f-8163-cc0c5e096075	1032	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 05:12:15.243927+00	\N	\N	1	\N	\N	2026-05-17 00:06:06.829159+00	2026-05-17 05:12:15.243927+00
27af3a9f-cf21-4274-8de2-07e9105afc11	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 10:17:55.420248+00	\N	\N	1	\N	\N	2026-05-17 10:15:00.380576+00	2026-05-17 10:17:55.420248+00
a2aeb09a-523f-49de-b465-0db59a1e0e75	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 10:27:58.222622+00	\N	\N	1	\N	\N	2026-05-17 10:23:27.031971+00	2026-05-17 10:27:58.222622+00
4a6d58f8-3961-4add-abc6-ff73f5f7cdb2	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 10:28:31.086744+00	\N	\N	1	\N	\N	2026-05-17 10:24:15.485632+00	2026-05-17 10:28:31.086744+00
79123277-59c3-4f80-8442-40a3b3423cda	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 14:56:58.185226+00	\N	\N	1	\N	\N	2026-05-17 14:55:37.647825+00	2026-05-17 14:56:58.185226+00
258fb17b-fea1-4755-b9ee-e6e74f460a8f	1038	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-17 14:57:03.7403+00	\N	\N	1	\N	\N	2026-05-17 14:53:14.275906+00	2026-05-17 14:57:03.7403+00
b76fda27-0478-4901-b6ce-53e3ce9cb6b3	975	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1300000	50000	1250000	RUB	2026-05-20 18:01:36.160898+00	\N	\N	1	\N	\N	2026-05-20 17:57:09.627384+00	2026-05-20 18:01:36.160898+00
f2fe886e-6d0d-424c-9d0e-abf52bf990ff	776	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-21 06:24:01.020815+00	\N	\N	1	\N	\N	2026-05-21 05:54:35.815086+00	2026-05-21 06:24:01.020815+00
008e6d98-071d-4577-8d5f-c8880777aa7f	1109	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-22 14:45:54.926207+00	\N	\N	1	\N	\N	2026-05-22 12:58:47.189934+00	2026-05-22 14:45:54.926207+00
1a0d3e3c-7097-4f04-8f7a-2fc604b3d438	1095	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-22 14:46:03.544456+00	\N	\N	1	\N	\N	2026-05-21 07:40:10.687376+00	2026-05-22 14:46:03.544456+00
9b07ada7-8913-4db0-bbb7-a293b6c366c1	274	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	900000	50000	850000	RUB	2026-05-28 08:54:05.317103+00	\N	\N	1	\N	\N	2026-05-28 08:50:30.342119+00	2026-05-28 08:54:05.317103+00
07085ac8-d7d2-4b1e-a7ad-ca46945ed43f	1187	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	650000	50000	600000	RUB	2026-05-31 20:54:34.020986+00	\N	\N	1	\N	\N	2026-05-31 20:27:22.274237+00	2026-05-31 20:54:34.020986+00
c72b494d-782b-419d-8588-05eb52a753a4	1190	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-08 10:44:09.973558+00	2026-06-08 13:29:33.822352+00	\N	1	1	\N	2026-06-08 08:22:58.841585+00	2026-06-08 13:29:33.822352+00
5d4f35b5-e05a-48b6-8137-471f5922faac	485	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	1300000	0	1300000	RUB	2026-06-02 11:33:31.485676+00	\N	\N	1	\N	\N	2026-06-02 11:09:54.374339+00	2026-06-02 11:33:31.485676+00
ac046f2f-1295-4e9b-a0a7-2a1215b023ff	1213	3	PAID	PHONE	\N	waiting_for_manual_confirmation	09314758-d3ce-412f-b677-e5354f728d32	700000	50000	650000	RUB	2026-06-03 09:47:48.38801+00	\N	\N	1	\N	\N	2026-06-03 09:17:07.117367+00	2026-06-03 09:47:48.38801+00
f3212eeb-429b-40f4-8d78-e60acd3116c7	975	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	250000	0	250000	RUB	2026-06-20 09:04:10.516963+00	\N	\N	1	\N	\N	2026-06-20 09:03:57.03701+00	2026-06-20 09:04:10.516963+00
0cb9482b-0b83-4148-9e4f-7bf4ef323598	975	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	\N	2026-06-20 09:06:12.937533+00	\N	\N	1	\N	2026-06-19 15:33:59.291115+00	2026-06-20 09:06:12.937533+00
b22cab67-a900-4c06-bd8c-737fd1b82128	412	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	ff6c6341-f541-4678-95f5-56997e62f889	700000	50000	650000	RUB	\N	2026-06-24 04:42:32.749398+00	\N	\N	1	test	2026-06-24 04:41:08.282637+00	2026-06-24 04:42:32.749398+00
96e120d3-c4d3-4226-b443-7bbded3b14a1	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-24 12:23:51.834858+00	\N	\N	1	\N	\N	2026-06-24 12:23:33.49121+00	2026-06-24 12:23:51.834858+00
bf7f830c-4aec-413f-84c3-54ed245f89d8	1	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	500000	0	500000	RUB	2026-06-24 17:05:20.260568+00	\N	\N	1	\N	\N	2026-06-24 17:03:46.199558+00	2026-06-24 17:05:20.260568+00
dba9d347-0afc-45fd-b031-45f7b7d33f8e	782	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	450000	0	450000	RUB	2026-06-25 12:50:40.456525+00	\N	\N	1	\N	\N	2026-06-25 12:19:05.265142+00	2026-06-25 12:50:40.456525+00
5a7c8e7b-227d-4f4f-a007-06bb884d01a8	1519	3	PAID	PHONE	\N	waiting_for_manual_confirmation	\N	700000	0	700000	RUB	2026-06-29 09:12:46.295652+00	\N	\N	1	\N	\N	2026-06-29 09:07:37.65498+00	2026-06-29 09:12:46.295652+00
3482c81c-7abe-4f0a-884d-6b7ccd20ba5d	264	3	PAID	PHONE	\N	waiting_for_manual_confirmation	a1c7a311-685d-4f13-ad74-6e255cb2b8ad	700000	50000	650000	RUB	2026-07-01 07:46:44.550289+00	\N	\N	1	\N	\N	2026-07-01 07:44:51.631743+00	2026-07-01 07:46:44.550289+00
1d54ef8f-cb6b-4838-b955-6dea05945a45	1	3	CANCELED	PHONE	\N	waiting_for_manual_confirmation	\N	6000000	0	6000000	RUB	\N	2026-07-02 10:18:43.508743+00	\N	\N	1	test	2026-07-02 10:18:21.601314+00	2026-07-02 10:18:43.508743+00
\.


--
-- Data for Name: payment_settings; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.payment_settings (id, phone_number, usdt_wallet, usdt_network, usdt_memo, phone_description, usdt_description, qr_description, sbp_description, updated_by, created_at, updated_at, payment_qr_data, phone_enabled, usdt_enabled, payment_qr_enabled, sbp_enabled) FROM stdin;
1	+79841478036	THsMEfAWtJo5bkU4nxKgKBR1wHC2v262gd	TRC20		Перевод СБП по номеру на  T Bank\nПосле перевода для ускорения обработки платежа скиньте чек транзакции в бота.	После перевода для ускорения обработки платежа скиньте tx транзакции в бота.		Официальный эквайринг Точка Банк. Переводы обрабатываются автоматически	1	2026-02-11 16:49:30.733713+00	2026-05-16 09:16:42.349583+00		t	t	f	f
\.


--
-- Data for Name: payment_settings_scoped; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.payment_settings_scoped (scope, phone_number, usdt_wallet, usdt_network, usdt_memo, payment_qr_data, phone_enabled, usdt_enabled, payment_qr_enabled, sbp_enabled, phone_description, usdt_description, qr_description, sbp_description, updated_by, created_at, updated_at) FROM stdin;
TRANSFER	+79841478036	THsMEfAWtJo5bkU4nxKgKBR1wHC2v262gd	TRC20			t	t	f	f	Перевод СБП по номеру на  T Bank\nПосле перевода для ускорения обработки платежа скиньте чек транзакции в бота.	После перевода для ускорения обработки платежа скиньте tx транзакции в бота.		Официальный эквайринг Точка Банк. Переводы обрабатываются автоматически	1	2026-02-11 16:49:30.733713+00	2026-05-16 09:16:42.349583+00
TICKET	+79046122613	THsMEfAWtJo5bkU4nxKgKBR1wHC2v262gd	TRC20			t	t	f	f	Перевод СБП по номеру на  T Bank\nПосле перевода для ускорения обработки платежа скиньте чек транзакции в бота.	После перевода для ускорения обработки платежа скиньте tx транзакции в бота.		Официальный эквайринг Точка Банк. Переводы обрабатываются автоматически	1	2026-02-11 16:49:30.733713+00	2026-06-22 11:07:49.067483+00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.payments (id, order_id, provider, provider_payment_id, amount, status, raw_response_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.promo_codes (id, code, discount_type, value, usage_limit, used_count, active_from, active_to, event_id, is_active, created_by, created_at, updated_at) FROM stdin;
34ee3ac9-7d94-408f-8832-b1a22bb56bb7	SYSTO	FIXED	50000	\N	0	\N	\N	3	t	1	2026-06-24 06:21:11.405839+00	2026-06-24 06:21:11.405839+00
3757dd5a-aef7-462f-abdc-75076fe5e814	ANATMAN	FIXED	50000	\N	0	\N	\N	3	t	1	2026-06-24 06:21:43.380875+00	2026-06-24 06:21:43.380875+00
5902a55c-c34d-4d2c-9450-d7298a76b2bc	VALEK	FIXED	50000	\N	0	\N	\N	3	t	1	2026-06-28 18:11:52.83281+00	2026-06-28 18:11:52.83281+00
e4aacb6e-c9f8-4b01-a88b-52bc4ec713f4	CHIRIK	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-29 09:57:30.594544+00	2026-06-29 09:57:30.594544+00
ff6c6341-f541-4678-95f5-56997e62f889	ALICE26	FIXED	50000	30	2	\N	\N	3	t	1	2026-06-11 18:13:24.057011+00	2026-06-29 11:16:55.737965+00
4db26f93-28d5-41a4-8c55-ffaa642ba2e3	ICH2000	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-05 00:14:25.597676+00	2026-06-29 11:17:21.566596+00
a1c7a311-685d-4f13-ad74-6e255cb2b8ad	PSYNA	FIXED	50000	50	2	\N	\N	3	t	1	2026-06-03 05:51:38.435721+00	2026-07-01 08:05:15.005056+00
fe039733-193f-48a8-ab88-918a000321d0	TABOOTEAM	PERCENT	100	16	1	\N	\N	3	t	1	2026-06-30 11:42:42.467333+00	2026-07-01 19:59:06.42173+00
711dff27-b8d9-4925-bc5a-e0aca783c597	РЕГИОНЫ	PERCENT	23	\N	1	\N	\N	3	t	1	2026-05-31 20:02:06.521617+00	2026-05-31 20:03:16.902788+00
f11ab2c9-7123-4166-9589-da7caed78075	KNIGA	FIXED	50000	50	0	\N	\N	3	t	1	2026-06-03 05:50:53.726308+00	2026-06-03 05:50:53.726308+00
8bd2b7fe-c8f6-4e42-967a-0f9075b8ff09	BORN	FIXED	50000	50	0	\N	\N	3	t	1	2026-06-03 05:51:14.675579+00	2026-06-03 05:51:14.675579+00
a66aa868-5088-4081-9b19-179e3c2e09b7	TABOO	FIXED	50000	50	0	\N	\N	\N	t	1	2026-06-03 05:52:54.158536+00	2026-06-03 05:52:54.158536+00
09314758-d3ce-412f-b677-e5354f728d32	LYNOXOD	FIXED	50000	50	1	\N	\N	3	t	1	2026-06-03 05:50:10.394846+00	2026-06-03 09:17:07.117367+00
048158d9-9503-4b33-a13a-33ec8f46f254	LILA2526	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:02:11.889315+00	2026-06-04 23:02:11.889315+00
4fb5b544-2803-484e-9c60-aa378301a609	OK2625	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:02:57.793457+00	2026-06-04 23:02:57.793457+00
91c4e333-ccfe-4277-b269-9383a1eda80c	BLACKROCK	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:03:43.135762+00	2026-06-04 23:03:43.135762+00
1f671a80-0230-4ad3-99d4-efd879da1e23	NARADA25	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:04:20.025195+00	2026-06-04 23:04:20.025195+00
0b19a128-85c0-4cd1-afdb-4ba62437866f	OK0525	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:07:58.252133+00	2026-06-04 23:07:58.252133+00
ff081b75-7d12-422e-811f-946bb0b6300b	MZ67	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-04 23:59:20.612624+00	2026-06-04 23:59:20.612624+00
e35a33e3-7e2c-4f09-b524-1119645e4781	25KADR	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-05 06:03:03.154181+00	2026-06-05 06:03:03.154181+00
fc099fa5-8017-4aec-ae28-b1c8b6d65807	STALIN	FIXED	50000	20	0	\N	\N	3	t	1	2026-06-05 06:17:34.906618+00	2026-06-05 06:17:34.906618+00
3ae75c1f-e48d-4366-a8e4-c7cc3200616a	FESTBAZA	FIXED	50000	30	0	\N	\N	3	t	1	2026-06-05 07:52:59.457236+00	2026-06-05 07:52:59.457236+00
49f4f703-03ef-4323-a6af-b3c25fdfe6ec	FUNT	FIXED	50000	30	0	\N	\N	3	t	1	2026-07-02 17:57:49.977432+00	2026-07-02 17:57:49.977432+00
\.


--
-- Data for Name: referral_claims; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.referral_claims (id, referral_code_id, event_id, invitee_user_id, inviter_user_id, bonus_amount, created_at) FROM stdin;
11	4	3	399	215	100	2026-02-19 11:47:53.566499+00
12	6	13	524	269	100	2026-02-21 13:17:51.903555+00
13	3	14	532	368	100	2026-02-21 13:44:27.751287+00
14	6	13	541	269	100	2026-02-21 14:29:48.078653+00
15	8	3	652	350	100	2026-03-03 12:20:46.986571+00
16	4	3	859	215	100	2026-04-07 10:31:30.394749+00
17	4	3	956	215	100	2026-05-11 15:01:40.003051+00
18	4	3	957	215	100	2026-05-11 15:03:32.849566+00
19	4	3	958	215	100	2026-05-11 15:48:52.516736+00
20	4	3	959	215	100	2026-05-11 15:58:45.059722+00
21	4	3	1066	215	100	2026-05-19 15:57:45.366674+00
22	4	3	1109	215	100	2026-05-22 10:16:18.890911+00
24	4	3	1287	215	100	2026-06-11 03:45:22.500794+00
25	4	3	1360	215	100	2026-06-18 16:30:57.349421+00
26	4	3	1361	215	100	2026-06-18 16:47:03.627075+00
27	4	3	1385	215	100	2026-06-19 22:10:59.541282+00
\.


--
-- Data for Name: referral_codes; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.referral_codes (id, code, owner_user_id, created_at) FROM stdin;
1	MJ6ESAR3	65	2026-02-12 15:05:16.531307+00
2	LKCU5ZBQ	1	2026-02-14 01:19:41.236383+00
3	7CROURMM	368	2026-02-17 06:56:28.814481+00
4	VZXXYH7M	215	2026-02-19 11:41:16.036711+00
5	W2I742DG	212	2026-02-21 11:35:19.050431+00
6	CMWWW7BG	269	2026-02-21 11:36:49.574868+00
7	JCR4Z6K5	620	2026-02-28 17:30:34.321619+00
8	5R2LO2ZO	350	2026-03-03 12:20:07.863554+00
9	ITOXSDQ3	695	2026-03-06 18:19:25.144964+00
\.


--
-- Data for Name: sbp_qr; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.sbp_qr (id, order_id, qrc_id, payload, merchant_id, account_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.schema_migrations (version, dirty) FROM stdin;
26	f
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: ticket_products; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.ticket_products (id, event_id, type, price_cents, inventory_limit, sold_count, is_active, created_by, created_at, updated_at, name) FROM stdin;
102c4c03-67f7-4e77-84f9-a7df4b14b2de	3	GROUP10	6000000	\N	0	t	1	2026-06-28 18:45:55.934971+00	2026-06-28 18:45:55.934971+00	Групповой на 10 чел
0041797b-c408-4083-a5ef-975bfcab8800	3	GROUP2	1350000	\N	2	t	1	2026-06-02 16:11:40.089788+00	2026-06-30 10:01:41.558816+00	Билет на 2 человека
bd76d662-f425-418d-a10f-cab4a6d9acab	3	SINGLE	700000	\N	13	t	1	2026-06-02 16:13:48.200032+00	2026-07-01 20:38:26.273634+00	Билет на 1 человека
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.tickets (id, order_id, user_id, event_id, ticket_type, quantity, qr_payload, qr_payload_hash, qr_issued_at, redeemed_at, redeemed_by, created_at, qr_delivered_at, qr_delivery_error) FROM stdin;
55252270-a016-4c41-b898-4f8d99162158	f22be794-32aa-4a0a-a9bb-c5613be51a96	212	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjU1MjUyMjcwLWEwMTYtNGM0MS1iODk4LTRmOGQ5OTE2MjE1OCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjEyLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoid2dtQWVDRElYYkNpQ1c5MGZreHEwUSIsImlzc3VlZEF0IjoxNzcxMDcyMjE5fQ.18841ebcf4728b5eb1b14eef4854493c7a446f3ed5c21dc0b8afa08e2453abe4	2be784846ba8a2f4397220f868c59c88ccbf4efc6f1268bd8255d08106a7ab8c	2026-02-14 12:30:19.766949+00	\N	\N	2026-02-14 12:01:56.901521+00	2026-05-16 14:48:59.318949+00	\N
86a22fab-2624-49f0-a640-0e71f4e493f6	be316b60-9982-4b17-8d01-83ae67104eef	295	3	SINGLE	1	eyJ0aWNrZXRJZCI6Ijg2YTIyZmFiLTI2MjQtNDlmMC1hNjQwLTBlNzFmNGU0OTNmNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjk1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiM2VlS0UwVlg4aW1iMWE0NTI2aUFfUSIsImlzc3VlZEF0IjoxNzcxMDg4NDA4fQ.e4f4ca232d0ec8c0395dfd19afcb5d27b9b97460c02ee6423fce9555f1f4f9b0	788f1afcf1c7b0b57c8b2b3a85311205a7a45754f3c9efcae3b44fc3338ba839	2026-02-14 17:00:08.773478+00	\N	\N	2026-02-14 16:50:25.846296+00	2026-05-16 14:48:54.601838+00	\N
1d9a6b1d-c393-4fde-8ac0-33539c4e30f9	a2139c42-09c7-4e74-8c48-127f7136b90d	215	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjFkOWE2YjFkLWMzOTMtNGZkZS04YWMwLTMzNTM5YzRlMzBmOSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjE1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiMko0Z2EtbjdzOXh6SEY3NmJaVG1ZZyIsImlzc3VlZEF0IjoxNzcxNDkzNDIzfQ.c2e77c0bd38be329b70b21467f8909d7137796ed3a78c96e2ac07174a2367acd	93a81007a25f0237220df691c20b3706f4c6e9edf5421539a7f4a35c691036b0	2026-02-19 09:30:23.324905+00	\N	\N	2026-02-19 09:28:08.533822+00	2026-05-16 14:48:50.783394+00	\N
a8ca5d05-c030-4cfb-8b96-2f189364e4d7	e4681fe4-9346-423b-8525-64ab3b4e6a2d	209	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImE4Y2E1ZDA1LWMwMzAtNGNmYi04Yjk2LTJmMTg5MzY0ZTRkNyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjA5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiR3hKOGstYjM2c29EWUNzX3BQLTZOdyIsImlzc3VlZEF0IjoxNzcxNTk3Mjc5fQ.a499b1c61ae2649dfcc70e3a886b06c58795fabb4203e8ec0926bf041966d9d6	5ed0bb79c2b9545e71d0edd7ba147396cab0975252fac17517df6b1a0d5846a3	2026-02-20 14:21:19.774083+00	\N	\N	2026-02-20 11:42:57.640715+00	2026-05-16 14:48:57.898671+00	\N
dd622456-73ee-46f0-a1c5-e36b601de09b	c346f744-ec97-4276-8829-1c68703f0315	255	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImRkNjIyNDU2LTczZWUtNDZmMC1hMWM1LWUzNmI2MDFkZTA5YiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjU1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoib2ptTHNzck1BME50SlBvRkktcVJxUSIsImlzc3VlZEF0IjoxNzcxMDgxMDk2fQ.d8f9e51646eb9544116257ac1da19db24584b6c55331f2584f08905e1b2ca80d	e07879c4d39f5381df0e53e1aebda790d1d51bb4d387396f367e27a6bbe78df8	2026-02-14 14:58:16.761566+00	\N	\N	2026-02-14 14:11:18.711123+00	2026-05-16 14:48:55.844647+00	\N
69b72b97-96d3-4b42-9d59-13ab968bd053	0d1e78dd-4282-404c-8bab-d7d7090d82f4	217	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjY5YjcyYjk3LTk2ZDMtNGI0Mi05ZDU5LTEzYWI5NjhiZDA1MyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjE3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoibndhN2RHRktkaUNnOVl2Rm15cXAzUSIsImlzc3VlZEF0IjoxNzcxMDgxMTA0fQ.ea4fab96c343ce08e94c225a6d1e93dad6468ec3894516e355bae968552bcf5b	7b93d5aaf39c0891da32ce60f7f3707f5c3b56532b1587a4aec9ada743fc9695	2026-02-14 14:58:24.546363+00	\N	\N	2026-02-14 13:52:07.801861+00	2026-05-16 14:48:44.838777+00	\N
c7bab696-b0b2-40a4-9d6f-f58b1be780be	69c74d6e-c804-4928-b734-a3391640112f	318	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImM3YmFiNjk2LWIwYjItNDBhNC05ZDZmLWY1OGIxYmU3ODBiZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzE4LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoib1Y5blRNNjRxa3pXc01oMTJKb0hRZyIsImlzc3VlZEF0IjoxNzcxMjM3MzU4fQ.52e544a85717469575cc0e64ecb8397cbde7f2fef6b45c579e00bd7ccfe0b7b6	add80847206fe16c72c0e7543bdefc1205eafdff415b16d4e56bf59168fcdfea	2026-02-16 10:22:38.402044+00	\N	\N	2026-02-15 03:22:51.579215+00	2026-05-16 14:48:48.903121+00	\N
25576867-bbd8-4585-b53f-e219e5e668ef	c346f744-ec97-4276-8829-1c68703f0315	255	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjI1NTc2ODY3LWJiZDgtNDU4NS1iNTNmLWUyMTllNWU2NjhlZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjU1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoidVB5SGRrRHJ0Y01LOGVZRFZnS3Q4ZyIsImlzc3VlZEF0IjoxNzcxMDgxMDk2fQ.d19773e05441073a369263ba97a2880f7d131e86b37663ba928fe464dbf801de	be476c76e47264b7b9ec1422034e350466bdc6fae9b6f5ec64eb4d37bac1efde	2026-02-14 14:58:16.761566+00	\N	\N	2026-02-14 14:11:18.711123+00	2026-05-16 14:48:55.627358+00	\N
4578759b-2ddf-4a4c-bdbf-47973d19bd14	7efc7010-5da9-4c9a-9241-e6e60d3a10e2	209	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjQ1Nzg3NTliLTJkZGYtNGE0Yy1iZGJmLTQ3OTczZDE5YmQxNCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjA5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoieDl2ejNJOUdFTlBlME5uY2xONjYtUSIsImlzc3VlZEF0IjoxNzcxMDcyMjI1fQ.59b2591309a75b48ccce7b9518431453608a95cfece93ab254a1ddae7b588028	8722ceb861cecf6097feecbfdf7b0ada2f975f8453be10ae9098b374b99f69df	2026-02-14 12:30:25.599498+00	\N	\N	2026-02-14 11:54:52.07225+00	2026-05-16 14:48:49.596457+00	\N
ff275f07-ee4e-4914-91ad-ad38fcb4759f	b44ba145-0a44-40e3-85ea-2e172f822b5b	375	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImZmMjc1ZjA3LWVlNGUtNDkxNC05MWFkLWFkMzhmY2I0NzU5ZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mzc1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiWFlnSE4wUUtGVTFqeVNScEVGbV9sUSIsImlzc3VlZEF0IjoxNzcxMzUwNTgyfQ.9ec125444c21ca1529c8b6f4f9b00d3122d23b3765c557c839542ac49b62374b	f8e916b8ba8a382097a1e9af15cfd1c25186ceb1d623769d1510c2d169646f12	2026-02-17 17:49:42.167092+00	\N	\N	2026-02-17 17:23:23.20965+00	2026-05-16 14:48:53.688242+00	\N
f079c3e4-8911-4ea7-afce-4fe0e878663a	bd328e17-14da-4a01-8dd6-fef503988fbe	204	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImYwNzljM2U0LTg5MTEtNGVhNy1hZmNlLTRmZTBlODc4NjYzYSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjA0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiSkUtTGxGcjF5VDBtZ2VodVp2N3hOUSIsImlzc3VlZEF0IjoxNzcxMDcyMjIzfQ.07ab4c6c633dc06c8c5b6c847703741bbc79650c8901fe7623c2eba19226f2e1	89fd92143b512aa91b486ab5e61a45db1efa270e11f7c1216a0e4a2edd1ee948	2026-02-14 12:30:23.330936+00	\N	\N	2026-02-14 12:00:25.156081+00	2026-05-16 14:48:54.366307+00	\N
a2791a03-acef-4d95-a549-04a89bc96f88	aa09e3e1-3ae2-4670-a56e-a6857b705c4d	215	3	SINGLE	1	\N	\N	\N	\N	\N	2026-02-19 09:20:04.309993+00	\N	\N
3e3ce189-09dd-4863-a56e-b598697d6ee8	b2b2dd7a-4ac1-4403-8983-d400c1701c00	399	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjNlM2NlMTg5LTA5ZGQtNDg2My1hNTZlLWI1OTg2OTdkNmVlOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mzk5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoid0pTZXFIbjhvWUU3aDdPbks4ZnBNZyIsImlzc3VlZEF0IjoxNzcxNTAzNzYwfQ.217eaf39e04c9e39bf3cd95722dadca195b50cb285ae99b85884e3300783fef8	6aba7f3a8d791444b44f99af26a12217a2d15a2e485b07ac40465e9bf2e6c289	2026-02-19 12:22:40.482241+00	\N	\N	2026-02-19 11:50:45.157442+00	2026-05-16 14:48:52.996381+00	\N
846b26f4-7450-4bfb-9d42-0a6139164b30	b44ba145-0a44-40e3-85ea-2e172f822b5b	375	3	SINGLE	1	eyJ0aWNrZXRJZCI6Ijg0NmIyNmY0LTc0NTAtNGJmYi05ZDQyLTBhNjEzOTE2NGIzMCIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mzc1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiZWxhWUs1RlZoMmFDZ2VnZ3JKNkdyQSIsImlzc3VlZEF0IjoxNzcxMzUwNTgyfQ.7907a3218f87f488f057e5b3cf5d9cd74e7dbce46c6aed05c353e02bf466ff83	bf492f4f61e5217f1c6bd6a9ff2295b6fb908d25702aa341375b4de0fb2efa62	2026-02-17 17:49:42.167092+00	\N	\N	2026-02-17 17:23:23.20965+00	2026-05-16 14:48:53.4675+00	\N
c2d7b87c-acac-4fa5-a647-3ae6dbd87c90	b2b2dd7a-4ac1-4403-8983-d400c1701c00	399	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImMyZDdiODdjLWFjYWMtNGZhNS1hNjQ3LTNhZTZkYmQ4N2M5MCIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mzk5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiVzZiU055ckc4OXM0dFJWck04QnJIdyIsImlzc3VlZEF0IjoxNzcxNTAzNzYwfQ.89b4053ab4f2063070cda3a8deb7d6757516a0d5f9f4e40d6a4355468fbdca98	85d2c12ec05851e80c1256ee960da2fe5a83139b7e32c1915383b169aee1b120	2026-02-19 12:22:40.482241+00	\N	\N	2026-02-19 11:50:45.157442+00	2026-05-16 14:48:53.228843+00	\N
c385885c-319c-490f-872f-f66935bd6d58	a8fa67ed-27ac-4ac6-a885-a4049dfc6df3	340	3	SINGLE	1	\N	\N	\N	\N	\N	2026-02-20 11:05:08.294549+00	\N	\N
0b1d3312-d7f0-43db-ae66-2cc2fb1c6994	f22be794-32aa-4a0a-a9bb-c5613be51a96	212	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjBiMWQzMzEyLWQ3ZjAtNDNkYi1hZTY2LTJjYzJmYjFjNjk5NCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjEyLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoicEdyOVMyR053RHJYTWxPLU05b0VhZyIsImlzc3VlZEF0IjoxNzcxMDcyMjE5fQ.72edb4566d17782361691f7005f638bd902e2a186c9c59e1dd986c3230cbf469	50ffa6d81c3db6e19f1141d286aa833113aff8a6ab0e1bcc4e1859d85d3e4e76	2026-02-14 12:30:19.766949+00	\N	\N	2026-02-14 12:01:56.901521+00	2026-05-16 14:48:59.043182+00	\N
3199326b-0d94-4366-9a4b-1d83f4e1215c	5c83fbe5-206c-4e2f-9b13-3be9028d3f6c	334	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjMxOTkzMjZiLTBkOTQtNDM2Ni05YTRiLTFkODNmNGUxMjE1YyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzM0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoicnZlU0FHOVBtMVdBQmd2d0RLamVsdyIsImlzc3VlZEF0IjoxNzc4OTQ5NDE3fQ.4cb7db83eb7998ad05812e13b105318079b8ccc841e0de18445f99039e4a8932	8232b45053fd13de975c6eccf9193e4938aa7cc989fc41451acbb029e4e56ee3	2026-05-16 16:36:57.978987+00	\N	\N	2026-05-16 15:48:44.211789+00	2026-05-16 16:36:58.775364+00	\N
c5fcd3f2-e437-46da-b2be-89110b498f1e	e7dfb063-9a7c-4ba3-b044-26cc2bcb2783	474	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImM1ZmNkM2YyLWU0MzctNDZkYS1iMmJlLTg5MTEwYjQ5OGYxZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDc0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoieTZYazVDSkJUT3pTcEZOdkFudE5mZyIsImlzc3VlZEF0IjoxNzcxNjIzNTAzfQ.938dedf513d5c0b73392182a452e20d4e83fac79b110d49cab02802b3e31cd93	4fc8dec6831b54c6f4cf11632f3d3c15c8fbaa47cd690f598ab5ed9b49bf0649	2026-02-20 21:38:23.225013+00	\N	\N	2026-02-20 21:37:13.803305+00	2026-05-16 14:48:58.365637+00	\N
c2fd8b44-520a-481c-9f3f-2a2267d644b3	34ac1591-a2b4-4702-aeca-139c9328faa3	695	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImMyZmQ4YjQ0LTUyMGEtNDgxYy05ZjNmLTJhMjI2N2Q2NDRiMyIsImV2ZW50SWQiOjMsInVzZXJJZCI6Njk1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiZzh3Nll2UEppSE1Vb3phQWlLRk54ZyIsImlzc3VlZEF0IjoxNzcyODczMDE0fQ.0f6b2f012ad19fda1d163937ea45d0d1af0882c8f3b491aa98c9346f2ec534c1	169129591d2286b3c473df004eed2249578f1d9eaf467b9fb868f177b40f90fb	2026-03-07 08:43:34.480709+00	\N	\N	2026-03-06 18:18:01.060816+00	2026-05-16 14:48:47.387324+00	\N
2c0a0896-8b59-4423-b9eb-0d13608dd152	a05893ee-a7ed-4cc7-95f5-ecfc912332a7	278	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjJjMGEwODk2LThiNTktNDQyMy1iOWViLTBkMTM2MDhkZDE1MiIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjc4LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiemtpeHhCbmc4RHVIclhyd25RemV0USIsImlzc3VlZEF0IjoxNzcyODEzMjA4fQ.c7e80f42b4689de1b076e9a9b28abb67dc4f173a28f1e558b670ad6ff5707525	314a68de9adcaaed5f077e2f91b0772fbdce3a5da398c47683488b302184634f	2026-03-06 16:06:48.499624+00	\N	\N	2026-03-06 15:58:48.834834+00	\N	telegram sendMessage status 400
1e9a58c5-30b1-4cbf-94f8-9c7e219b0436	e7dfb063-9a7c-4ba3-b044-26cc2bcb2783	474	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjFlOWE1OGM1LTMwYjEtNGNiZi05NGY4LTljN2UyMTliMDQzNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDc0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiTDkwaExPaGlUMEctVHNGX2VrLXlrZyIsImlzc3VlZEF0IjoxNzcxNjIzNTAzfQ.d1e6252c2394abca63c516d75e9ae8f91b9b7871ce7a2afbea7415e2d0140ade	c528b6c761ba89b2124fbde60b9287e41c9c076d8e0d034f60b365ef59d0955c	2026-02-20 21:38:23.225013+00	\N	\N	2026-02-20 21:37:13.803305+00	2026-05-16 14:48:58.119733+00	\N
f49d8c7b-d629-4b72-a635-090ab39ffd17	9227cccc-2f83-4e32-9a79-d960b5da4b72	274	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImY0OWQ4YzdiLWQ2MjktNGI3Mi1hNjM1LTA5MGFiMzlmZmQxNyIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjc0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiTFVhNF8tRHNUZnZaWVJZWjFWQnRCUSIsImlzc3VlZEF0IjoxNzcyMDQwMjg2fQ.5814c5717fd125b3a8709ea98404218d9e367d86c740579206ed5745cdcd8d33	0eb364a99827c13bdc5e74b7d50d9a6b2a514c83650b6b77841b9165c3c77716	2026-02-25 17:24:46.88566+00	\N	\N	2026-02-25 17:23:11.532731+00	2026-05-16 14:48:49.799899+00	\N
433b3e86-19ad-4461-8948-7e6caa0576c6	d99efd31-b24c-4fb4-b3a3-055e7c8c9af9	315	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjQzM2IzZTg2LTE5YWQtNDQ2MS04OTQ4LTdlNmNhYTA1NzZjNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzE1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiQUx4UmpROUVBUzRSSWtjalNmSnl0dyIsImlzc3VlZEF0IjoxNzcyODE0MjYwfQ.b4a16647a47a541fb5895bfdecc778cda6099932d8364f4bf11196a289addf34	5777cf491fe45116c67e1dea9e8536efc06319e8e84f3afb76381631432b4f20	2026-03-06 16:24:20.365412+00	\N	\N	2026-03-06 16:08:38.694904+00	2026-05-16 14:48:56.458955+00	\N
679f6398-0e9d-4616-92bd-8d6634b3047b	c79bcd8a-9622-4ffa-81fc-f8f0c1741128	620	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjY3OWY2Mzk4LTBlOWQtNDYxNi05MmJkLThkNjYzNGIzMDQ3YiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NjIwLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiVmx0NDZSYmtmaWI4OHY4NF82V3I5dyIsImlzc3VlZEF0IjoxNzcyNDQ0MDc0fQ.b5691f9341dea26ed80e8ccfe4995b997e48d67bff33b85ec47f6f91dbc440ae	5bd7627fb35f2eea7241ec8957a5c515619117b214865ce93913de7e7a87e426	2026-03-02 09:34:34.096159+00	\N	\N	2026-02-28 17:19:05.409558+00	2026-05-16 14:48:56.203414+00	\N
b942ec62-94ee-4e40-ba4e-df747a2a9a8d	dfbd52ba-c68d-4da2-9605-b5ece89d1193	587	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImI5NDJlYzYyLTk0ZWUtNGU0MC1iYTRlLWRmNzQ3YTJhOWE4ZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NTg3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiWm1XZ2x4S2dyNWZWVkFOY1NkckRfZyIsImlzc3VlZEF0IjoxNzcyNjk0NDYzfQ.5d90e5fedd486af42f2ca6f89b155737b58565396f926ce8f0711b8d34377f34	201b097e4a38c4ebeb4cca4bbf2f42c5f97345912a6f1ad079eafeaa769861a7	2026-03-05 07:07:43.289583+00	\N	\N	2026-03-04 23:18:06.223169+00	2026-05-16 14:48:57.415283+00	\N
8dfa642d-26c9-434e-bb9e-2cc2033eaa82	dfbd52ba-c68d-4da2-9605-b5ece89d1193	587	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhkZmE2NDJkLTI2YzktNDM0ZS1iYjllLTJjYzIwMzNlYWE4MiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NTg3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiWDdfYnE4ejhVMVF3VVctbGNNeThJQSIsImlzc3VlZEF0IjoxNzcyNjk0NDYzfQ.d3453c3c5c1aef6671abd580b7d259a36285615d0edce1ca670c15158699ea8f	65cd2541caebd6b6bf36f418a0857bae999cb59d00b1dfd479a6abbf3d580b9b	2026-03-05 07:07:43.289583+00	\N	\N	2026-03-04 23:18:06.223169+00	2026-05-16 14:48:57.207928+00	\N
bbd0703f-4be8-4384-9fb3-68a514b45d47	e15f599e-da23-4c3f-85c6-de93e1d424d5	224	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImJiZDA3MDNmLTRiZTgtNDM4NC05ZmIzLTY4YTUxNGI0NWQ0NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjI0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiZ3hIbUROUE9WZmpXcGlXQXhENWhmQSIsImlzc3VlZEF0IjoxNzcyMjAyODI1fQ.1cba849629b0cc28ebf63e1fd79513cb3f4007b2f4306433806ff574596bd6d3	2ee5df636db5034888c7fa2ca80edbc0054d33409903d775794a62612e0e5ff6	2026-02-27 14:33:45.772522+00	\N	\N	2026-02-27 13:40:50.422309+00	2026-05-16 14:48:57.626299+00	\N
801f2269-a280-46fa-ba7f-b55d15e2295c	a05893ee-a7ed-4cc7-95f5-ecfc912332a7	278	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjgwMWYyMjY5LWEyODAtNDZmYS1iYTdmLWI1NWQxNWUyMjk1YyIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjc4LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoibUEtRjFfSEhUVlFJakJqZ2ZHWHNoQSIsImlzc3VlZEF0IjoxNzcyODEzMjA4fQ.87868c9cd223ea6f53f501dc924ce86637deb4cab885cfe633a243a298cf9eeb	da13ae202caa7bd44d555119584240367d47f1d3dbbbee04f9041906e392c910	2026-03-06 16:06:48.499624+00	\N	\N	2026-03-06 15:58:48.834834+00	\N	telegram sendMessage status 400
cb55bab3-c4ce-4cce-97b5-a6bfa9c91487	d99efd31-b24c-4fb4-b3a3-055e7c8c9af9	315	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImNiNTViYWIzLWM0Y2UtNGNjZS05N2I1LWE2YmZhOWM5MTQ4NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzE1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiSjNhOWVjNl9NU3djazBSZ0NQTnpMQSIsImlzc3VlZEF0IjoxNzcyODE0MjYwfQ.484425bc7ce31320d9fc7a467a1a17090643d1cc19b5d242cf7dce2c58b1bfee	3d70e42bba96949af780d67ad858e8dddbafbc6c2809eb7b323d88c6380ce56e	2026-03-06 16:24:20.365412+00	\N	\N	2026-03-06 16:08:38.694904+00	2026-05-16 14:48:56.66967+00	\N
6161ce48-7b8c-4724-ae72-1b35a71a120e	dfbd52ba-c68d-4da2-9605-b5ece89d1193	587	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjYxNjFjZTQ4LTdiOGMtNDcyNC1hZTcyLTFiMzVhNzFhMTIwZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6NTg3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiNVl5SXZySXhpXzV4SHdqOEptYXB3ZyIsImlzc3VlZEF0IjoxNzcyNjk0NDYzfQ.1341e98601b7c24bfc099e967a228429d37c002de22ccbeed53ad766718fcaab	ea10bd95894c70bae9ba5ec12e0b95b29122160e5c0c80e85b29cdf5062092ae	2026-03-05 07:07:43.289583+00	\N	\N	2026-03-04 23:18:06.223169+00	2026-05-16 14:48:56.924098+00	\N
46f4fe68-cd49-49c5-8aa0-82316081fbdd	5af4bdb8-d627-451f-b6d2-8d2106fc8ebb	224	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjQ2ZjRmZTY4LWNkNDktNDljNS04YWEwLTgyMzE2MDgxZmJkZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjI0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiZzB0LWtVT1p2YkNVc2Eybi1LT0d1USIsImlzc3VlZEF0IjoxNzcyMjEzNjA3fQ.f7b3d3ad6ca7f7ec8ce0ebc68cf3fa806895a83b5465ccca0598e6791ad79c35	0beadc4de1cf3638ea072c923bf4892ba7a13b9dbfefd70e1a4b3922eb78543d	2026-02-27 17:33:27.769582+00	\N	\N	2026-02-27 17:23:48.496656+00	2026-05-16 14:48:48.233911+00	\N
635d1ffd-34f3-4eb5-91c0-a3d539fe0ab9	eac41a7a-d4fe-4996-b2ab-7463c09ef3f1	340	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjYzNWQxZmZkLTM0ZjMtNGViNS05MWMwLWEzZDUzOWZlMGFiOSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzQwLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiS1h2SE91bHpkRWZRaEFhZ3oxbkVTZyIsImlzc3VlZEF0IjoxNzcyMDE3MzIzfQ.6b40c6b514d78a19c4195bd0f640be258d9a07dd7896964b616f4431784dddf0	887c6acb28b1c207d6ab8764ef0ccc7daeb855337bb42fbd86ac2c8a5d14e75d	2026-02-25 11:02:03.835106+00	\N	\N	2026-02-25 11:00:43.738335+00	2026-05-16 14:48:58.621248+00	\N
16e21225-9f89-468e-a9ad-917fd64a0783	27af3a9f-cf21-4274-8de2-07e9105afc11	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjE2ZTIxMjI1LTlmODktNDY4ZS1hOWFkLTkxN2ZkNjRhMDc4MyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IktkMnVCMXVjajlrSEdxaFUxcDdXSHciLCJpc3N1ZWRBdCI6MTc3OTAxMzA3NX0.06db560c2d358c59307679532693161cad6775d05b3374f5385b2695800d2d13	88afa1ffad0d0f30bbfe7cd3b69fd1585b3f7bb38443eb9e124ee655018f5fa9	2026-05-17 10:17:55.442836+00	\N	\N	2026-05-17 10:15:00.380576+00	2026-05-17 10:17:55.945602+00	\N
c005ed7b-b93b-476b-ae82-2b546d21a6f5	5fc5bf35-c2f2-46be-9b0e-f02b839915f9	335	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImMwMDVlZDdiLWI5M2ItNDc2Yi1hZTgyLTJiNTQ2ZDIxYTZmNSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzM1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiNWhMdUdhVS1vZUo1NDBQOHV6ZFlhZyIsImlzc3VlZEF0IjoxNzczMDU0MTY1fQ.764962c3c1bde98d95e832f61e9736dcbeb4ccf04786bae9a5a5e7a25052a626	6f6fa6e3452946bc4bb499abe3fcfcbe913aae3f9e528c52942ba807124324e2	2026-03-09 11:02:45.41624+00	\N	\N	2026-03-08 16:59:47.959246+00	2026-05-16 14:48:48.649386+00	\N
4cd26132-07ee-4b6e-9efa-49ea5f2a9603	c1bfbac7-41dc-416e-897f-2d156d4cfe1c	272	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjRjZDI2MTMyLTA3ZWUtNGI2ZS05ZWZhLTQ5ZWE1ZjJhOTYwMyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjcyLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiMzF6QnhFMnQ5Y2RSOVNrX1BIWlRTUSIsImlzc3VlZEF0IjoxNzczMDUzODc2fQ.0ce47bd44c17e3fa3e5697b581c800f83525f8672ebe386057f0d5bfa6e73ff6	05ea3250412829e05c316bd23b1c08a14a54bc3db3d2ba21a0b1ad98872118bd	2026-03-09 10:57:56.664179+00	\N	\N	2026-03-08 20:25:41.323883+00	2026-05-16 14:48:54.87445+00	\N
a9632b8b-da15-490b-b13e-d05889ea4d54	b8f8abdd-657c-48eb-90d7-0c64b4bb39a2	606	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImE5NjMyYjhiLWRhMTUtNDkwYi1iMTNlLWQwNTg4OWVhNGQ1NCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NjA2LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoib1ItR29KSGlydHVhcHBnVHBYbWN4QSIsImlzc3VlZEF0IjoxNzcyOTA3OTM4fQ.9ee66271cd3b684b8eb64002255f5d97543399f3e17e7dfc920099b8d5c5459c	6662f12949f1e24bcca5548943967c6f701a5a20b0516a370717f8c582adcc1f	2026-03-07 18:25:38.754835+00	\N	\N	2026-03-07 16:21:26.132099+00	2026-05-16 14:48:54.134456+00	\N
505df11d-d513-40cf-ace0-b0f52ed750aa	b8f8abdd-657c-48eb-90d7-0c64b4bb39a2	606	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjUwNWRmMTFkLWQ1MTMtNDBjZi1hY2UwLWIwZjUyZWQ3NTBhYSIsImV2ZW50SWQiOjMsInVzZXJJZCI6NjA2LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiMk5kZzI3OVRBdm5FVTJ0SGctaVM4dyIsImlzc3VlZEF0IjoxNzcyOTA3OTM4fQ.ce17599f6fb7ad9962ccbc3648a1a4ed4cd243d4039fdd038e2e9ef60923b931	146d7ec5cde9bd37800157b84c95b09405471d3df3ae20a9763669c2c2afc5c4	2026-03-07 18:25:38.754835+00	\N	\N	2026-03-07 16:21:26.132099+00	2026-05-16 14:48:53.916381+00	\N
869cf078-ecb7-4ae4-bb42-e6a7f4787ae8	c1bfbac7-41dc-416e-897f-2d156d4cfe1c	272	3	SINGLE	1	eyJ0aWNrZXRJZCI6Ijg2OWNmMDc4LWVjYjctNGFlNC1iYjQyLWU2YTdmNDc4N2FlOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjcyLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiNmlqZ1ZwbzAtS0oybDZQNV9fcXBQdyIsImlzc3VlZEF0IjoxNzczMDUzODc2fQ.837c8ca91a35dc7d0a9eb809ce0eec583149bed9735fb3e1e5402f82ea6b623b	46cd3b69739b925a75bfeb39515140836683af286ba8914753cf3ec1da09fa11	2026-03-09 10:57:56.664179+00	\N	\N	2026-03-08 20:25:41.323883+00	2026-05-16 14:48:55.176906+00	\N
8a501736-8012-4ec4-beaf-2cf362725c37	a91884f3-49f2-44bc-be06-1aec61654126	61	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhhNTAxNzM2LTgwMTItNGVjNC1iZWFmLTJjZjM2MjcyNWMzNyIsImV2ZW50SWQiOjMsInVzZXJJZCI6NjEsInRpY2tldFR5cGUiOiJTSU5HTEUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiJmQ01LSktwZ29adzJvSkhxS0RaSzVBIiwiaXNzdWVkQXQiOjE3NzI4NjU5OTV9.7bf6854588b66c8c17294d6d642a5d3d85ff57046dde6b84e829e4ad2cbe4122	281c1d20abb0cad4f16900cf4e32b3118526008beb04ec4e542a02e9f6361193	2026-03-07 06:46:35.857923+00	\N	\N	2026-03-07 06:41:35.364537+00	2026-05-16 14:48:51.02207+00	\N
7255b951-db61-4324-83cb-59363e3126e8	306edbfe-0fc1-44de-94f4-66814ef2ac91	754	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjcyNTViOTUxLWRiNjEtNDMyNC04M2NiLTU5MzYzZTMxMjZlOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NzU0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoid2FqOG9Gb2ZoRlpOeWY3cHJGcVN0USIsImlzc3VlZEF0IjoxNzczMDU0MjM5fQ.3a909b8093af5853a93a228a2a1ebc8add3a131c9bfdb6426732122b3b6ec9d2	bd5223a8e94fae3c26884913cd67f26d6ecf3194b28aae66f5f1547087b09853	2026-03-09 11:03:59.690914+00	\N	\N	2026-03-08 18:27:11.099943+00	2026-05-16 14:48:47.162935+00	\N
a6bec181-e01b-4b78-9d43-0e3aa97966a8	234970fe-2761-433c-9a1d-0888f096569c	281	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImE2YmVjMTgxLWUwMWItNGI3OC05ZDQzLTBlM2FhOTc5NjZhOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjgxLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiMTFpM2lVUzZtSVNIRFNOMzZxWktYZyIsImlzc3VlZEF0IjoxNzcyOTc4NDA0fQ.11b87e1564d05b943176773099b564bd5bd59d2b5fc82df394cdc3225c4eeff7	e2a9affbb61b65ed23659b6290b996eb86a8a409010a22ba1f6dfabb76951e67	2026-03-08 14:00:04.193948+00	\N	\N	2026-03-08 11:05:45.504983+00	2026-05-16 14:48:46.382674+00	\N
1f4d6d95-6ef4-4fe8-b865-3ea69fa80aff	6beb44ab-939e-428e-9130-f369bf5bf8f6	740	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjFmNGQ2ZDk1LTZlZjQtNGZlOC1iODY1LTNlYTY5ZmE4MGFmZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NzQwLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiM0dXdW9MZ3hFTnkza3czSllmWE1uZyIsImlzc3VlZEF0IjoxNzcyOTYzNTk2fQ.5b86f210b0fb925f6b9b193dae9da219a398d4e4d05d305dc42784e7e1b66659	bb9bf1341bb22a3cbc7ea50ef8c0b655ab89147944547113f50f9bfa045818bc	2026-03-08 09:53:16.505944+00	\N	\N	2026-03-08 06:37:30.043889+00	2026-05-16 14:48:49.155114+00	\N
5666373c-34be-456d-831c-1c9c5dd85d1f	5537ec32-c138-4fbb-b4cb-c5651ad130da	724	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjU2NjYzNzNjLTM0YmUtNDU2ZC04MzFjLTFjOWM1ZGQ4NWQxZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NzI0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiclZnRlhUR2M1TS1RSTNlNHpMcmtYUSIsImlzc3VlZEF0IjoxNzcyODg1MjMwfQ.7f33e0808a76571cfd1df71231edbf84c84f2f5edc9b3459e84fe1b4046aeed1	bedb8e83777033ada3cfc622896e98e3311716103b4d9e1e9998b9def1691706	2026-03-07 12:07:10.391172+00	\N	\N	2026-03-07 11:30:56.452006+00	2026-05-16 14:48:48.027944+00	\N
31048377-9182-433e-b3a1-267ae2de8b5b	1095dfe4-41aa-4a3c-ac72-7a185f551f86	484	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjMxMDQ4Mzc3LTkxODItNDMzZS1iM2ExLTI2N2FlMmRlOGI1YiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDg0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiZW90TW1QWDhEMkZLd3N6LVNqcVBadyIsImlzc3VlZEF0IjoxNzcyODczMDIxfQ.2769ec7cb35ec29a8ea578b19ec8b5f8a78f79f382f9a7392c367d1ccc865584	5a488464f58177e3a3c1aa490ca52f3b2fb9aaf964a584f7206dd4d30cba4cf8	2026-03-07 08:43:41.763654+00	\N	\N	2026-03-06 17:56:23.001573+00	2026-05-16 14:48:45.083924+00	\N
4fd474f0-3738-40f3-95d7-dc784c34c06b	1095dfe4-41aa-4a3c-ac72-7a185f551f86	484	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjRmZDQ3NGYwLTM3MzgtNDBmMy05NWQ3LWRjNzg0YzM0YzA2YiIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDg0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiWG5OOTV2bmZETGdqc1RBSHdWY0ZIdyIsImlzc3VlZEF0IjoxNzcyODczMDIxfQ.e2896ac7da43e47f9b062a1891c09bdb2619758418e85accba17e4a1899b8e92	67d7bb59c7ae24efd7cccc4720dc7bfdaeb4f8966f4fd83f4f1b309a125bdd67	2026-03-07 08:43:41.763654+00	\N	\N	2026-03-06 17:56:23.001573+00	2026-05-16 14:48:45.30512+00	\N
24beb1d2-1317-40a8-8d75-81ad23d663fb	234970fe-2761-433c-9a1d-0888f096569c	281	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjI0YmViMWQyLTEzMTctNDBhOC04ZDc1LTgxYWQyM2Q2NjNmYiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjgxLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiNzZwV0ZMV25JVUVMbnp6c20tQXlzZyIsImlzc3VlZEF0IjoxNzcyOTc4NDA0fQ.cbcc03c14858afd4424c8680e0e137b9fb5e103a7667bf8f0a2476aee02a510d	f480269b4d7ded4ff7d87ebfb11dc764451f5772f138e8b721404335d33c10f8	2026-03-08 14:00:04.193948+00	\N	\N	2026-03-08 11:05:45.504983+00	2026-05-16 14:48:46.027682+00	\N
fda5a6f6-3ce1-4fdc-8a2a-061669bb0c6a	a91884f3-49f2-44bc-be06-1aec61654126	61	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImZkYTVhNmY2LTNjZTEtNGZkYy04YTJhLTA2MTY2OWJiMGM2YSIsImV2ZW50SWQiOjMsInVzZXJJZCI6NjEsInRpY2tldFR5cGUiOiJTSU5HTEUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiJ1MThRazI4dUY1WDNTWXlZTmFtWnd3IiwiaXNzdWVkQXQiOjE3NzI4NjU5OTV9.cd9679ae0290a26b01ca441bc03b913b731d0488d064f42bc16740e1f30f6f45	f0d221ac07aa4ee185f99563c791775c81fb6b24bc42e25d683e05316c5f093b	2026-03-07 06:46:35.857923+00	\N	\N	2026-03-07 06:41:35.364537+00	2026-05-16 14:48:51.688715+00	\N
580127d0-e1b9-44d5-984a-757fcf963b29	ae0625d7-7740-4ebc-a68e-9d074fc1c6ec	351	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjU4MDEyN2QwLWUxYjktNDRkNS05ODRhLTc1N2ZjZjk2M2IyOSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzUxLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiWjVkaW1hck5ISVp1djRCUkgxR2UxUSIsImlzc3VlZEF0IjoxNzcyOTYyNDQwfQ.b5afec2b476ca0976e89a2dda6deaa9f76aa92817414ecfb01f447629bc96618	c97fc5cf795347b7a29a14f6aad663c36f227d838999f223c5ad3411ba2b0c88	2026-03-08 09:34:00.497252+00	\N	\N	2026-03-08 08:11:36.08667+00	\N	telegram sendMessage status 400
5150b85c-710f-413b-ba8c-4821f8ca75b1	58df1160-42a8-444f-8163-cc0c5e096075	1032	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjUxNTBiODVjLTcxMGYtNDEzYi1iYThjLTQ4MjFmOGNhNzViMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzMiwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlM5T2Jmanl5REdXeGxxWWVoOUZmUVEiLCJpc3N1ZWRBdCI6MTc3ODk5NDczNX0.63f3e1c96d1c8d2913c120da20a50e6b4f90c12a6986263850b54623503100a7	06f9356775515d0968fc13e59c0450a5c73282d65a34a99d986ec83cd0479553	2026-05-17 05:12:15.261919+00	\N	\N	2026-05-17 00:06:06.829159+00	2026-05-17 05:12:15.800688+00	\N
55626b72-3c5f-4a4a-a9c5-2cd8df73f74a	ac046f2f-1295-4e9b-a0a7-2a1215b023ff	1213	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjU1NjI2YjcyLTNjNWYtNGE0YS1hOWM1LTJjZDhkZjczZjc0YSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTIxMywidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IldERzFmeTYyYk9Bc1NZNGtydHBTZHciLCJpc3N1ZWRBdCI6MTc4MDQ4MDA2OH0.2ca3aa20fcb78c20c1212aca285dae65800de2ad8ae10f1c2ae9bceb9683d5a2	2971b64cac9ad4cc7434cf9c33b89b964d93128af5bf508096ad861fb18d06a6	2026-06-03 09:47:48.395742+00	\N	\N	2026-06-03 09:17:07.117367+00	2026-06-03 09:47:49.041492+00	\N
75fbf637-0f3f-4e10-ae4c-870201b67142	375697b5-9c62-4aa8-9950-b094308d53fc	803	3	SINGLE	1	eyJ0aWNrZXRJZCI6Ijc1ZmJmNjM3LTBmM2YtNGUxMC1hZTRjLTg3MDIwMWI2NzE0MiIsImV2ZW50SWQiOjMsInVzZXJJZCI6ODAzLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiVFRVZjVhM0ZmQjZBS0NnaGwxc1BtQSIsImlzc3VlZEF0IjoxNzc0Mjg5OTkyfQ.9251207fff77395cf635fbd0f84320c3cb1202560978560ec259dfaefff2edf7	564e2a0858bd1b01251e322dafd556bc6b02d9e83728deaa012f0b3a7eb6f803	2026-03-23 18:19:52.032632+00	\N	\N	2026-03-22 20:11:28.042809+00	2026-05-16 14:48:47.607822+00	\N
b9988b9e-2971-48d7-a7ef-d861fdbd4957	ae0625d7-7740-4ebc-a68e-9d074fc1c6ec	351	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImI5OTg4YjllLTI5NzEtNDhkNy1hN2VmLWQ4NjFmZGJkNDk1NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzUxLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiRmYxeTlNWFYxYmhLTWlkYU9xaFEyZyIsImlzc3VlZEF0IjoxNzcyOTYyNDQwfQ.ab2ae1a17bd131b1cac3565fc3eaf155ce2f40d5e690e89c977f90ee5beffba2	a648ba26a8ada95f70c886ec91693d1a2a992c840693e5c39e4dc76b05ae9323	2026-03-08 09:34:00.497252+00	\N	\N	2026-03-08 08:11:36.08667+00	\N	telegram sendMessage status 400
7ebaf961-fcb4-46bd-9e97-b1d74fb79916	a2aeb09a-523f-49de-b465-0db59a1e0e75	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjdlYmFmOTYxLWZjYjQtNDZiZC05ZTk3LWIxZDc0ZmI3OTkxNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImdBNDBGc3RldGNQb1JKLTJtMXd1U2ciLCJpc3N1ZWRBdCI6MTc3OTAxMzY3OH0.46c80ed5b3eb81f5f15622e718e8e06e8b733824961b4d2cf5b7678c9cad480b	5392b0b47dd05c341e9e6576775f1ff3b60ac4036568112e7e384aea2a765903	2026-05-17 10:27:58.230695+00	\N	\N	2026-05-17 10:23:27.031971+00	2026-05-17 10:27:58.93839+00	\N
6ab6f9b5-3467-4274-91ee-8b2bfdf99011	425b82df-11ae-4344-8185-066de39aec31	968	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjZhYjZmOWI1LTM0NjctNDI3NC05MWVlLThiMmJmZGY5OTAxMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTY4LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiTmxDZjltUEYyT0tLZXkwUkhNNDlBUSIsImlzc3VlZEF0IjoxNzc4NjcwNDQzfQ.2f4b6deb184825fef969ad570d93c2bf21e909c145b050c148e9a6edce1c4eb8	1bb8597cae1e0742f5db54292f6fa3d6eba992f854f21791e286b5f8405cbae2	2026-05-13 11:07:23.819442+00	\N	\N	2026-05-13 10:51:20.555077+00	2026-05-16 14:48:47.799335+00	\N
8d039bb7-0d7c-4f9c-aa0f-50df3f64769e	acd10364-1fec-4863-8147-751445be21dd	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhkMDM5YmI3LTBkN2MtNGY5Yy1hYTBmLTUwZGYzZjY0NzY5ZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6InUtdUJSMkg1M21lRFZVYkNhSWV6N1EiLCJpc3N1ZWRBdCI6MTc3OTAxMzcwNH0.4516a6081e472442b62c436a692d5406957aa081376e9e0410153dea9ed86aab	6c51f41a22f55c4ef3cbd0496add3184fc64ef6308a4abcdfbea4af457e1d1d5	2026-05-17 10:28:24.033389+00	\N	\N	2026-05-17 10:25:39.549733+00	2026-05-17 10:28:24.949122+00	\N
3b21a913-b7d1-4fcf-8f3c-2f68eb638925	ff9e95d3-fd26-49c8-8a84-d8804aa50432	936	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjNiMjFhOTEzLWI3ZDEtNGZjZi04ZjNjLTJmNjhlYjYzODkyNSIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTM2LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiUlJjMVB6c0JWM2ZyZzViRWExaHhndyIsImlzc3VlZEF0IjoxNzc4NDAyMTg3fQ.0f4077c525637e9b7992f984403de52e61b723aca5eac5ff2ee32b5876cb150b	3b4d0b24904356bf6d23d57e50743f6df55b9f6ceb543e7eaab540c6be8959c1	2026-05-10 08:36:27.709564+00	\N	\N	2026-05-09 15:06:31.812305+00	2026-05-16 14:48:59.92807+00	\N
eb614df9-7e53-4a1e-ab7e-44376b509f01	4a6d58f8-3961-4add-abc6-ff73f5f7cdb2	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImViNjE0ZGY5LTdlNTMtNGExZS1hYjdlLTQ0Mzc2YjUwOWYwMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Ik1pd1VFRkRJOE1ELXJmdElPcnRoRGciLCJpc3N1ZWRBdCI6MTc3OTAxMzcxMX0.6b91e4d11e743b67ebdf75f0da05c6c8891582f40d150d71b4961d7d30ad67f8	c2b58ee172ba5b93b8e83e497042caa7f5831b08389197e2057d37aff8d0e468	2026-05-17 10:28:31.097022+00	\N	\N	2026-05-17 10:24:15.485632+00	2026-05-17 10:28:31.602002+00	\N
31ac42fe-03b2-4618-876c-42cb094e0c8a	5fc5bf35-c2f2-46be-9b0e-f02b839915f9	335	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjMxYWM0MmZlLTAzYjItNDYxOC04NzZjLTQyY2IwOTRlMGM4YSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzM1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoidHpKakYtMEZ4NUk2NU54M0RUQ3dLdyIsImlzc3VlZEF0IjoxNzczMDU0MTY1fQ.34478734407fb70edc5991c80eb7c31ba7407cc3c87f86f221133176dc023cc7	907fb8d37a48602ef0029f0443567e4169326b7d31b9589e71564d0b15af7784	2026-03-09 11:02:45.41624+00	\N	\N	2026-03-08 16:59:47.959246+00	2026-05-16 14:48:48.437176+00	\N
fcb60245-79ab-42e1-bd50-5ebc457a0260	0a70c9ad-4279-4dcf-b7d8-3c01ae069593	687	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImZjYjYwMjQ1LTc5YWItNDJlMS1iZDUwLTVlYmM0NTdhMDI2MCIsImV2ZW50SWQiOjMsInVzZXJJZCI6Njg3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiNldycjRhem16a1RCUVJZRjk5ZGx0dyIsImlzc3VlZEF0IjoxNzcyODczMDI3fQ.2249ebe8b68510a34dc567ce3d4fe9cdc57682d61ff119e477ea85ac238c4e8d	536ff292ac94b70d8223890b2bd252c86c024a5081d76a056d69ff7a184adda3	2026-03-07 08:43:47.963578+00	\N	\N	2026-03-06 16:38:37.184433+00	\N	telegram sendMessage status 400
226c6159-e9be-43c0-bb01-b60265d64dfc	0d1e78dd-4282-404c-8bab-d7d7090d82f4	217	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjIyNmM2MTU5LWU5YmUtNDNjMC1iYjAxLWI2MDI2NWQ2NGRmYyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjE3LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoieUdJNHNPS2ZySU9HYkNNYldSSy1iQSIsImlzc3VlZEF0IjoxNzcxMDgxMTA0fQ.e8644ff2beeb248e7198e6d56c08a6563be4709854148bf00324dfc27144b532	cf9021200b21e23fcaa36cb98cf8bd261f76777654a1cfe6014d7edd8f485862	2026-02-14 14:58:24.546363+00	\N	\N	2026-02-14 13:52:07.801861+00	2026-05-16 14:48:44.614343+00	\N
8ba89f29-d09a-41b0-a6d1-bdaf100c3d56	16cdbbaa-67bb-46df-a624-1a13f1721c17	935	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhiYTg5ZjI5LWQwOWEtNDFiMC1hNmQxLWJkYWYxMDBjM2Q1NiIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTM1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoieXFjUjhOU05LTXFMdkZPQVA0UUhBUSIsImlzc3VlZEF0IjoxNzc4NDg2MTU4fQ.2780e28bb7ab98dd7e9aac45e8090c9f03ee17d22d6e8a80576b199a6ecc1e98	18ed8c91f8808f0313e5251d5a753021a1ee33df27ee39b0f427e41033585870	2026-05-11 07:55:58.81287+00	\N	\N	2026-05-10 08:34:38.664298+00	2026-05-16 14:48:45.496246+00	\N
a279cc8c-5d9b-41a0-a90d-7b8e3785ee18	233e0295-afc2-4b53-bcd4-de58ccf66645	790	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImEyNzljYzhjLTVkOWItNDFhMC1hOTBkLTdiOGUzNzg1ZWUxOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NzkwLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiYU1sR3FveEJYZmFYellaTjFMclZUZyIsImlzc3VlZEF0IjoxNzczNDkwMjczfQ.1a50e15004ad48e6fcce84a14874be247576165fd8346390840ed82205adfea4	5931d6c1e529315bfbdb62cab78bcf717620f724beaf431927eee96c5948bee8	2026-03-14 12:11:13.587666+00	\N	\N	2026-03-14 09:40:29.708107+00	2026-05-16 14:48:45.731277+00	\N
d3fbe601-d60b-49b1-adfb-f64a6ddd90c8	280398e0-3572-4a34-a4b3-6bf46066a46a	479	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImQzZmJlNjAxLWQ2MGItNDliMS1hZGZiLWY2NGE2ZGRkOTBjOCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDc5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoicEZUVDNfODNBQTg3VzZNVDVLSU90USIsImlzc3VlZEF0IjoxNzcxNjI1MTU0fQ.c182f292e6e115e22ca804e61da6a27415e085a8db062bdd3826e758e46e39ef	344eaba7eb2ed9b4ed18fe43f79254f24fce184df94a6a664fad4e2385ec9b0f	2026-02-20 22:05:54.571927+00	\N	\N	2026-02-20 22:03:41.694531+00	2026-05-16 14:48:46.732436+00	\N
b5834947-fb74-4a4b-a44b-e29e0c65665b	284e5ef2-85f3-4e36-beb2-cde3dd5d58d9	978	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImI1ODM0OTQ3LWZiNzQtNGE0Yi1hNDRiLWUyOWUwYzY1NjY1YiIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTc4LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiLUdmbktMQmpNNXV1QmlQSDFNUUdFdyIsImlzc3VlZEF0IjoxNzc4Njg5Mzg4fQ.bf9bd725904dbd3fe318bbfe7c4c26c504f8dd75d9ce4a9cca3aa061f0259586	560ef38b9bc1f409e109fd72772e80727101eb9c4432594109a55ac57b9eaeb7	2026-05-13 16:23:08.757851+00	\N	\N	2026-05-13 15:23:52.808964+00	2026-05-16 14:48:46.913863+00	\N
f51f7611-9e57-4a2d-bd07-4acc8c5e5057	3482c81c-7abe-4f0a-884d-6b7ccd20ba5d	264	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImY1MWY3NjExLTllNTctNGEyZC1iZDA3LTRhY2M4YzVlNTA1NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjY0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiQXNlYThXSGZiSkdSUGplYVZVbWFIdyIsImlzc3VlZEF0IjoxNzgyODkyMDA0fQ.ca9db9edd1e8b46b31a32606ce01120a425836814f30abbe4b5c8f6e8f96dee3	7c556ccff1f009e488792db4332819ae0e96de25d6abfbed554719daefbccbe5	2026-07-01 07:46:44.557112+00	\N	\N	2026-07-01 07:44:51.631743+00	2026-07-01 07:46:44.993084+00	\N
de1f6eee-53f4-4086-92a1-3be6985b4ca3	79123277-59c3-4f80-8442-40a3b3423cda	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImRlMWY2ZWVlLTUzZjQtNDA4Ni05MmExLTNiZTY5ODViNGNhMyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Il9RWnMyRzNka0lERzBOSnRVVzVib3ciLCJpc3N1ZWRBdCI6MTc3OTAyOTgxOH0.84b8f4148eb508ae881fcf0d1aafd57f6ca1bc2cd032d7ea7603bdfb38cad3c7	4be71fa849014e824d3e29f17ed729e2e99b04826d6c980e970137b89b71716f	2026-05-17 14:56:58.201805+00	\N	\N	2026-05-17 14:55:37.647825+00	2026-05-17 14:56:58.671577+00	\N
e46740f0-bd9f-418b-a25b-91ae212fee99	258fb17b-fea1-4755-b9ee-e6e74f460a8f	1038	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImU0Njc0MGYwLWJkOWYtNDE4Yi1hMjViLTkxYWUyMTJmZWU5OSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAzOCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImMwMkJxQUZQRVZKVkVRMXZkMmpGRnciLCJpc3N1ZWRBdCI6MTc3OTAyOTgyM30.01d91cd946daa4a2c3f5bec9f032086aaf52ab6c153f63cdba58e57f51f9fdbd	ac24bd66e6fabc8d5312a418747871788d9811980b35676c8bf0c05ad998cdad	2026-05-17 14:57:03.745729+00	\N	\N	2026-05-17 14:53:14.275906+00	2026-05-17 14:57:04.145605+00	\N
559901ac-c94a-471a-9968-e6238f31ef7a	7f60f4df-53c6-4275-ad23-979fd4532749	2	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6IjU1OTkwMWFjLWM5NGEtNDcxYS05OTY4LWU2MjM4ZjMxZWY3YSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MiwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1RIRVJFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiVnlseTRvc29oUnlvcG1MazhRZ2NxdyIsImlzc3VlZEF0IjoxNzc5MTM0MDg5fQ.ab7b613cdcdf6295edf4cfe544471f73eb6c649933c518cef781ef0bba598ff2	160121546c12637c2ab3c9586af63ca5e86b96616a71a5aa4d43f0d5c0445cad	2026-05-18 19:54:49.523348+00	\N	\N	2026-05-18 19:53:35.575573+00	2026-05-18 19:54:50.375781+00	\N
cc2bbfab-d9e5-43ac-87a9-00994c0f4fa2	3bedd49b-a3cf-4a53-8b78-3adf98d5c139	1202	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImNjMmJiZmFiLWQ5ZTUtNDNhYy04N2E5LTAwOTk0YzBmNGZhMiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTIwMiwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImRSclloTjFkWUJmVmpBSUNSOF9yX1EiLCJpc3N1ZWRBdCI6MTc4MDc2MDEyMX0.936764a627037a5a2e6fda1fb626f3dd416441fd6fd311065f7e799fbce4a41f	eb4050c0b5410a5fbbdf109b8abf08660fcd2c0298120b77f960305943278fdf	2026-06-06 15:35:21.915564+00	\N	\N	2026-06-06 15:09:13.235209+00	2026-06-06 15:35:22.459474+00	\N
dd32e62e-1449-42dc-a218-c35430bb59ee	96e120d3-c4d3-4226-b443-7bbded3b14a1	1	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImRkMzJlNjJlLTE0NDktNDJkYy1hMjE4LWMzNTQzMGJiNTllZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImlTU0tST0hOOTNXMUFEa1ppVU5jX2ciLCJpc3N1ZWRBdCI6MTc4MjMwMzgzMX0.06deecb35edc8bf06fd4ef46164159a49f64c7a12e6f2697b3ed07b8c5e8bfc2	0b9a03f9184cc3ae084fc92cbd9c04a7875721cce80cb4c596317a608b929be8	2026-06-24 12:23:51.840035+00	\N	\N	2026-06-24 12:23:33.49121+00	2026-06-24 12:23:52.095262+00	\N
fd497990-02f3-4d33-8401-3a766f27a5bd	58ce170e-785e-4715-bfc1-f47fd28669cb	1	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6ImZkNDk3OTkwLTAyZjMtNGQzMy04NDAxLTNhNzY2ZjI3YTViZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1RIRVJFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiQ2tfSERlN2ROQnN2SEc1LUtQUjhzUSIsImlzc3VlZEF0IjoxNzgyNTQwNjc2fQ.70c106aaf9bc18da1a70de1dd6087e410c4f680e5cad6ad3938225b94a967df6	b043bdc0b823cc570c670cf1b71e4c1eb1d526cdb5e22d44bc8a7a9b0ee022f1	2026-06-27 06:11:16.586921+00	\N	\N	2026-06-27 06:10:49.349542+00	2026-06-27 06:11:16.83983+00	\N
cb1d30ba-4b72-4681-b11c-5e80dcb09cf2	d70845a4-b6a1-4696-9674-1e9d8ceae5f7	1000	3	GROUP2	2	eyJ0aWNrZXRJZCI6ImNiMWQzMGJhLTRiNzItNDY4MS1iMTFjLTVlODBkY2IwOWNmMiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAwMCwidGlja2V0VHlwZSI6IkdST1VQMiIsInF1YW50aXR5IjoyLCJub25jZSI6Ijh3WFlnYzRQRTdxa1FuelA5dUpxNkEiLCJpc3N1ZWRBdCI6MTc4MjgxMzcwMX0.5bd749bfb13a48eb3e2eb69915feacaee4cfd8b1420b158cbe1f475b7f464ebb	1c3977b03740fd0fe7ee4674af3972d18e738f39a614080399dd6284313a5bcd	2026-06-30 10:01:41.567336+00	\N	\N	2026-06-30 09:12:49.640751+00	2026-06-30 10:01:41.99894+00	\N
e232087b-42a9-4a90-91bf-58c0990b816f	d70845a4-b6a1-4696-9674-1e9d8ceae5f7	1000	3	GROUP2	2	eyJ0aWNrZXRJZCI6ImUyMzIwODdiLTQyYTktNGE5MC05MWJmLTU4YzA5OTBiODE2ZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTAwMCwidGlja2V0VHlwZSI6IkdST1VQMiIsInF1YW50aXR5IjoyLCJub25jZSI6ImY4S1psREZRYUtBSkhib0xtWnAtcVEiLCJpc3N1ZWRBdCI6MTc4MjgxMzcwMX0.258097eda42d8c17db9b1c63494c748bb40413e23ec32241aa9c8d0086e08678	476278fb96be827ee870c20f8102419963b054e88ef90876ade625238bce48a6	2026-06-30 10:01:41.567336+00	\N	\N	2026-06-30 09:12:49.640751+00	2026-06-30 10:01:42.150464+00	\N
7f4facf3-4681-4c9e-a4df-8b9dafe0b527	a5d981a8-0829-427e-afa2-cf60add58892	1	3	TRANSFER_ROUNDTRIP	1	eyJ0aWNrZXRJZCI6IjdmNGZhY2YzLTQ2ODEtNGM5ZS1hNGRmLThiOWRhZmUwYjUyNyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1JPVU5EVFJJUCIsInF1YW50aXR5IjoxLCJub25jZSI6Iks1cFd0dW5zWWtDWDltbE9NeFBfVWciLCJpc3N1ZWRBdCI6MTc4Mjg5MzE0Mn0.9a01ad5caec08fd23aab769bfb54484c780e2fda33dd56554e1f8229c01aa9f2	0736db198c49a4781dec7ef09032a7e2a04c84125143a01e6fd9337b3c0566e1	2026-07-01 08:05:42.732131+00	\N	\N	2026-07-01 08:05:15.005056+00	2026-07-01 08:05:42.980877+00	\N
36f7d41d-b74c-4c91-851f-672f75aea6ea	d924c5d6-b661-440a-869a-5b6c54184a01	1190	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjM2ZjdkNDFkLWI3NGMtNGM5MS04NTFmLTY3MmY3NWFlYTZlYSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE5MCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlB4ZHVpM1FKOHdqeG45OHcyeHpwT1EiLCJpc3N1ZWRBdCI6MTc4MDkxNTQ3NX0.e32d92150888cc5f9cd0cf12bfed88c190101ffa1dc28fbfca732602a6e0ee5f	c14a572122905185e46e0643961d2c8be89de4b2bc63245c1052fc70f7212a10	2026-06-08 10:44:35.183821+00	\N	\N	2026-06-07 19:35:04.985576+00	2026-06-08 10:44:35.434616+00	\N
8a2936dd-b5cc-48f6-8d84-13b039134569	0bca65cc-5f14-4b7a-9060-1b8941db9262	1190	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhhMjkzNmRkLWI1Y2MtNDhmNi04ZDg0LTEzYjAzOTEzNDU2OSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE5MCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImJ5VkVhcXhZSERRVktMU1lPM25kVWciLCJpc3N1ZWRBdCI6MTc4MDkxNzA2Mn0.bd5749f4ff106289187cdd2b97b56307edcc922e343d92639435dba5e05e5823	a267952f365f6c7dc8d2ffe8ee5931ae8d3832eda59c036c93194d0e89201ff5	2026-06-08 11:11:02.521595+00	\N	\N	2026-06-07 19:23:45.80263+00	2026-06-08 11:11:02.908824+00	\N
b274d42d-c171-4508-95ba-a8d19bb9762a	537832a4-56e6-4552-950e-d79cfb84fc6d	1190	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImIyNzRkNDJkLWMxNzEtNDUwOC05NWJhLWE4ZDE5YmI5NzYyYSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE5MCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImFtRUxsUEpXZ0Q0VEgydkh5TXlFOVEiLCJpc3N1ZWRBdCI6MTc4MDkxNzA4OH0.e7ab5b7e4e25e5c352924e9d5d9144c524ba1449f5944e72ab674fb16691bccd	0dd69bd192ced5697808c2906f91c12817692683553154dad67343da8d7fae32	2026-06-08 11:11:28.168192+00	\N	\N	2026-06-07 19:31:20.341646+00	2026-06-08 11:11:28.415504+00	\N
53d3a51d-3e95-4f92-9f01-dd95bacd63a6	42c93b49-bf85-4a17-bab6-ed769ba68c01	975	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjUzZDNhNTFkLTNlOTUtNGY5Mi05ZjAxLWRkOTViYWNkNjNhNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTc1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoieWh1ZlhMUW5USFdxd0xjUDNMX29WdyIsImlzc3VlZEF0IjoxNzgxOTQ2MjgxfQ.91fa3b1d5ef1f2bf8cfa3991b2277368439b35bcd1f4b1a8285b8db0780fa543	e0ec7d3f1457f33c7ec3f777acd9a68ef63260336054368a86ccf717218161ac	2026-06-20 09:04:41.571044+00	\N	\N	2026-06-20 05:13:22.686611+00	2026-06-20 09:04:41.817462+00	\N
6f758281-b31a-4911-a63f-37d070fed142	8ec79aa3-8e1c-47a8-985d-fe034425095a	334	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6IjZmNzU4MjgxLWIzMWEtNDkxMS1hNjNmLTM3ZDA3MGZlZDE0MiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzM0LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfVEhFUkUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiJYRVhMckNzYTZyeWVkVjlVZEFLemlBIiwiaXNzdWVkQXQiOjE3NzkyMDkwMTh9.214899515173924956d150dae217d11fc3d708cee8b11585af0f1851f9ceac5d	d1aaab5393b2a5e82b534f6c903d2a7364fe09cb9deac48d2790e067eee243b3	2026-05-19 16:43:38.024887+00	\N	\N	2026-05-19 16:02:16.477343+00	2026-05-19 16:43:38.403443+00	\N
0eacd56f-8b72-48c7-b5e8-3522c97a1c82	c72b494d-782b-419d-8588-05eb52a753a4	1190	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjBlYWNkNTZmLThiNzItNDhjNy1iNWU4LTM1MjJjOTdhMWM4MiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE5MCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6InhZTVU4U044Zkh4V1lyVjRTU045REEiLCJpc3N1ZWRBdCI6MTc4MDkxNTQ0OX0.4fb74f07c401322237e1bec536203c9576805d6721924e12df72ec91957fffbd	638593851ed00837c43fc5c34bd6f2e5e199b67ca154cd9594a15abd1b8c9563	2026-06-08 10:44:09.981396+00	\N	\N	2026-06-08 08:22:58.841585+00	2026-06-08 10:44:10.41155+00	\N
eb58b576-3b0b-4a8c-a0ff-70e5658ee14e	aab3dec7-2c37-4e00-9e4d-37aa82fbe704	269	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImViNThiNTc2LTNiMGItNGE4Yy1hMGZmLTcwZTU2NThlZTE0ZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjY5LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoib1RrYi1kcEFxME80Wm1mUnNBZlRNZyIsImlzc3VlZEF0IjoxNzgyOTM4MzA2fQ.24fb1dfe7d73d10ece26d7a2d80ac3fddc504d9c54498cf48572260902a7d2e7	18778fc90bda0edb9be09715be95536db30b3b203f9aaf4657d2916beb3464e4	2026-07-01 20:38:26.284351+00	\N	\N	2026-07-01 19:59:06.42173+00	2026-07-01 20:38:26.738696+00	\N
9063d48b-1390-4153-9939-9307a3d1be54	f3212eeb-429b-40f4-8d78-e60acd3116c7	975	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6IjkwNjNkNDhiLTEzOTAtNDE1My05OTM5LTkzMDdhM2QxYmU1NCIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTc1LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfVEhFUkUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiI2NkxESGNYc2dtTGk3UXhiczFpYnFBIiwiaXNzdWVkQXQiOjE3ODE5NDY0MDF9.820b09b7e812222a97ccd0f7db38eb0d949d02e546ec7dc41529519ee4ad99c0	4eb6eb96e45b516934ef84efa6acfcf1b44dd3c2008e649a080a8178b9ce19ee	2026-06-20 09:06:41.590204+00	\N	\N	2026-06-20 09:06:41.57939+00	2026-06-20 09:06:41.859222+00	\N
18d8db07-9f2f-4191-91d2-d1da0ae5a522	9e1924e8-7315-44a4-a7f9-346c42cb0cf5	1	3	SINGLE	1	\N	\N	\N	\N	\N	2026-06-24 14:20:38.585784+00	\N	\N
f899b1b9-bcd7-4d4a-b923-fb893f3c1084	102cf71c-16d0-4c9e-ac7f-871eca176aa5	217	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6ImY4OTliMWI5LWJjZDctNGQ0YS1iOTIzLWZiODkzZjNjMTA4NCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjE3LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfVEhFUkUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiJwYTdBVTFtSVJNSDA4eXhWOVJ0ZVdBIiwiaXNzdWVkQXQiOjE3NzkyMjg1NDJ9.a6626a33e78e130327f1ab7292ae31bb3cf1f55719aabb218e8e6c1bd447c6a0	5a13764a12d8c4a15348b3e5c6ff3480d952d12ebc3a6900aa847b15d8c4d963	2026-05-19 22:09:02.784139+00	\N	\N	2026-05-19 22:09:02.770263+00	2026-05-19 22:09:03.09245+00	\N
ec69492b-7a38-42ef-bb9d-b6ab863b8631	6ffe4c06-075c-48ec-82a4-1afe7a1ed8e4	1277	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImVjNjk0OTJiLTdhMzgtNDJlZi1iYjlkLWI2YWI4NjNiODYzMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTI3NywidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IjRfNzlHd2tjNENaV2dlc2EwdGlPNHciLCJpc3N1ZWRBdCI6MTc4MTY0MDYxMX0.d1de1d231108d8d9d51ea4e1cd040422d52f451ea2b2d885281e09554f6c6ef2	148461832036e65978648b0feaafeef828b4c8f313ceb82661d0f57e35b02354	2026-06-16 20:10:11.936099+00	\N	\N	2026-06-16 19:59:39.120309+00	2026-06-16 20:10:12.393314+00	\N
f652d533-debb-4457-852b-805bf2120626	7a66a0ab-1101-4ee9-a6a9-dd2d4ec58ba7	1287	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImY2NTJkNTMzLWRlYmItNDQ1Ny04NTJiLTgwNWJmMjEyMDYyNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTI4NywidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlFaTEN2MHNJT1YzdHZkSjBqUW92VlEiLCJpc3N1ZWRBdCI6MTc4MjIwNzY4NX0.e2be5fac649561d48a403a47311dc9921be06d6a52a7be46289e5593a6960b10	30a1ff60f3d27ff45c572daa0df11bc9ebe98e3009d0e5c08e3b1f1350822409	2026-06-23 09:41:25.000488+00	\N	\N	2026-06-23 03:12:38.83204+00	2026-06-23 09:41:25.429525+00	\N
ac7136f5-5cbc-44b8-aba6-b076e00ba803	bf7f830c-4aec-413f-84c3-54ed245f89d8	1	3	TRANSFER_THERE	2	eyJ0aWNrZXRJZCI6ImFjNzEzNmY1LTVjYmMtNDRiOC1hYmE2LWIwNzZlMDBiYTgwMyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1RIRVJFIiwicXVhbnRpdHkiOjIsIm5vbmNlIjoiV0FSNWxWVkFnZXhTZXF5M2FSZkRFZyIsImlzc3VlZEF0IjoxNzgyMzIwNzIwfQ.05d8f611743d7793ed2a1c2170d038f9670b0c9866ba521f079ee7cf1c507a88	a07520ca2566c4e4a9c2beb50d98525a4926c04becb7a8b20c8de193e89cb319	2026-06-24 17:05:20.267453+00	\N	\N	2026-06-24 17:03:46.199558+00	2026-06-24 17:05:20.554929+00	\N
cb126d9d-cbcc-4f6c-b8d5-5254c9b55f6e	6b7b9cf5-4d2d-424a-bde5-50cdca8f581f	1226	3	TRANSFER_ROUNDTRIP	1	eyJ0aWNrZXRJZCI6ImNiMTI2ZDlkLWNiY2MtNGY2Yy1iOGQ1LTUyNTRjOWI1NWY2ZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTIyNiwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1JPVU5EVFJJUCIsInF1YW50aXR5IjoxLCJub25jZSI6IjRma29sMzlRNEVRWnpXT0VyemYxMVEiLCJpc3N1ZWRBdCI6MTc4MjcxNDc1M30.a6445b13fffeca884bd08a866f983c421c51ad72a58249722aab11d29cefdc05	bd6afcf25221c785a9ed7514ce5ddefc532a7b3eb05085b3eb6617e69c66d194	2026-06-29 06:32:33.240521+00	\N	\N	2026-06-29 05:07:09.720651+00	2026-06-29 06:32:33.929763+00	\N
f7ed8965-0047-4198-bd75-33debf35595f	70c3708e-6b7f-4fd5-b2d9-3751bc6d5eb1	215	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6ImY3ZWQ4OTY1LTAwNDctNDE5OC1iZDc1LTMzZGViZjM1NTk1ZiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjE1LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfVEhFUkUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiJKX0pPREdVQ1FDeWJkSmRaRS1RMWNnIiwiaXNzdWVkQXQiOjE3NzkyMjg1NTJ9.102cadc6e91b983d4806c2a2613d982e2e2012224869ce0d92577d3b14a251f6	fb5147b46038c29bc265685bc1882933af740a0a0360aaa0c019d3ec3f52e8f0	2026-05-19 22:09:12.087694+00	\N	\N	2026-05-19 22:09:12.076209+00	2026-05-19 22:09:12.245802+00	\N
35b88ded-737f-43f1-a96c-1fd219ac13fd	06030764-bce2-47db-a612-f6ebce438c76	1083	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjM1Yjg4ZGVkLTczN2YtNDNmMS1hOTZjLTFmZDIxOWFjMTNmZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTA4MywidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6ImFuRWNiZGlmbi1xVlhGV0FFUkRnNUEiLCJpc3N1ZWRBdCI6MTc3OTI4MzU2N30.3d8bb62a6504cebc0cdf57667170bd1cf9b45a028bf5c5f1cc31ec46571f04cf	7a37a8ea52a3ce953672a01cf5dd3244907008c5f983baaff952a52926d511ce	2026-05-20 13:26:07.558857+00	\N	\N	2026-05-20 13:19:32.531643+00	2026-05-20 13:26:08.014427+00	\N
4ab183cc-286a-4c0a-b964-b38142e1c4b0	d7f760d8-0790-4357-9885-6723cba3e511	334	3	TRANSFER_BACK	1	eyJ0aWNrZXRJZCI6IjRhYjE4M2NjLTI4NmEtNGMwYS1iOTY0LWIzODE0MmUxYzRiMCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MzM0LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfQkFDSyIsInF1YW50aXR5IjoxLCJub25jZSI6IjlPSWRlWUtlTzZxYmFkN3BCQThUVmciLCJpc3N1ZWRBdCI6MTc4MTY4ODY5Nn0.872623458a618b6e5e548e0dd250c98ea3ed5bb56824f1a6199244c5a21edaae	30543b5d1ef55ee681574e0dbcce57944f88d938f4f405dc0eafc133e33a11ae	2026-06-17 09:31:36.928363+00	\N	\N	2026-06-17 09:30:27.473983+00	2026-06-17 09:31:37.29059+00	\N
f1c67574-45d6-4c06-b669-0776da565453	480803e9-9dbd-42b9-95ac-2240fb75682c	253	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImYxYzY3NTc0LTQ1ZDYtNGMwNi1iNjY5LTA3NzZkYTU2NTQ1MyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MjUzLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiQXo5S0VEM2psWlBXcGdLcXJYSVJBZyIsImlzc3VlZEF0IjoxNzgyMjI3MTk4fQ.113611fa1ecb81038f69f1aeb12c3f5510f1510eb3937ead7ca607cdd4c08d24	94bda7742244a44a335e6aa741d77a4eb99b60b0260beac1e07449acaae26c31	2026-06-23 15:06:38.869669+00	\N	\N	2026-06-23 15:06:13.525739+00	2026-06-23 15:06:39.432994+00	\N
8afb16a4-79b0-457c-8fc8-21ad1b01c387	1a16e5bd-3859-4c1a-8ef0-d30f689571b1	1	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjhhZmIxNmE0LTc5YjAtNDU3Yy04ZmM4LTIxYWQxYjAxYzM4NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Ino2WGJLY3g3NnlsUUlVTzlIUjZYV1EiLCJpc3N1ZWRBdCI6MTc4MjMyMDcxMX0.d439c0950e788eee7ef6b4d7cede331937f25a4ddbd886f0dd9416cdcc7b6c39	fd0e218dec262c1bf7dd6b805ec5909ad3dedd6ede12e454faac0d0212778ad8	2026-06-24 17:05:11.271726+00	\N	\N	2026-06-24 17:04:47.732891+00	2026-06-24 17:05:11.55475+00	\N
46c6602f-8c1b-4165-b3d2-31462a1e476c	0afe14a6-36c3-4e89-975c-0e6b32f56294	1514	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjQ2YzY2MDJmLThjMWItNDE2NS1iM2QyLTMxNDYyYTFlNDc2YyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTUxNCwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlpMb3BLSlQ5cUZzdGFSS01qZEtUWUEiLCJpc3N1ZWRBdCI6MTc4MjcxODIxNX0.ba162ef9343e1ce5409a24245dedfdf47154ea7e078ab8cd1e5699a785be56dc	9f2cac1701a5d745a462e640ae2be153446b86bf5d7abfbf81ddf6f6b4f318eb	2026-06-29 07:30:15.736732+00	\N	\N	2026-06-29 07:17:30.078849+00	\N	\N
fe1b1792-3326-4cb8-b8d1-f0a753cb717e	0cb9482b-0b83-4148-9e4f-7bf4ef323598	975	3	SINGLE	1	\N	\N	\N	\N	\N	2026-06-19 15:33:59.291115+00	\N	\N
6e12c1ff-af77-4643-88b3-a626a0522f7a	b76fda27-0478-4901-b6ce-53e3ce9cb6b3	975	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjZlMTJjMWZmLWFmNzctNDY0My04OGIzLWE2MjZhMDUyMmY3YSIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTc1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiRVNOVU5RYUdkdkk3OU5QQURMVnlzZyIsImlzc3VlZEF0IjoxNzc5MzAwMDk2fQ.28d2a30838def5e2b41cc24985c69bcd8e74986e2447c2655146fce9757df8f9	8480ca6d14d36dca3ec3b4c4992e55b7976ae9870050dd48f70d33ca218fd8dc	2026-05-20 18:01:36.168624+00	\N	\N	2026-05-20 17:57:09.627384+00	2026-05-20 18:01:36.591628+00	\N
d1e4697b-242e-4ae1-b8da-40dfb0d404ca	b76fda27-0478-4901-b6ce-53e3ce9cb6b3	975	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImQxZTQ2OTdiLTI0MmUtNGFlMS1iOGRhLTQwZGZiMGQ0MDRjYSIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTc1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiaGpHanlhODk2OFVYNkFJWUItZTZfdyIsImlzc3VlZEF0IjoxNzc5MzAwMDk2fQ.0038d2409b34119224c208c9c7c26d73d963644709fc540ba83123b726cb1948	46b9920a4353d8775d12a2c13d84efd509123bd48501fbcd60590113cf54e269	2026-05-20 18:01:36.168624+00	\N	\N	2026-05-20 17:57:09.627384+00	2026-05-20 18:01:36.759187+00	\N
c6d9d1ad-cf1e-4573-94e0-028145a3c131	f2fe886e-6d0d-424c-9d0e-abf52bf990ff	776	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImM2ZDlkMWFkLWNmMWUtNDU3My05NGUwLTAyODE0NWEzYzEzMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6Nzc2LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoibXhkT09pMlFsLVpvaFJJNndyZl9BdyIsImlzc3VlZEF0IjoxNzc5MzQ0NjQxfQ.aa2ee52acaf69254e02e723308a907c2cda5a058511e99ec2b4042f54b52d9fe	7ca5d6f302fb31d5860d781540e9b0ca0244650b361fec435abddcaf709c42d6	2026-05-21 06:24:01.027965+00	\N	\N	2026-05-21 05:54:35.815086+00	\N	telegram sendMessage status 400
0677028d-2fd8-4d14-bd88-bb5b69dd3d2b	008e6d98-071d-4577-8d5f-c8880777aa7f	1109	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjA2NzcwMjhkLTJmZDgtNGQxNC1iZDg4LWJiNWI2OWRkM2QyYiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTEwOSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IkZtWVJYT0piemplUTJaNnRDWDlxTVEiLCJpc3N1ZWRBdCI6MTc3OTQ2MTE1NH0.5fc016fb6ef1f062583364c74ab1e19fd1c6af2c18533203d667f52519182942	861230eb0ba74d6fdc0b6a22da7aa28fa18576b0a3704eea593ca1c412915da0	2026-05-22 14:45:54.934468+00	\N	\N	2026-05-22 12:58:47.189934+00	2026-05-22 14:45:55.31383+00	\N
ce5e8794-ebb5-4302-bc09-e6f31665cd5f	b22cab67-a900-4c06-bd8c-737fd1b82128	412	3	SINGLE	1	\N	\N	\N	\N	\N	2026-06-24 04:41:08.282637+00	\N	\N
5b092551-6159-4d43-88bd-27b4ccc9b287	1a0d3e3c-7097-4f04-8f7a-2fc604b3d438	1095	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjViMDkyNTUxLTYxNTktNGQ0My04OGJkLTI3YjRjY2M5YjI4NyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTA5NSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Ilh3elNvSzE2MVV6bzEwa2x1WG1HaXciLCJpc3N1ZWRBdCI6MTc3OTQ2MTE2M30.a953d8d9bbb62296647fa1f44f5de80832cb624a41ed1dffe5002c9b7206fcd6	437409341775398cb4c6c90d91a92f54baffc04a88cb2344ef40c3c3301b9ccc	2026-05-22 14:46:03.549734+00	\N	\N	2026-05-21 07:40:10.687376+00	2026-05-22 14:46:04.307377+00	\N
e287d63f-acab-41b3-a817-4a5d0df0ca6c	f826428f-03f1-42e7-8b49-9cece6730c32	952	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImUyODdkNjNmLWFjYWItNDFiMy1hODE3LTRhNWQwZGYwY2E2YyIsImV2ZW50SWQiOjMsInVzZXJJZCI6OTUyLCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoicjVOMjAtMVJFa1dySlV4WHJxOXI2USIsImlzc3VlZEF0IjoxNzc5OTU3MDA3fQ.2bed5232a3e696858ded3b155b82127660e127bc14bb07296e0c672a5c8e6968	7673c83e396a4caf13b51f52fff6b0c5f123d8d11a27203c8a42ea10bdef0ae1	2026-05-28 08:30:07.076767+00	\N	\N	2026-05-27 15:02:53.608635+00	2026-05-28 08:30:07.469354+00	\N
f910197d-6d6a-4097-a198-80102a613174	dae6f0ae-3b24-4c7c-ace4-8efec152bc1e	1431	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImY5MTAxOTdkLTZkNmEtNDA5Ny1hMTk4LTgwMTAyYTYxMzE3NCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTQzMSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Il82a0ZvZEJyNXpsRmdTNHRVa081VWciLCJpc3N1ZWRBdCI6MTc4MjM3MzcxNn0.247c1f7af5d327a177217be7e684367e0b0afa8129f22b21a207c16e9520ee41	21079415a4d712feccd50d5b5b1563f8fbcc45cbc84d7840d605d87d2a3a2ae4	2026-06-25 07:48:36.133924+00	\N	\N	2026-06-25 02:46:31.383476+00	\N	\N
e779b02b-16cf-441c-94b4-ea161e0da70d	64412946-5c27-46db-962a-fc166e755820	1162	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImU3NzliMDJiLTE2Y2YtNDQxYy05NGI0LWVhMTYxZTBkYTcwZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE2MiwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Illwd3NLYV8wMHoybTQ5TmE0cm1HcVEiLCJpc3N1ZWRBdCI6MTc4MDA4NzYwMH0.7031a7d1c808dfbb24b69a021bc96a104599a96b5b4df8ca3af9622c2cf83601	2981221f099d70eaeedb0c7ee9616456951626cf416c9e275938842744724236	2026-05-29 20:46:40.456415+00	\N	\N	2026-05-29 18:17:34.048437+00	2026-05-29 20:46:42.448449+00	\N
34916763-1059-47dc-bebf-5de5ad55bf21	9b07ada7-8913-4db0-bbb7-a293b6c366c1	274	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjM0OTE2NzYzLTEwNTktNDdkYy1iZWJmLTVkZTVhZDU1YmYyMSIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjc0LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiSF8tcU1KTVVkb2I0eW9ZTnBPTkgydyIsImlzc3VlZEF0IjoxNzc5OTU4NDQ1fQ.780e5876dcb242024325b26bc87e9f2c8fb34972a0520d213d6c544c0507e798	d1c4202be9bc4fa8569afc0f266466cdf93e828886e0e7d8252f6e70e2fe1205	2026-05-28 08:54:05.326798+00	\N	\N	2026-05-28 08:50:30.342119+00	2026-05-28 08:54:05.688945+00	\N
25d89876-3f01-484d-81b1-64e547900903	5a7c8e7b-227d-4f4f-a007-06bb884d01a8	1519	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjI1ZDg5ODc2LTNmMDEtNDg0ZC04MWIxLTY0ZTU0NzkwMDkwMyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTUxOSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Imp0WXRZWTBNVU83aDlESHVTTDQ4bmciLCJpc3N1ZWRBdCI6MTc4MjcyNDM2Nn0.cb17e578ab3cd7afa790dc3f2cf133d7c2378551814bd52268f656569397ff5e	18c8f39478a0ee76e236931034db72c53b8fef76329b49d430abf5950aa9d045	2026-06-29 09:12:46.304113+00	\N	\N	2026-06-29 09:07:37.65498+00	2026-06-29 09:12:46.685378+00	\N
bb097322-44c1-470d-acc9-28b1df1b775e	9b07ada7-8913-4db0-bbb7-a293b6c366c1	274	3	TRANSFER_THERE	1	eyJ0aWNrZXRJZCI6ImJiMDk3MzIyLTQ0YzEtNDcwZC1hY2M5LTI4YjFkZjFiNzc1ZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6Mjc0LCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfVEhFUkUiLCJxdWFudGl0eSI6MSwibm9uY2UiOiIyd1pBNGxEMG1FdTJwSFRxRGF0b2NRIiwiaXNzdWVkQXQiOjE3Nzk5NTg1ODJ9.d4680e3fadceba1a2b5c8646ff1b16a0387ebdd949e12dd32eb2c967043f3d73	8bbf8f78a2ca0df2e2a4b96aeb02e5fbcf2efc1a96349fd8979201fa66026fbc	2026-05-28 08:56:22.781717+00	\N	\N	2026-05-28 08:56:22.77162+00	2026-05-28 08:56:23.694716+00	\N
d8d41958-bb71-4f3f-8ae7-a29cf9ea2fd2	70213cfc-1133-4145-82c5-3be1a17a78bc	975	3	SINGLE	1	\N	\N	\N	\N	\N	2026-06-19 18:32:51.688694+00	\N	\N
e1baead9-4693-44f5-8161-7d88eff30f25	64412946-5c27-46db-962a-fc166e755820	1162	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImUxYmFlYWQ5LTQ2OTMtNDRmNS04MTYxLTdkODhlZmYzMGYyNSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE2MiwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6Im9jc1IwU1FGbVZNeWlBWG93Q2owTkEiLCJpc3N1ZWRBdCI6MTc4MDA4NzYwMH0.1bd0b246d04bce99c9d96c9506415a3fb404ce588565d415e7f3b8522d3015de	4b6bab80996cc30c08f6bfe7d2cfcc0b0208b1033d0650332e7896c713752d80	2026-05-29 20:46:40.456415+00	\N	\N	2026-05-29 18:17:34.048437+00	2026-05-29 20:46:41.945759+00	\N
928387ac-7f47-403f-ad98-8b9a5dbc5ade	2161e1f9-98b1-48d9-92aa-f569d032cc79	1	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjkyODM4N2FjLTdmNDctNDAzZi1hZDk4LThiOWE1ZGJjNWFkZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6InAxOERrYUtOQklGY2s4aUowRHJZNEEiLCJpc3N1ZWRBdCI6MTc4MDI1NzgxNn0.2cfa0354b235dd1981fc88104c806b0f9cc3daa1717f820653746d71fbd0aa50	124706a48661da6f8c01424cc9781992f2ae57fc975490f6d3e6df014a4916c1	2026-05-31 20:03:36.637378+00	\N	\N	2026-05-31 20:03:16.902788+00	2026-05-31 20:03:36.933457+00	\N
63dc1bb1-94d4-4a62-a6c8-65cbe6e43c6e	07085ac8-d7d2-4b1e-a7ad-ca46945ed43f	1187	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjYzZGMxYmIxLTk0ZDQtNGE2Mi1hNmM4LTY1Y2JlNmU0M2M2ZSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MTE4NywidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlNNX0htVFhrbUQ0cmxhU0xlVERyMnciLCJpc3N1ZWRBdCI6MTc4MDI2MDg3NH0.c50bb28050fddb21afdc0ae2ac1af832014937a03325e986c1d3a80290fd1cab	1d6e51a1b717c52eb5745a676cc7ac752e4f4cee2caf5b76bbb61c098d36fad2	2026-05-31 20:54:34.028272+00	\N	\N	2026-05-31 20:27:22.274237+00	2026-05-31 20:54:35.056281+00	\N
72a3050d-b76c-4780-ba30-1bcf34045224	5d4f35b5-e05a-48b6-8137-471f5922faac	485	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjcyYTMwNTBkLWI3NmMtNDc4MC1iYTMwLTFiY2YzNDA0NTIyNCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDg1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiT1Myall4ZFhqelRtU2xRWXpnUUR0QSIsImlzc3VlZEF0IjoxNzgwNDAwMDExfQ.0f3af9bc6f3a36b82d108dc9203212f33d6268a0538286c357211c647cde6126	62c11470670ae75efc140dbae4a369b6aa6ccef5ae7b984402f939253503b749	2026-06-02 11:33:31.49348+00	\N	\N	2026-06-02 11:09:54.374339+00	2026-06-02 11:33:32.124269+00	\N
da6e009e-2636-4534-9630-cfc209def4d4	5d4f35b5-e05a-48b6-8137-471f5922faac	485	3	SINGLE	1	eyJ0aWNrZXRJZCI6ImRhNmUwMDllLTI2MzYtNDUzNC05NjMwLWNmYzIwOWRlZjRkNCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NDg1LCJ0aWNrZXRUeXBlIjoiU0lOR0xFIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiblNCeWx3ekxjd2dfNUN3R2Z4UHU0QSIsImlzc3VlZEF0IjoxNzgwNDAwMDExfQ.eb1c70cdff189038e81963ea54952432d725e62061b4688d40ff43e7f23e514f	1a4bc65142cf8ee732760d6a792304389f14b20df0318a9507034722ed28b280	2026-06-02 11:33:31.49348+00	\N	\N	2026-06-02 11:09:54.374339+00	2026-06-02 11:33:32.588626+00	\N
5309556f-7090-4a61-9341-6f13e3910ec6	d9168caf-e58e-4404-b483-6bcd7f893be9	1	3	TRANSFER_THERE	2	eyJ0aWNrZXRJZCI6IjUzMDk1NTZmLTcwOTAtNGE2MS05MzQxLTZmMTNlMzkxMGVjNiIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1RIRVJFIiwicXVhbnRpdHkiOjIsIm5vbmNlIjoib3Jpd3FXcnVOMkpPWG5YWVAxalJoQSIsImlzc3VlZEF0IjoxNzgyMzAwOTc5fQ.a43248ebca86f4760a8184889e8ca82cf2f50cf7296e7d282208820077c25118	13de335395544d4f0ea8b255b241f37ddb91596a50f2bd35ee07a9ef70c790f7	2026-06-24 11:36:19.95039+00	\N	\N	2026-06-24 11:35:56.236815+00	2026-06-24 11:36:20.223945+00	\N
8baeee20-f904-4c29-81e0-3ea59e2c18f9	e71876a8-6650-43de-9ab7-1245de79badc	1	3	TRANSFER_ROUNDTRIP	3	eyJ0aWNrZXRJZCI6IjhiYWVlZTIwLWY5MDQtNGMyOS04MWUwLTNlYTU5ZTJjMThmOSIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlRSQU5TRkVSX1JPVU5EVFJJUCIsInF1YW50aXR5IjozLCJub25jZSI6Imk4d1JhTENXbGZFODFGb2FpREsyckEiLCJpc3N1ZWRBdCI6MTc4MjMwMDk4OH0.3d0269e2dcb42a7fdd450ccf057600416d6dba631c584cafdfd007803ed45da0	4bbc634fbc48558cf48e321933484b05dc1399cbe85cb294bdf1d95cb967e18d	2026-06-24 11:36:28.27712+00	\N	\N	2026-06-24 11:35:40.926409+00	2026-06-24 11:36:28.535298+00	\N
0b6328cf-d90b-462d-8889-77a8e32b71bd	dba9d347-0afc-45fd-b031-45f7b7d33f8e	782	3	TRANSFER_ROUNDTRIP	1	eyJ0aWNrZXRJZCI6IjBiNjMyOGNmLWQ5MGItNDYyZC04ODg5LTc3YThlMzJiNzFiZCIsImV2ZW50SWQiOjMsInVzZXJJZCI6NzgyLCJ0aWNrZXRUeXBlIjoiVFJBTlNGRVJfUk9VTkRUUklQIiwicXVhbnRpdHkiOjEsIm5vbmNlIjoiX3BpOFF0ci1lUHBxVkR0Z1BFWmtvdyIsImlzc3VlZEF0IjoxNzgyMzkxODQwfQ.319b4321a2bd29d17b4ecdf969b53d3f7552cfb83feae01956ecd35dea28366a	cfafb22f4eedafcefa89d5edbe1895e5e129437ed93d9e5f4fac9d52fabbdc2c	2026-06-25 12:50:40.46654+00	\N	\N	2026-06-25 12:19:05.265142+00	2026-06-25 12:50:40.944075+00	\N
2a208540-f65b-4892-a801-f3c5a2181acc	bec29e45-540c-48f6-be25-1fa5b9eb70ba	1	3	SINGLE	1	eyJ0aWNrZXRJZCI6IjJhMjA4NTQwLWY2NWItNDg5Mi1hODAxLWYzYzVhMjE4MWFjYyIsImV2ZW50SWQiOjMsInVzZXJJZCI6MSwidGlja2V0VHlwZSI6IlNJTkdMRSIsInF1YW50aXR5IjoxLCJub25jZSI6IlFoMHIwVnpzZ3gxcnpMSlU3emwtd3ciLCJpc3N1ZWRBdCI6MTc4MjczMTg1MH0.31f8af13d3a82b291031105014e79a4f0bfe1308ca2c565746558bad0f804b5f	3c4c2d696676dfdfb0a8a1a5ec8055957ceda1198d861797ad9e8d78d713edca	2026-06-29 11:17:30.328378+00	\N	\N	2026-06-29 11:16:55.737965+00	2026-06-29 11:17:30.662335+00	\N
67422aab-7017-402a-b859-3edd393d3fde	1d54ef8f-cb6b-4838-b955-6dea05945a45	1	3	GROUP10	10	\N	\N	\N	\N	\N	2026-07-02 10:18:21.601314+00	\N	\N
\.


--
-- Data for Name: transfer_products; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.transfer_products (id, event_id, direction, price_cents, info_json, inventory_limit, sold_count, is_active, created_by, created_at, updated_at, name) FROM stdin;
222e1b0c-129d-4e34-98f8-f83c5c642dd9	3	THERE	250000	{"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ладожский"}	\N	11	t	1	2026-04-21 20:13:55.709986+00	2026-06-27 06:11:16.576326+00	Трансфер СПБ-SPACE
b8aed809-f1a5-458e-a517-2175ade76493	3	ROUNDTRIP	450000	{"time": "12.00", "notes": "Точное место придет в сообщении в боте", "pickupPoint": "Ladoga"}	\N	6	t	1	2026-04-21 20:16:57.258498+00	2026-07-01 08:05:42.725524+00	Трансфер СПБ-SPACE-СПБ
4b22e975-cdae-4b7d-a89d-89de825e101a	3	BACK	250000	{"time": "16.20", "notes": "", "pickupPoint": ""}	\N	1	t	1	2026-05-19 08:40:53.61518+00	2026-06-20 09:06:41.57939+00	SPACE-СПБ
\.


--
-- Data for Name: user_contact_matches; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.user_contact_matches (user_id, contact_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_push_tokens; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.user_push_tokens (id, user_id, platform, token, device_id, app_version, locale, is_active, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.users (id, telegram_id, username, first_name, last_name, photo_url, created_at, updated_at, last_location, last_seen_at, rating, rating_count, balance_tokens, is_blocked, blocked_reason, blocked_at) FROM stdin;
231	1709412421	turnonforest	🌿Денис🌿	\N	https://t.me/i/userpic/320/MOxlWsRAAipSH51Km6HLWtu8h5-DqoTd-8BLFgYpZr8.svg	2026-02-14 12:28:31.58848+00	2026-02-14 12:28:32.653625+00	\N	2026-02-14 12:28:31.58848+00	0.00	0	100	f	\N	\N
56	1470769403	Annushka_Adamovna	Tellura	\N	https://t.me/i/userpic/320/c9qge8O6zS2RVIGKTgq8Gm5nOGtreU8Nf8tlbpI0ve4.svg	2026-02-11 21:07:12.86161+00	2026-02-11 21:07:29.561262+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-11 21:07:29.561262+00	0.00	0	0	f	\N	\N
256	380594944	Vasio87	Basil	\N	https://t.me/i/userpic/320/-drTjcjFG2IitU4aWlVMu_VE80ytC5XkIHjxHlukS4Y.svg	2026-02-14 13:41:24.969215+00	2026-02-14 13:41:24.969215+00	\N	2026-02-14 13:41:24.969215+00	0.00	0	0	f	\N	\N
374	741274653	belymbelom2	Александр	\N	https://t.me/i/userpic/320/hvPcIimQID3sOFWOlUQDrufMVBUxxKygV7TFGm6GxlQ.svg	2026-02-17 12:18:13.666839+00	2026-02-17 12:18:13.666839+00	\N	2026-02-17 12:18:13.666839+00	0.00	0	0	f	\N	\N
473	6807970759	trololo232	Den4ik	\N	https://t.me/i/userpic/320/5nAMZypzqADsVJ_fUyu1BpZuLrdTh8bcqPvo5R8t63FBFDNSoCASeeHn5CycjwL1.svg	2026-02-20 20:28:45.510997+00	2026-02-20 20:28:45.510997+00	\N	2026-02-20 20:28:45.510997+00	0.00	0	0	f	\N	\N
239	428512698	Nightdamn	Дмитрий	\N	https://t.me/i/userpic/320/nOI8a4qxI97m3m5q-3_jn8AvEvY9iNQazS9_eqqOULY.svg	2026-02-14 12:51:29.706535+00	2026-06-23 12:40:59.419558+00	\N	2026-06-23 12:40:59.419558+00	0.00	0	0	f	\N	\N
697	506674112	mihailredstar	Михаил	Юриков	https://t.me/i/userpic/320/eVybVBdNayGlYOeCMk-3ZDBuDC_VmxhygX5f4cD53wg.svg	2026-03-06 18:45:23.914165+00	2026-03-06 18:45:23.914165+00	\N	2026-03-06 18:45:23.914165+00	0.00	0	0	f	\N	\N
548	1007530620	K_Plotnikoff	K.	Plotnikoff	https://t.me/i/userpic/320/RxqJQIarZXu2ABGpEtHLx3FraMv3zJqJ8JBwihvllRQ.svg	2026-02-21 17:14:00.198746+00	2026-02-21 17:14:00.198746+00	\N	2026-02-21 17:14:00.198746+00	0.00	0	0	f	\N	\N
1037	8723614563	FuckOffShit89	Серж	\N	https://t.me/i/userpic/320/S7QOEqw2KDLjA3tq_Me3M9qMujUVTJPKb9trYsUmcVWnSw1u5xRDoE6M_gAU0nPW.svg	2026-05-17 08:22:19.399429+00	2026-05-17 08:22:19.399429+00	\N	2026-05-17 08:22:19.399429+00	0.00	0	0	f	\N	\N
178	6758095321	AudioHallu	AudioHallu	\N	https://t.me/i/userpic/320/Fl5cPQJnHX6QguuEQmTb-Mc-__sidFbx4qVmrLhblG3p-rFB-QU992_gXGI03C_7.svg	2026-02-14 07:14:20.077591+00	2026-02-14 07:14:20.439552+00	\N	2026-02-14 07:14:20.077591+00	0.00	0	100	f	\N	\N
8	7576937698	newmoona	Айрида	OooDa	https://t.me/i/userpic/320/2Zh8ii_l0AlH8e-ahW1ZDNS56B0eZU28vsDXibt0k5I9UhlhWh-Pgk2zZY6ANQHt.svg	2026-02-09 16:15:45.898264+00	2026-02-14 11:51:48.276092+00	0101000020E6100000C48664FD6A3B53400D7265085C9F4540	2026-02-14 11:51:48.276092+00	0.00	0	0	f	\N	\N
179	6859088623	\N	Вадян_ой	\N	https://t.me/i/userpic/320/OQcgp9U7kLmVyFPIaHZUmLzFRFTkTmHu8B-SzIgVgqEgWsd29O3rM2dVHZNw3Fce.svg	2026-02-14 07:14:21.454183+00	2026-02-14 07:14:21.981501+00	\N	2026-02-14 07:14:21.454183+00	0.00	0	100	f	\N	\N
51	5117470178	TimofeyChelbaev	Тимофей	Челбаев	https://t.me/i/userpic/320/69O3Y5Nz_Wdn1GRzP0Yd0qL_SdmxhlVMUwEKmoG2duLahEYAM9whYMEcEdrtd0q5.svg	2026-02-11 16:46:54.213268+00	2026-02-12 22:34:31.047686+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-12 22:34:31.047686+00	0.00	0	0	f	\N	\N
698	1119662352	Spearman1988	артем	ерошин	https://t.me/i/userpic/320/M0OzL5UKyKqb9K3tbx88Obr9HmFI_VMmFKWO437B47c.svg	2026-03-06 18:51:42.140109+00	2026-03-06 18:51:42.140109+00	\N	2026-03-06 18:51:42.140109+00	0.00	0	0	f	\N	\N
58	1449127672	Lynoxod	Михаил	\N	https://t.me/i/userpic/320/6p6cys0bnASuItmgFbExp_N-s_I_VcbkG4z6BHHRnkw.svg	2026-02-12 10:19:09.949584+00	2026-04-06 09:55:26.801927+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-06 09:55:26.801927+00	0.00	0	0	f	\N	\N
145	202078851	lerikorner	Valery	Z	https://t.me/i/userpic/320/_ss6BtvfppUnsM4JQ3WYKdlsNkcdnHwBBSx6F3HDLUQ.svg	2026-02-13 18:38:26.967088+00	2026-02-14 07:23:24.506464+00	\N	2026-02-14 07:23:24.506464+00	0.00	0	0	f	\N	\N
198	299551847	Varga108	Dmitriy	VargA	https://t.me/i/userpic/320/WdUPHwWHgwT693VV5Lya2-VVTKj5CdDjSfsRcOkudno.svg	2026-02-14 10:38:01.832172+00	2026-03-06 15:59:51.886671+00	\N	2026-03-06 15:59:51.886671+00	0.00	0	100	f	\N	\N
323	1450218842	gypsycrew	gipsy	crew	https://t.me/i/userpic/320/bQHwZt7PqZm8Z76DpZaFc_BljdM5WtzM4ksMhvvnLxw.svg	2026-02-15 05:55:08.132344+00	2026-05-16 14:50:59.798348+00	\N	2026-05-16 14:50:59.798348+00	0.00	0	0	f	\N	\N
47	1408139216	chikipukiolyalya	Оленька	\N	https://t.me/i/userpic/320/00tgMEnnRotcB2Q2QS-ViyGaC4mQyXnXhYZjP_QZzbg.svg	2026-02-11 08:23:50.736118+00	2026-02-14 07:28:57.959654+00	\N	2026-02-14 07:28:57.959654+00	0.00	0	0	f	\N	\N
573	1110473643	dimonoo_aum	dimonoo	\N	https://t.me/i/userpic/320/2r9EPXVdwE6hwcYvuA5V8rEOjwx5asGsGNNxFOop248.svg	2026-02-22 17:22:09.266339+00	2026-03-06 18:08:12.820324+00	\N	2026-03-06 18:08:12.820324+00	0.00	0	0	f	\N	\N
134	748473174	sasha_september	Александра	Смирнова	https://t.me/i/userpic/320/xLlDd1OuBkT0cWbuvJ4m4ixlG4kyBewpNsx__EjiuRo.svg	2026-02-13 13:37:11.967829+00	2026-02-13 18:13:52.79856+00	\N	2026-02-13 18:13:52.79856+00	0.00	0	0	f	\N	\N
180	6516999403	\N	Семëн	\N	https://t.me/i/userpic/320/KOkGt3UwolGE439mVH72UCp8DXv9a85kJVp51RSiWNQ-Eoz6gN_vvexrNYIxMGlK.svg	2026-02-14 07:15:03.184573+00	2026-02-14 07:36:03.872395+00	\N	2026-02-14 07:36:03.872395+00	0.00	0	100	f	\N	\N
204	556543104	omstuff88	Om	Stuff	https://t.me/i/userpic/320/LtnLzbXTsfNPHh8Q8_8enuCZX8ZuUVHZkUfI-tDrYOs.svg	2026-02-14 11:51:08.632607+00	2026-02-19 18:38:26.43759+00	0101000020E61000008D3CA2EE90FD4240CBED039A86E74B40	2026-02-19 18:38:26.43759+00	0.00	0	0	f	\N	\N
187	270441835	Defytone	Da	Mir	https://t.me/i/userpic/320/UMK0NsfQ3uwZP0eCJcIualr8yAvy2vN1FKsYYtGsidc.svg	2026-02-14 07:45:24.417181+00	2026-02-14 07:45:26.42643+00	\N	2026-02-14 07:45:24.417181+00	0.00	0	100	f	\N	\N
9	566432291	Meinherzj	Vitali	\N	https://t.me/i/userpic/320/YIwSI2ClY7AXY9U2lrpYlexsYM16Bc2cYV-D853doRY.svg	2026-02-09 19:02:02.310697+00	2026-02-09 19:06:04.15079+00	\N	2026-02-09 19:06:04.15079+00	0.00	0	0	f	\N	\N
188	5922897020	\N	Ольга.	\N	https://t.me/i/userpic/320/sHRWkbbM7XyM_-6gKEAdvH5iGa8kv4vUcb9t_xJJlTUfxafo_TNGleiUBFqrinNn.svg	2026-02-14 07:55:27.746222+00	2026-02-14 07:55:27.910018+00	\N	2026-02-14 07:55:27.746222+00	0.00	0	100	f	\N	\N
132	375442215	input_n4m3	Dev	\N	https://t.me/i/userpic/320/WF2x_6yNH5lBqYayOfagy5v-PwVx3VsZ9RUMpKhry40.svg	2026-02-13 13:24:22.220173+00	2026-02-19 18:48:23.244283+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-19 18:48:23.244283+00	0.00	0	0	f	\N	\N
65	1448344320	SolarAlice1	Алиса	Малыгина	https://t.me/i/userpic/320/Cm0DIpOCv3FzfgbcjgptfpNeoJELl5LvdpFFrkbekGc.svg	2026-02-12 15:04:28.018877+00	2026-02-12 15:07:17.478164+00	0101000020E61000002C222F10A9144140D7868A71FE3E4640	2026-02-12 15:07:17.478164+00	0.00	0	0	f	\N	\N
190	941662314	LATiN0Z	LATiNOS	ᅠ	https://t.me/i/userpic/320/8Zzy7M5QqlX2I14W7v_-36Iy_s9bgTO3iinnhz9XIyg.svg	2026-02-14 08:16:43.685904+00	2026-02-14 08:19:02.549743+00	0101000020E6100000224CE4B0D3613E40C2C7A7018EFC4D40	2026-02-14 08:19:02.549743+00	0.00	0	0	f	\N	\N
7	5051777977	Kungfuoko	Kung	Fu	https://t.me/i/userpic/320/bFcanM8WtohmQLuAb2IlMJUZSHO0Chh5Y1qA2B72O_7Z2hlGDXtKQGl9uSJODBuU.svg	2026-02-09 14:05:12.37727+00	2026-02-10 10:33:28.220631+00	\N	2026-02-10 10:33:28.220631+00	0.00	0	0	f	\N	\N
191	2118152234	Feklafedor	Мран Белочь Рыжъ	\N	https://t.me/i/userpic/320/JzUkleCmJsiHQv9UdCNTV97TdvCbgQMuvAn27-EkngI.svg	2026-02-14 08:46:42.580967+00	2026-02-14 08:46:46.104528+00	\N	2026-02-14 08:46:42.580967+00	0.00	0	100	f	\N	\N
192	247133206	olga_webversion	Ольга 🍀 Web & nature	\N	https://t.me/i/userpic/320/HdQmXiFtq02HnX-Qje-Dipv7uveeIZeHz0rHnnA2fcQ.svg	2026-02-14 08:50:33.379443+00	2026-02-14 08:50:33.478797+00	\N	2026-02-14 08:50:33.379443+00	0.00	0	100	f	\N	\N
193	1530344493	Agen3327	Денис	Пирожок	https://t.me/i/userpic/320/9Is5TpHrO5aHr_Nh0sBAANhIl5ARbyPIXjVDBPifbfI.svg	2026-02-14 09:05:52.534478+00	2026-02-14 09:06:11.09417+00	\N	2026-02-14 09:06:11.09417+00	0.00	0	0	f	\N	\N
43	7474382064	Ptfro	Potifer	\N	https://t.me/i/userpic/320/c0HxLOIuNmNP-oU9XaCl-ffp1cEHLPzervoaAIJwusSA_6NBlgfPkSwLQ-sTmg_S.svg	2026-02-11 03:56:36.379489+00	2026-02-11 03:57:13.184318+00	0101000020E610000029487FC193CD4240169C076AE5D34B40	2026-02-11 03:57:13.184318+00	0.00	0	0	f	\N	\N
200	906949632	webcard	Denis	Shulga	https://t.me/i/userpic/320/LsCR8TIo3yoTT8EzsXDjHNj-HObquh66bO2prGgIP5I.svg	2026-02-14 11:08:39.121768+00	2026-02-14 11:09:40.49103+00	0101000020E6100000D12B7056E20941409108F5D91A604640	2026-02-14 11:09:40.49103+00	0.00	0	0	f	\N	\N
137	1304680416	\N	Наталия 🧚‍♀️	\N	https://t.me/i/userpic/320/jx9reDx8wqiYdxcgfL57b6vA38xZF8c7-hPGE6FTzEs.svg	2026-02-13 14:36:45.378796+00	2026-02-14 11:23:27.212963+00	\N	2026-02-14 11:23:27.212963+00	0.00	0	0	f	\N	\N
1462	391874473	DenDenisovich	den	den	https://t.me/i/userpic/320/VxUd6Ae9UWva4XQF4bbz4EA7gprdBHQlKMG9mArxi1k.svg	2026-06-25 15:14:45.291654+00	2026-06-25 15:14:45.291654+00	\N	2026-06-25 15:14:45.291654+00	0.00	0	0	f	\N	\N
670	321237203	irakotina	Ира	Котина	https://t.me/i/userpic/320/Q5e_pMTMfRPar_o72Lj1HxZwyMwg00hV1sHDjDDOwpM.svg	2026-03-05 17:12:07.460672+00	2026-03-05 17:12:09.66333+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-05 17:12:09.66333+00	0.00	0	0	f	\N	\N
1267	568108581	tech_rd	Din	\N	https://t.me/i/userpic/320/wxhVm4ciTCOWdGvOWrzXtFfi-kt6t5sVcEDFfLfOejw.svg	2026-06-07 23:04:53.064164+00	2026-06-07 23:04:53.064164+00	\N	2026-06-07 23:04:53.064164+00	0.00	0	0	f	\N	\N
578	807646088	PavlovAlexeyDCM	А	\N	https://t.me/i/userpic/320/nDmD1vpFvHp3zfd4ZjSVKvnhsXolWaC7K8tWRQRo0R8.svg	2026-02-23 13:32:57.166882+00	2026-02-23 13:32:57.166882+00	\N	2026-02-23 13:32:57.166882+00	0.00	0	0	f	\N	\N
212	117687812	mi_shk	✨	\N	https://t.me/i/userpic/320/BafLv_KjOwSfqptGs9e4NqL7gMmYfW70aiYjX2wcRkg.svg	2026-02-14 11:55:17.961442+00	2026-02-21 11:34:39.303407+00	\N	2026-02-21 11:34:39.303407+00	0.00	0	0	f	\N	\N
484	300226937	Sammoise	Samwise	Gamgee	https://t.me/i/userpic/320/APW4rkhzrY9-gSxczNeey7Tv16-WYb_WMP3AXiAJnnI.svg	2026-02-21 06:50:23.415244+00	2026-03-07 12:25:22.288648+00	\N	2026-03-07 12:25:22.288648+00	0.00	0	0	f	\N	\N
887	968255135	Realtorr	A.	Realtorr	https://t.me/i/userpic/320/EBULU7q5cFiDSwisbg7bUWmNNM-W5deeGRjRguMy5Uo.svg	2026-04-21 12:27:56.971126+00	2026-04-21 12:27:56.971126+00	\N	2026-04-21 12:27:56.971126+00	0.00	0	0	f	\N	\N
207	276406263	floraonsand	ẋsn	\N	https://t.me/i/userpic/320/9H2hgZZSg0N1JTFt0emsjnCPe_zauteVtnIH6ZDFanE.svg	2026-02-14 11:51:21.314029+00	2026-02-21 23:13:43.932822+00	\N	2026-02-21 23:13:43.932822+00	0.00	0	0	f	\N	\N
900	5683083	snusnu4o	Илья	\N	https://t.me/i/userpic/320/5q4Tc5X5lbP_zZzJc3LzaLhdWwBJVfXyV13NEqXVNcc.svg	2026-04-25 13:45:14.626196+00	2026-04-25 13:45:14.626196+00	\N	2026-04-25 13:45:14.626196+00	0.00	0	0	f	\N	\N
728	501752804	katdevise	Katy	Devise	https://t.me/i/userpic/320/MXmIUG6BCyBqebh1EOyU-zlfHDKPdWzXidY6FLBjOko.svg	2026-03-07 12:52:40.365853+00	2026-03-07 12:52:40.365853+00	\N	2026-03-07 12:52:40.365853+00	0.00	0	0	f	\N	\N
940	505373266	AnnushFed	Anna Fed	\N	https://t.me/i/userpic/320/6M8F4FPdp2ElSJsYd1OOsq5wnTbdEM7JpgzowzVG9OU.svg	2026-05-09 18:33:54.689063+00	2026-05-09 18:33:54.689063+00	\N	2026-05-09 18:33:54.689063+00	0.00	0	0	f	\N	\N
524	658487430	mikha604	Mik-Ha	604	https://t.me/i/userpic/320/rPb595if8M2HSb8uybmgvf6un07T1UzNFM54bRq5xIg.svg	2026-02-21 13:17:49.73205+00	2026-02-21 13:17:51.903555+00	\N	2026-02-21 13:17:49.73205+00	0.00	0	100	f	\N	\N
205	791821962	tryptamine25	Alexandr	\N	https://t.me/i/userpic/320/O4YyZr2Fe_8OSRY5yFYHN3m_NIVEp_qN6krUSCt8Z_c.svg	2026-02-14 11:51:09.462883+00	2026-05-13 19:01:55.856117+00	\N	2026-05-13 19:01:55.856117+00	0.00	0	0	f	\N	\N
209	1368670953	Don_digid0n	Don	Digidon	https://t.me/i/userpic/320/B9TY4HFsxfBs9aWR8wV0JIErk8dCupEWp5reZsWGLYE.svg	2026-02-14 11:52:00.011237+00	2026-03-05 07:29:09.64825+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-05 07:29:09.64825+00	0.00	0	0	f	\N	\N
258	1252831488	Ukusila	ukusila	\N	https://t.me/i/userpic/320/kIvXhnIVAHIIacSuwRp2p9WUqueTz1QWp3NSB9mWT8A.svg	2026-02-14 13:41:27.987301+00	2026-02-14 13:44:25.89847+00	0101000020E6100000E7091250823E3E40C8DB5F0496F94D40	2026-02-14 13:44:25.89847+00	0.00	0	0	f	\N	\N
282	1182717756	ReklamaFilin	Иван	\N	https://t.me/i/userpic/320/cPlH1leXfnWII0yqwXvki90EzuMoq2u2CEISUDPBjnw.svg	2026-02-14 15:18:37.577171+00	2026-05-20 10:38:29.348754+00	\N	2026-05-20 10:38:29.348754+00	0.00	0	0	f	\N	\N
232	395667091	Orexxxl	Юля	Орех	https://t.me/i/userpic/320/9bRgH2KesDTRcsr5JCfJtNOhxZ3Hh7ILlYA4FakHb9U.svg	2026-02-14 12:29:20.423435+00	2026-02-14 12:29:20.423435+00	\N	2026-02-14 12:29:20.423435+00	0.00	0	0	f	\N	\N
247	421228663	roma_my_nigga	Roman	\N	https://t.me/i/userpic/320/Hnf6ivr915yA_Q2m56Z4CR61III6bbKFJPW4eL2hmkk.svg	2026-02-14 13:22:51.641954+00	2026-02-21 13:57:56.839938+00	\N	2026-02-21 13:57:56.839938+00	0.00	0	0	f	\N	\N
1577	8456317294	gennsmeta	Геннадий	Л.	https://t.me/i/userpic/320/9FtpA7y4w9qFP12PYDycEFko90cnifPfUSu8HWCi_V5aSp1WPiYGz0o_VVAwHhEe.svg	2026-07-02 00:11:48.736339+00	2026-07-02 00:11:48.736339+00	\N	2026-07-02 00:11:48.736339+00	0.00	0	0	f	\N	\N
261	374040742	MariiMarii	Мария	Коноплёва	https://t.me/i/userpic/320/-iGIH4wF8uIS9BywEDaalpPVHrqapnWC9p79M88IZfA.svg	2026-02-14 13:55:08.271905+00	2026-07-01 05:39:00.771149+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 05:39:00.771149+00	0.00	0	0	f	\N	\N
712	76441919	EDarkside	E	R	https://t.me/i/userpic/320/yFc1K9uzHVb9Sfkv5jCTNbM0FQ7AYutpB7DH4XbRm5c.svg	2026-03-07 05:44:33.735482+00	2026-03-07 05:44:33.735482+00	\N	2026-03-07 05:44:33.735482+00	0.00	0	0	f	\N	\N
343	824654028	Mamawa9	MisteR Di	\N	https://t.me/i/userpic/320/zdcHwaLhV2QTaQHheV7suhRIcsl38bx1_tY57izGrbA.svg	2026-02-15 17:14:08.673961+00	2026-04-16 13:40:34.660497+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-16 13:40:34.660497+00	0.00	0	0	f	\N	\N
233	250131649	yaRaSvetMara	ЯRa	SvEtMara ♫╰▐.w.▐♫	https://t.me/i/userpic/320/o_tJ_t0VniV0P1tiXl4jXymW7I3uVZ1R8KFx4SsTcZU.svg	2026-02-14 12:35:57.713227+00	2026-02-14 12:36:16.030666+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-14 12:36:16.030666+00	0.00	0	0	f	\N	\N
264	388060547	Bushemi13	Vitaly Bushemi	\N	https://t.me/i/userpic/320/TZh9Oq5In80StNlLXc30dizbQPAkOsTDUSlXRYG1BHg.svg	2026-02-14 14:10:18.294724+00	2026-07-01 07:47:36.745898+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 07:47:36.745898+00	0.00	0	0	f	\N	\N
225	765371089	gardenmasta	Воображение	Бесконечно	https://t.me/i/userpic/320/u9hDHiW5CcPjjWMVVh1mXpKaWkwfIhmTMniRN8r0YmQ.svg	2026-02-14 12:18:15.112376+00	2026-02-14 12:18:15.112376+00	\N	2026-02-14 12:18:15.112376+00	0.00	0	0	f	\N	\N
227	215020	ayy_ka	S౮૯੮૦ઽคՐ	\N	https://t.me/i/userpic/320/jH3EhE8Nyq1J_XAHwpvSln8BxOAtX5_ahKC3nciMQ18.svg	2026-02-14 12:24:21.820536+00	2026-02-14 12:36:37.373353+00	\N	2026-02-14 12:36:37.373353+00	0.00	0	0	f	\N	\N
213	432716364	slava_shu555	Slava Shu	\N	https://t.me/i/userpic/320/Q7EU-FRf9hBBXm4HdQL5Ld9O3hpvAYUI41pf699FdRU.svg	2026-02-14 12:02:47.181622+00	2026-02-21 14:31:48.901806+00	\N	2026-02-21 14:31:48.901806+00	0.00	0	0	f	\N	\N
226	5104585310	LeL_iaaa	LELIA	\N	https://t.me/i/userpic/320/Yqgoit4_D5kzQsasdl-euz_EWUHO7bxTQ3HnmkIVlXCjH8NMZmxr484s9dyLjA2n.svg	2026-02-14 12:22:38.207238+00	2026-02-14 12:26:10.390008+00	\N	2026-02-14 12:26:10.390008+00	0.00	0	100	f	\N	\N
253	446529558	Victorrr7	Victorrr विजेता	Victorrr	https://t.me/i/userpic/320/m7I5C-M4PKjKiYXJXHNUFwf4lkRbFITt1Xtnyg4wuu4.svg	2026-02-14 13:35:45.895618+00	2026-06-23 15:03:06.503703+00	0101000020E6100000BA49B148B8613E409365D2F077FB4D40	2026-06-23 15:03:06.503703+00	0.00	0	0	f	\N	\N
715	778338820	DCP_PRODuction	Lev	\N	https://t.me/i/userpic/320/30wi-i1jnrx2Skgo4_4bzwPPbhCRI21j9_r0gEhnmno.svg	2026-03-07 06:23:54.0322+00	2026-03-07 06:23:54.0322+00	\N	2026-03-07 06:23:54.0322+00	0.00	0	0	f	\N	\N
236	206849628	intramurti	Evan	\N	https://t.me/i/userpic/320/Gu6ofDUQfVAVAv2rjtJZ5EXVgusgTiraVhRv6uOWsqE.svg	2026-02-14 12:42:20.790431+00	2026-02-14 12:43:10.720542+00	0101000020E6100000A98349D7E1E04240DA1BE03CF9D94B40	2026-02-14 12:43:10.720542+00	0.00	0	0	f	\N	\N
242	205681903	archigene	Евгений	Кондобаров	https://t.me/i/userpic/320/uwe5jQ8oHziPJ-se2mr-qs8ygNC95FNHQzFFhi40mcQ.svg	2026-02-14 12:57:27.218073+00	2026-02-14 12:57:27.218073+00	\N	2026-02-14 12:57:27.218073+00	0.00	0	0	f	\N	\N
243	451654735	irnlbtprt	🍄	\N	https://t.me/i/userpic/320/GZy-cR0kyGzRax8R5q0UyjmOX5sMmxpImengTnN-9qA.svg	2026-02-14 13:00:33.539573+00	2026-02-14 13:00:33.539573+00	\N	2026-02-14 13:00:33.539573+00	0.00	0	0	f	\N	\N
244	1894854522	pzzDuDezzz	Афанисий	Фет	https://t.me/i/userpic/320/8v0dzQWCVL-gC2KFhOg_OeEei_SQ0GpL0Mb3vAPiEVs.svg	2026-02-14 13:15:03.680331+00	2026-02-14 13:15:03.680331+00	\N	2026-02-14 13:15:03.680331+00	0.00	0	0	f	\N	\N
268	527773682	Julia_HolyHealth	Julia	Magdebura	https://t.me/i/userpic/320/u4Sx0KO9b4Rsr5CYeSpFEPHNstKIb0jtgHqvyEHFfHQ.svg	2026-02-14 14:25:33.955293+00	2026-02-14 14:25:33.955293+00	\N	2026-02-14 14:25:33.955293+00	0.00	0	0	f	\N	\N
245	6276322284	\N	.. VаtiMari ..	\N	https://t.me/i/userpic/320/DEjQmjkmmXcjiRx8WDSL6_PQKjVTar6H34mkFVgJ3ZgiYyVHQHdCzbbdGqk4f6MJ.svg	2026-02-14 13:19:02.442192+00	2026-02-14 13:21:14.584213+00	\N	2026-02-14 13:21:14.584213+00	0.00	0	0	f	\N	\N
252	605625930	\N	Pasha	Dyakov	https://t.me/i/userpic/320/Id_o9keYLeCjk0rZGAuAHfqRjT8bf6IFjM2c-dabEZg.svg	2026-02-14 13:33:15.125141+00	2026-02-14 13:39:40.381178+00	0101000020E61000007C4455D7BF583E40A1A107745FEA4D40	2026-02-14 13:39:40.381178+00	0.00	0	0	f	\N	\N
1206	663632405	AlesyaEnsimus	Алеся	\N	https://t.me/i/userpic/320/nnef6Fyyvxw71O5GzKwendoXfVZasiv-2NXwPPga_Wg.svg	2026-06-02 18:02:22.294588+00	2026-06-02 18:02:22.294588+00	\N	2026-06-02 18:02:22.294588+00	0.00	0	0	f	\N	\N
276	1710262749	captainlove8	Капитан Любовь	\N	https://t.me/i/userpic/320/ftnIaYY80SqYomARcCK0adHpoTttUThJ4Wmhvk-eCZI.svg	2026-02-14 14:50:11.968776+00	2026-02-14 14:51:38.509667+00	0101000020E6100000B1CC3C5C85483E40783CE11138F94D40	2026-02-14 14:51:38.509667+00	0.00	0	0	f	\N	\N
300	1443716987	fr33_hugz	Антон	Мо	https://t.me/i/userpic/320/JhEGqKuS5j4HHq83TmoWoLNqDiR5WNk-uuD1QpQSglE.svg	2026-02-14 17:30:15.643779+00	2026-02-14 17:30:15.643779+00	\N	2026-02-14 17:30:15.643779+00	0.00	0	0	f	\N	\N
671	342308291	AndreasRadomirus	Andreas	Sandals	https://t.me/i/userpic/320/7VX7oF7iTUHvO5rPyZ5lSXpccS6IFqhKDlttpRk0m6c.svg	2026-03-05 20:19:59.008652+00	2026-03-05 20:19:59.008652+00	\N	2026-03-05 20:19:59.008652+00	0.00	0	0	f	\N	\N
321	75678709	rromanoff	Roman	Romanov	https://t.me/i/userpic/320/dh9Ori9naN2C6U3WjnO3iIbNbdSN09hPo9bMpirZda8.svg	2026-02-15 05:43:32.203883+00	2026-02-15 18:32:25.975844+00	\N	2026-02-15 18:32:25.975844+00	0.00	0	0	f	\N	\N
1425	87834126	Ghostesky	Ghost 👻	\N	https://t.me/i/userpic/320/_b5yYmsnxsvi0UeDsbC4vqXiHmlM3pKy4NqQSQ6_pA8.svg	2026-06-23 15:03:01.51791+00	2026-06-23 15:03:01.51791+00	\N	2026-06-23 15:03:01.51791+00	0.00	0	0	f	\N	\N
313	5704527221	\N	ILYA	\N	https://t.me/i/userpic/320/xym6OHt18nc2cHSooZTvfhLxDuE_PWjyy6Nr8aKiwznfw-uXWsFTuF4edz7dwJvJ.svg	2026-02-14 21:42:58.264266+00	2026-02-21 23:57:51.559538+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-21 23:57:51.559538+00	0.00	0	0	f	\N	\N
886	523153601	idimimo	díɑɢonɑӀ	\N	https://t.me/i/userpic/320/7K13ADN69i_drzCT2rnWw8rK6305_BOrpsk_qEabIM8.svg	2026-04-21 09:13:41.825954+00	2026-05-16 12:14:15.061349+00	\N	2026-05-16 12:14:15.061349+00	0.00	0	0	f	\N	\N
318	264731041	Oleg_53r	Oleg	53	https://t.me/i/userpic/320/gubso_7dMuY5lVBN5-fB2OGnKXi__-O2_kZewpFgF_Y.svg	2026-02-15 03:15:09.224152+00	2026-03-23 14:32:16.625279+00	0101000020E6100000457CC57A9233454021FDCC9088232040	2026-03-23 14:32:16.625279+00	0.00	0	0	f	\N	\N
1170	7760321591	azztattoo	Andrey	Zubarev	https://t.me/i/userpic/320/Dsl_1eLeg6QSdHwk5BCs9T3_lfIvsk_p-G1oQsOkMYGprCocoQiWFVvDbn94XVW7.svg	2026-05-30 14:14:40.062148+00	2026-05-30 14:14:40.062148+00	\N	2026-05-30 14:14:40.062148+00	0.00	0	0	f	\N	\N
950	7019164437	Forest_trump_is_back	Forest	Trump	https://t.me/i/userpic/320/FFdFh5vqN5o1ARkMY4Z08VENhrZWd2ajAhZMwYGku7XdaXhZpU5DqjkON0Z_WyWA.svg	2026-05-10 14:30:40.236741+00	2026-05-10 14:30:40.236741+00	\N	2026-05-10 14:30:40.236741+00	0.00	0	0	f	\N	\N
319	165003638	makkesev	Игорь	Бриз	https://t.me/i/userpic/320/W4yLqPXpTgUV9ZGBvQXmKGnAThCUvag62lsP8mTxFVM.svg	2026-02-15 04:46:33.165253+00	2026-02-21 11:32:07.538896+00	0101000020E610000028D0CC38B2C240408463963D094A4640	2026-02-21 11:32:07.538896+00	0.00	0	0	f	\N	\N
765	427439290	\N	Danila	Master	https://t.me/i/userpic/320/ZDZnS3r4o8EefmuC7aZKvHSGTobgu2_hZ6x6bZ4pjRk.svg	2026-03-09 05:57:13.787843+00	2026-03-09 05:57:13.787843+00	\N	2026-03-09 05:57:13.787843+00	0.00	0	0	f	\N	\N
1115	67007476	helloshap	Shap	\N	https://t.me/i/userpic/320/CireMVEK8jVFUeG8IIgsRYM3Zt9kWUR9sdqq-MG_WKo.svg	2026-05-23 04:45:43.484625+00	2026-05-23 04:45:43.484625+00	\N	2026-05-23 04:45:43.484625+00	0.00	0	0	f	\N	\N
888	6203303823	hellohellohello1001	Ник	.	https://t.me/i/userpic/320/Vv4imr4xAz7o5rxPNC2MqEWFqgiNTR5Jh6FqLR0afk5RQNQtz2tOVychnxOHdcQP.svg	2026-04-21 16:36:56.046+00	2026-05-13 17:46:22.145688+00	\N	2026-05-13 17:46:22.145688+00	0.00	0	0	f	\N	\N
324	182443880	allisform	vasya t	\N	https://t.me/i/userpic/320/PVoHCI-9umP7DRP0Z5MQEC3y-rGCa6O36Qm5BPc1i_E.svg	2026-02-15 06:54:16.449599+00	2026-02-22 05:46:19.955568+00	\N	2026-02-22 05:46:19.955568+00	0.00	0	0	f	\N	\N
317	76360980	shifer604	Alexander	🌍	https://t.me/i/userpic/320/FYAAH70yvArAk6x36cdlyt-Lt58xFAxJwv43K7mMZeI.svg	2026-02-15 03:03:45.902492+00	2026-02-22 13:13:29.677903+00	\N	2026-02-22 13:13:29.677903+00	0.00	0	0	f	\N	\N
375	1001167211	Trepanetor	Alexey	\N	https://t.me/i/userpic/320/8vp2c4NDIsDyFUrG6iP78trVJVbuxaIHeis_Mp3Owjc.svg	2026-02-17 17:22:33.475038+00	2026-02-19 18:43:14.002626+00	\N	2026-02-19 18:43:14.002626+00	0.00	0	0	f	\N	\N
311	59379838	SolarSerg	Sergey	Egorov	https://t.me/i/userpic/320/bKNJIfxF6AfUQHPjotoXHRCcf035Q8GHpwoD3p7Fu_U.svg	2026-02-14 20:55:22.093838+00	2026-02-19 18:51:56.23897+00	\N	2026-02-19 18:51:56.23897+00	0.00	0	0	f	\N	\N
305	5483030714	x_ai_ai	К	\N	https://t.me/i/userpic/320/5xXg9RXHtyUWR0VIlbniM41Bju06DLrgJnfOJ4BNNa6Y_mZgEEb-kWA4fKe37hgC.svg	2026-02-14 18:52:36.533501+00	2026-02-14 18:52:36.533501+00	\N	2026-02-14 18:52:36.533501+00	0.00	0	0	f	\N	\N
312	5243622785	Unjubmun	Кирилл	\N	https://t.me/i/userpic/320/qpcaCYZv1tkuVMpyQXUpQvJuUjKffF5pKoQDWVB1pOpyq7YeT-eZ-iFh7hQlgdKT.svg	2026-02-14 21:21:02.626304+00	2026-02-19 19:15:30.816701+00	\N	2026-02-19 19:15:30.816701+00	0.00	0	0	f	\N	\N
307	8065277271	\N	Gab	Folder	https://t.me/i/userpic/320/8MvZwz3h6dDJHphLbKc0lhhnY36fMZs5Gt936YJWFUPcOebhyp9IzuUMy3hYmLn7.svg	2026-02-14 19:20:57.844736+00	2026-02-14 19:20:57.844736+00	\N	2026-02-14 19:20:57.844736+00	0.00	0	0	f	\N	\N
298	5245422723	Oleg_viatkin	Oleg	\N	https://t.me/i/userpic/320/GfwA-20-BsL83v2I55Mxo4lbxprtAkMh6wVNAFvsrdjHZyBNxWwax_SOXOmaNpWS.svg	2026-02-14 17:01:04.109278+00	2026-02-19 20:44:51.714977+00	\N	2026-02-19 20:44:51.714977+00	0.00	0	0	f	\N	\N
348	363537154	NikBRSHK	Niko	\N	https://t.me/i/userpic/320/MeWNSxcWQBzrHCIw_SMXSM_4DIGg0ek5XfpFRNCnV6Q.svg	2026-02-15 19:58:54.239213+00	2026-02-21 12:16:55.26262+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-21 12:16:55.26262+00	0.00	0	0	f	\N	\N
309	829676558	Hitechpower	Анжела	\N	https://t.me/i/userpic/320/FvftewGSFxx0SkmHTdy7ci20HGpBNgIwxeMZe6S-dT0.svg	2026-02-14 20:11:18.47614+00	2026-02-14 20:11:18.47614+00	\N	2026-02-14 20:11:18.47614+00	0.00	0	0	f	\N	\N
331	1605767560	\N	Ivan	\N	https://t.me/i/userpic/320/WsP7UxROTNfDi5zaUobxLr6pKbNoGwNLhyWU9PwBv6s.svg	2026-02-15 11:07:03.087567+00	2026-02-25 10:25:31.796842+00	\N	2026-02-25 10:25:31.796842+00	0.00	0	0	f	\N	\N
755	668112492	AlxndraRo	Alexandra	\N	https://t.me/i/userpic/320/WBHJVXdK0zesIf0T9oNCmaiKNr1ZzVx6lGjYrFCQ7z4.svg	2026-03-08 17:38:43.394007+00	2026-04-03 21:21:31.171364+00	0101000020E61000007F2BFEEEAE6D3E40864F40D95FFC4D40	2026-04-03 21:21:31.171364+00	0.00	0	0	f	\N	\N
273	897841165	cryptgalaxy	Vladimir	\N	https://t.me/i/userpic/320/F5JVLY-HERWvq7M51WZQi_ibBauoacgW0J1iA1jnfBE.svg	2026-02-14 14:35:48.361405+00	2026-02-20 06:48:04.010978+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-20 06:48:04.010978+00	0.00	0	0	f	\N	\N
286	365695838	Goaelf	Al	\N	https://t.me/i/userpic/320/Mqg1zUksMApMnTlzyovmTiogTiA3GOcpJvfF6CwmWqg.svg	2026-02-14 15:52:07.455871+00	2026-02-14 15:53:48.085573+00	0101000020E61000005B35199F13A94840AC787EAC3BDC4B40	2026-02-14 15:53:48.085573+00	0.00	0	0	f	\N	\N
314	569743666	ilyajluc	Илья	Лис	https://t.me/i/userpic/320/sV4g_rgpuX6QejWnHt9ASYtE1xd84UIBF8rqLeIi8Zo.svg	2026-02-14 23:05:25.801954+00	2026-02-14 23:14:16.319634+00	0101000020E61000006B96708D740E49405AB09EA40A984A40	2026-02-14 23:14:16.319634+00	0.00	0	0	f	\N	\N
283	923778667	AlexanderN87	CorewardVoid	\N	https://t.me/i/userpic/320/o5dYMAfRGIx1X_9JOog-yJaZ5gmqlLrVjBEYgSfMPy0.svg	2026-02-14 15:33:11.718723+00	2026-04-04 07:08:37.917077+00	0101000020E6100000D49343D5F9CB42403DE5E2B908D04B40	2026-04-04 07:08:37.917077+00	0.00	0	0	f	\N	\N
288	325125404	Nirmalita	Anetta	Nirmala	https://t.me/i/userpic/320/35Z4mqVD9Y7ELcrVNmbkXuVvY0Jmyaqmn-2U3XMmZgE.svg	2026-02-14 16:09:34.825721+00	2026-02-14 16:10:09.29748+00	\N	2026-02-14 16:10:09.29748+00	0.00	0	0	f	\N	\N
322	8079172441	\N	Vladimir	Vladimir	https://t.me/i/userpic/320/nni-W6OUt34VLcFP-9_M6Prk-47dNg7v5uYIXHG54voAr5HM0SHesbycScPVnl53.svg	2026-02-15 05:48:12.036552+00	2026-02-15 05:48:12.036552+00	\N	2026-02-15 05:48:12.036552+00	0.00	0	0	f	\N	\N
292	142660883	ksenka_zoza	Ksenia	\N	https://t.me/i/userpic/320/izM99KR4rP7E21npuhl94Vwf9FNCJOi1DAONDMnqnII.svg	2026-02-14 16:22:49.041655+00	2026-02-14 16:22:49.041655+00	\N	2026-02-14 16:22:49.041655+00	0.00	0	0	f	\N	\N
293	1093194221	Danila_669	Данила	\N	https://t.me/i/userpic/320/hySquPBMB8Eb5hAMynhyGnpgRoX5yth-iYpZ72fPsMI.svg	2026-02-14 16:23:23.332996+00	2026-02-14 16:23:23.332996+00	\N	2026-02-14 16:23:23.332996+00	0.00	0	0	f	\N	\N
294	722259052	biosonar	biosonar	\N	https://t.me/i/userpic/320/OPBp7veHn3CP8yGErsJtdwbxHfVStWPSsl-E29vi6YY.svg	2026-02-14 16:30:30.527791+00	2026-02-14 16:30:30.527791+00	\N	2026-02-14 16:30:30.527791+00	0.00	0	0	f	\N	\N
325	138008290	mariya_preymontayte	Мария	Преймонтайте	https://t.me/i/userpic/320/RugQRXKY-sgyTCQwAkSiieglRvq1zW9hBNcCH3qk7Yc.svg	2026-02-15 07:40:46.014568+00	2026-02-15 07:40:46.014568+00	\N	2026-02-15 07:40:46.014568+00	0.00	0	0	f	\N	\N
377	1186608855	Dr_Annushka	Dr.Annushka	\N	https://t.me/i/userpic/320/m4j7RL44VXzeLPD4OT2LzZn4MhsfQi_grFTJeyF8HC4.svg	2026-02-17 17:34:53.270114+00	2026-02-17 17:34:53.270114+00	\N	2026-02-17 17:34:53.270114+00	0.00	0	0	f	\N	\N
650	207298487	i4Daniil	Daniil Alekseevich	\N	https://t.me/i/userpic/320/lU3KWOJl9Qv0_dr1g-gxWQI7yNccG1mTV_FW141hS0M.svg	2026-03-02 21:06:32.196378+00	2026-03-02 21:07:25.589655+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-02 21:07:25.589655+00	0.00	0	0	f	\N	\N
329	182487128	evgeniya_magic	Женя	Волшебная💥✨	https://t.me/i/userpic/320/RvP0lENGl94haCioPB-a7JL7WtwoRmTDycgwU4uc3PU.svg	2026-02-15 09:37:27.683225+00	2026-02-15 09:37:27.683225+00	\N	2026-02-15 09:37:27.683225+00	0.00	0	0	f	\N	\N
66	106809397	Alex_Kniga	Alex	Kniga	https://t.me/i/userpic/320/c8Orob5Ks8lkg27TpOb6r0fNYs5fjX5s4Us-wOaRSag.svg	2026-02-12 15:28:05.902904+00	2026-02-15 09:57:52.185805+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-15 09:57:52.185805+00	0.00	0	0	f	\N	\N
1349	507344	funky	Alex	Omg	https://t.me/i/userpic/320/tQe6hJ26G00fu8DD2c3iab6UCICon7AFNEud0kT5PwU.svg	2026-06-17 10:00:11.475086+00	2026-06-17 10:00:11.475086+00	\N	2026-06-17 10:00:11.475086+00	0.00	0	0	f	\N	\N
574	5678996981	lukichox	Pingpong2000	\N	https://t.me/i/userpic/320/WEhCuCFj8CmG_2SRREOdWKeXEIiWJkUw6_Yzg1oYwXCYh7Aa7bjkUgq5TCloDA6i.svg	2026-02-22 18:52:46.578033+00	2026-02-22 18:53:59.183272+00	\N	2026-02-22 18:53:59.183272+00	0.00	0	0	f	\N	\N
892	531283221	vovvvvannnn	Владимир	\N	https://t.me/i/userpic/320/05qirs3HbE4GxTdadWZN0xbIp1MZr0nKhpPGOEg9Gmo.svg	2026-04-22 10:28:48.181868+00	2026-04-22 10:28:48.181868+00	\N	2026-04-22 10:28:48.181868+00	0.00	0	0	f	\N	\N
1173	1000395936	vidumkavoobroghenia	Па	\N	https://t.me/i/userpic/320/PMCGOL6A0cCMydBPa3YWD4VacgTtis0CfTQ3LN0V4ZU.svg	2026-05-30 17:34:58.977512+00	2026-05-30 17:40:55.632026+00	\N	2026-05-30 17:40:55.632026+00	0.00	0	0	f	\N	\N
532	335499197	katya_esenika	Катя	Есеника	https://t.me/i/userpic/320/w6g1Vw3fu_oVLQstilwql22v2VYocAqM9vzwDyk4OYE.svg	2026-02-21 13:44:27.221701+00	2026-02-21 13:44:27.751287+00	\N	2026-02-21 13:44:27.221701+00	0.00	0	100	f	\N	\N
951	220069658	Lena_ElVl	Elena	\N	https://t.me/i/userpic/320/78vNsZYKsj-EZwzz9gMvD3MAaQzo7DhZ3RM2vj4Y4oU.svg	2026-05-10 22:50:49.024066+00	2026-05-20 09:30:33.298176+00	\N	2026-05-20 09:30:33.298176+00	0.00	0	0	f	\N	\N
549	680041505	ruslan_cardigan	Ruslan	Cardigan	https://t.me/i/userpic/320/Dwfk4USbRnikaM0WRKcqbg9kXrH7OJT-AM0p5LurOjQ.svg	2026-02-21 18:31:16.419248+00	2026-02-21 18:31:16.481972+00	\N	2026-02-21 18:31:16.481972+00	0.00	0	0	f	\N	\N
214	1186998459	Garilla_Jah	MOZAYKA	\N	https://t.me/i/userpic/320/QcetWM81jD5iAPpvy9kf9n_ST4kUjpuxxHHkO0oihVM.svg	2026-02-14 12:07:30.177818+00	2026-02-23 18:02:59.970682+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-23 18:02:59.970682+00	0.00	0	0	f	\N	\N
386	352807720	daralexx	ᚦᚣᚹⰓᚱ	\N	https://t.me/i/userpic/320/YuhkBnQHlmjd11jjjczLqKBTfv2qOSiP-C-TMA-Bg70.svg	2026-02-18 12:27:27.427019+00	2026-02-18 12:27:27.427019+00	\N	2026-02-18 12:27:27.427019+00	0.00	0	0	f	\N	\N
358	1098209410	Bombay22	Paprika	\N	https://t.me/i/userpic/320/wzVc9sqh4Zd88BOTsU-gkrqoBu6rVsoeOpu5aj9CkOI.svg	2026-02-16 11:47:15.51203+00	2026-02-21 23:25:42.562143+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-21 23:25:42.562143+00	0.00	0	0	f	\N	\N
349	7002813458	edireifman	Edi	Reifman	https://t.me/i/userpic/320/uzHXbRZ_v7VQDmBL2zLabskz6CeziICaQ4MCIRAMnUHmabUeXTS8M-yUkGepup9c.svg	2026-02-15 20:01:47.996569+00	2026-02-22 06:26:59.357875+00	\N	2026-02-22 06:26:59.357875+00	0.00	0	0	f	\N	\N
336	5115019494	NOMAD1_9_8_4	Роман ⚔️ Gift Kombat🍀 Anthill	\N	https://t.me/i/userpic/320/aZDQ3wESmCfHsP1l2hoklZHZcANMqG3pAH1Jjw5Dq3RZQ7o68ddNxbliQjtUW36K.svg	2026-02-15 11:42:19.809847+00	2026-02-21 12:26:28.419209+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-21 12:26:28.419209+00	0.00	0	0	f	\N	\N
224	7575255339	hitechpower88	🍄	\N	https://t.me/i/userpic/320/uu-TT7r_4gmf-UOLMsSbHW5IKPLwEe78Z4yY10A90zNyu_PFLx2tmefnKdo0-2aO.svg	2026-02-14 12:13:21.074724+00	2026-02-27 17:23:00.763622+00	\N	2026-02-27 17:23:00.763622+00	0.00	0	0	f	\N	\N
479	146648183	Oeric1984	Oeric	\N	https://t.me/i/userpic/320/B5STcBdHsv5Yau5icLT0bHqfecEJ9uxSIJMHtGaRMzk.svg	2026-02-20 22:01:30.779132+00	2026-02-20 22:05:43.891789+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-20 22:05:43.891789+00	0.00	0	0	f	\N	\N
1222	1169254929	Zombets	Серёга	\N	https://t.me/i/userpic/320/slMWI_7KkxJBT3uU7LmjgYY7yp-Vs72V3C1eLOTeols.svg	2026-06-03 20:13:17.91007+00	2026-06-03 20:13:17.91007+00	\N	2026-06-03 20:13:17.91007+00	0.00	0	0	f	\N	\N
1207	390055119	Apexius	Олег	\N	https://t.me/i/userpic/320/hAZ3Bh_G6nDO7dE9YRQoRWaQEy1Qux5YAlrO1qDwCQI.svg	2026-06-02 19:55:25.099132+00	2026-06-27 10:46:06.401085+00	\N	2026-06-27 10:46:06.401085+00	0.00	0	0	f	\N	\N
800	402257620	AlexSima25	Alexandra	\N	https://t.me/i/userpic/320/XwmNF4q4yZUlBVvIil6wXmvVcPU2oxmARM1vXHXpuv8.svg	2026-03-20 14:04:23.188841+00	2026-04-14 15:42:44.644455+00	\N	2026-04-14 15:42:44.644455+00	0.00	0	0	f	\N	\N
673	77785271	Alova_Snezhana	Алова	Снежана	https://t.me/i/userpic/320/Jw-zYr_3rIbkxDMVNpVwlQGBw0-fMdMRiGtCAcco4ls.svg	2026-03-06 06:20:18.282098+00	2026-03-06 06:20:18.282098+00	\N	2026-03-06 06:20:18.282098+00	0.00	0	0	f	\N	\N
776	113557156	ShenyaLis	Лисичкины Пёрышки	\N	https://t.me/i/userpic/320/9NMyukOww0nfQOyT6CcG9ZrOZDoVc7ypzZ2eR1jjZwA.svg	2026-03-10 05:08:13.644961+00	2026-05-21 07:57:29.33778+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-21 07:57:29.33778+00	0.00	0	0	f	\N	\N
380	7983670300	Vosstanovi	Игорь	Шаповал	https://t.me/i/userpic/320/EVrk8JOac-KLmttdBmJ1zH9Pqq0HqEPjbDCnH_2yL4SpXry4G3q7cHerLMTlXU7k.svg	2026-02-18 04:27:25.340902+00	2026-02-22 08:35:01.711217+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-22 08:35:01.711217+00	0.00	0	0	f	\N	\N
730	7842800167	sl1p_sl0p	𝙎𝙇𝙄𝙋•𝙎𝙇𝙊𝙋	\N	https://t.me/i/userpic/320/B25844-hY1cLbKjYcHtT4rvNUnLv6J567jtg4o-wvIoFhrxUhXU9gJli9nvQmDIq.svg	2026-03-07 14:45:54.885566+00	2026-03-07 14:45:54.885566+00	\N	2026-03-07 14:45:54.885566+00	0.00	0	0	f	\N	\N
355	462416232	SiVi19	Si	Vi	https://t.me/i/userpic/320/s1kqZoflQrBAWyi5TTChF7Ks8VOuum3k1zfKg4xrVl4.svg	2026-02-16 11:07:59.702915+00	2026-02-16 11:07:59.702915+00	\N	2026-02-16 11:07:59.702915+00	0.00	0	0	f	\N	\N
485	222083638	stiiiiilllllll	Димитрий	\N	https://t.me/i/userpic/320/BfRK8TJ3-fKR_hLYCfml0qmYvSiIgHPtgv2hoS2DKGU.svg	2026-02-21 07:18:40.508209+00	2026-06-02 11:10:17.88963+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-02 11:10:17.88963+00	0.00	0	0	f	\N	\N
199	280317426	psygari	Igor	\N	https://t.me/i/userpic/320/ujKm5MwPZyVsZ7Kdj6terjwu7C58S6nZ0RDScMuoA3I.svg	2026-02-14 10:56:39.96272+00	2026-02-25 09:38:40.467329+00	0101000020E6100000A4C990B528E642408D0503A8A3D04B40	2026-02-25 09:38:40.467329+00	0.00	0	0	f	\N	\N
815	454157119	Fedr0ff	Serj	\N	https://t.me/i/userpic/320/qthgI3N2hpn5eugLkZdM8-pNeClvjX-2tssyywxAftM.svg	2026-03-25 12:27:34.252344+00	2026-03-25 12:27:34.252344+00	\N	2026-03-25 12:27:34.252344+00	0.00	0	0	f	\N	\N
365	485992842	alexseymot	Алексей	\N	https://t.me/i/userpic/320/xNSb6cT-eHV9vZIS09ocrguoI5tVsa5glwm3Um5eIzM.svg	2026-02-16 21:29:24.105112+00	2026-02-16 21:29:24.105112+00	\N	2026-02-16 21:29:24.105112+00	0.00	0	0	f	\N	\N
389	553311737	SamPablito	Paul	\N	https://t.me/i/userpic/320/yd8nQJ6Vgs2o1-txiLntQROfrGcYSKv7VJYOnlVDcn4.svg	2026-02-18 15:16:01.988302+00	2026-02-25 09:49:37.629421+00	\N	2026-02-25 09:49:37.629421+00	0.00	0	0	f	\N	\N
344	45792863	Jazzblood	Alex	G	https://t.me/i/userpic/320/1Sn1INz1o2v_1ZTcVa51StXvyLOpjNYdQHAmOCzNWsQ.svg	2026-02-15 17:14:59.376091+00	2026-06-27 15:41:38.801226+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-27 15:41:38.801226+00	0.00	0	0	f	\N	\N
340	307059155	naste_mir	Настя	\N	https://t.me/i/userpic/320/hLMS-g48VQ1JzDyOUhGdbv96aEtMwT8PPezbUh5qSEc.svg	2026-02-15 16:11:20.526354+00	2026-05-18 14:17:49.179352+00	0101000020E61000000389377C1CBD4240982144E856DE4B40	2026-05-18 14:17:49.179352+00	0.00	0	0	f	\N	\N
1498	451414515	Forest_Witch_MandalaDesign	Natalia	Kachkovskaya	https://t.me/i/userpic/320/cLPdOmCWRlDBPBgWasq8-yHJ0-_le9jmu93yys8qRzw.svg	2026-06-27 16:14:39.704584+00	2026-06-27 16:14:39.704584+00	\N	2026-06-27 16:14:39.704584+00	0.00	0	0	f	\N	\N
1507	735013400	valteRRsas	🥵💔	\N	https://t.me/i/userpic/320/_lU07xZlUyNmin0zDFVKUmhtPHErGkgR5_RqQ6G6QgQ.svg	2026-06-28 18:24:14.137104+00	2026-06-28 18:24:14.137104+00	\N	2026-06-28 18:24:14.137104+00	0.00	0	0	f	\N	\N
138	6788783024	Los_tanates	Agents Master	\N	https://t.me/i/userpic/320/euOewCvB2P_ISQTKbJICw_9Mp1YyJAWRmNnZin-f7IOms_q8UocYvstwTM2XyLTZ.jpg	2026-02-13 17:17:12.744388+00	2026-02-28 18:55:58.336247+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-28 18:55:58.336247+00	0.00	0	0	f	\N	\N
48	147349977	Sacral_Fractal	Александр	\N	https://t.me/i/userpic/320/ifcMyw3HENQXvnLhAJyo4JLARbyC2apHHsLr7lBT1fA.svg	2026-02-11 08:41:05.860186+00	2026-04-03 17:15:16.624658+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-03 17:15:16.624658+00	0.00	0	0	f	\N	\N
346	427153732	Stealthfriar	St	Th	https://t.me/i/userpic/320/0PLvr9ZYedk1g6VkqdDXwaPLYQm_vsncnDs3DPJkGSQ.svg	2026-02-15 18:08:29.6657+00	2026-02-15 18:08:29.6657+00	\N	2026-02-15 18:08:29.6657+00	0.00	0	0	f	\N	\N
625	847155598	\N	Roman	\N	https://t.me/i/userpic/320/GvmqZdURnDAwtltfIPtPQZuQ4y467LPYzHyvRmUH4-w.svg	2026-02-28 19:43:00.284642+00	2026-02-28 19:43:00.284642+00	\N	2026-02-28 19:43:00.284642+00	0.00	0	0	f	\N	\N
1010	419959566	yegorla	Yegor	L	https://t.me/i/userpic/320/48YR32K2-1joZD4wwEm5_PY6yxAMSDgIEBF9uFkYj4k.svg	2026-05-16 12:48:20.462949+00	2026-05-16 12:48:20.462949+00	\N	2026-05-16 12:48:20.462949+00	0.00	0	0	f	\N	\N
636	863966	Batonrain	Eugen	Batishchev	https://t.me/i/userpic/320/uM39fpCNtFIJD6aFIoT0T3oIO1nzW6p6ecoC1AKLnj0.svg	2026-03-02 07:09:29.280559+00	2026-05-13 10:38:40.388728+00	0101000020E6100000AB206679F6934840D7611D59D0E44B40	2026-05-13 10:38:40.388728+00	0.00	0	0	f	\N	\N
1351	206196442	forestgirl	Mary	\N	https://t.me/i/userpic/320/DNF-ABkaIIm2JY_bfb8SmbStUqblnEz2BqXN7QA2OI0.svg	2026-06-17 10:35:42.804627+00	2026-06-17 10:35:42.804627+00	\N	2026-06-17 10:35:42.804627+00	0.00	0	0	f	\N	\N
1076	209282988	Someonespecial2	Someone	Special	https://t.me/i/userpic/320/0l8yXJUXeOQ2rmmkXjhlCwEqnnqYR2eklbEay-SDP_c.svg	2026-05-20 09:29:46.77543+00	2026-05-20 09:29:46.77543+00	\N	2026-05-20 09:29:46.77543+00	0.00	0	0	f	\N	\N
357	180318636	milonga604	Elena	Markova	https://t.me/i/userpic/320/jRDUUQ8yO85DCQZw0oFiAIpDxHR9dpo9ogItft_xlEg.svg	2026-02-16 11:29:28.563012+00	2026-02-16 11:29:28.563012+00	\N	2026-02-16 11:29:28.563012+00	0.00	0	0	f	\N	\N
360	745313831	mmittoss	Дмитрий	Ярошенко	https://t.me/i/userpic/320/ULKVYZEhdVw4TrBHguRim2aKx0vqKE6mupMDq60jGGA.svg	2026-02-16 12:21:54.102092+00	2026-02-16 12:21:54.102092+00	\N	2026-02-16 12:21:54.102092+00	0.00	0	0	f	\N	\N
633	256795765	myBubaleh	A.	Neori	https://t.me/i/userpic/320/7AgGQ9X3bf53aybMIWm949M35eTyZMfqp1_KOgmWW4s.svg	2026-03-01 14:03:38.360716+00	2026-03-01 14:04:17.794463+00	0101000020E6100000B7DF27CE1ACE42405BEFBA20A3184B40	2026-03-01 14:04:17.794463+00	0.00	0	0	f	\N	\N
611	312453330	Siropov	Sirop	\N	https://t.me/i/userpic/320/V7fredE9gsg2DhKkrZ0wzrNV-GzWagA1MtUblLOleRQ.svg	2026-02-28 06:05:25.510439+00	2026-04-08 14:27:05.872161+00	0101000020E61000008AA934406ED5424066B6DA4BC1CA4B40	2026-04-08 14:27:05.872161+00	0.00	0	0	f	\N	\N
699	86192251	usergor	User	\N	https://t.me/i/userpic/320/h7msrQ3R7nBOcAEZcjYospcyMNDMhpfG8rSk4X1oXNQ.svg	2026-03-06 18:59:39.951198+00	2026-06-03 20:47:06.210267+00	\N	2026-06-03 20:47:06.210267+00	0.00	0	0	f	\N	\N
913	177470587	\N	Efim🎥	Efim	https://t.me/i/userpic/320/Z0gq2okdmwY0wizH9tS1LBovTqG3DylCfkOAOeFUhIk.svg	2026-04-30 09:10:15.657533+00	2026-06-18 18:38:22.335369+00	\N	2026-06-18 18:38:22.335369+00	0.00	0	0	f	\N	\N
587	56209897	Vet_Sychmann	@Vet	\N	https://t.me/i/userpic/320/oQM1poK1txec4UcTNToJeneiUmm3tTMc7-96O3_XLow.svg	2026-02-25 08:45:26.351781+00	2026-05-22 09:27:49.563069+00	0101000020E61000009C18929389BF42408B64D9DD4DDF4B40	2026-05-22 09:27:49.563069+00	0.00	0	0	f	\N	\N
674	8038318279	PipindraJo	Гоу	СосаЦа	https://t.me/i/userpic/320/yZT8y41pn4_MDyYYATeDV2L42qzWiRZUNpbM-6GT2YFqeV79px_1QMCPAlFDlnnj.svg	2026-03-06 06:30:58.632139+00	2026-03-06 06:31:10.693985+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-06 06:31:10.693985+00	0.00	0	0	f	\N	\N
552	1856273861	Dj_Fuckir	Юрий Симанов	Dj Fuckir	https://t.me/i/userpic/320/EdCeFAO1YPSKjdZlwQ_KbBH_zZWEPp5rh23PjpSr0mE.svg	2026-02-21 20:20:10.522689+00	2026-02-21 20:20:10.522689+00	\N	2026-02-21 20:20:10.522689+00	0.00	0	0	f	\N	\N
576	1031329904	RASSSSSSSSSSSSSUL	Расул	\N	https://t.me/i/userpic/320/rS83kI-ioBgGvj-j52wSSB2BMCqU54Nk93S6_By4MQY.svg	2026-02-23 05:10:34.877649+00	2026-02-23 05:10:34.877649+00	\N	2026-02-23 05:10:34.877649+00	0.00	0	0	f	\N	\N
238	7026963698	MTrishula	Аmaxim	\N	https://t.me/i/userpic/320/qQo_nsi_E4eqcsB2KWE2ivHdqYH9-TNzwHge-xcaQRI0e1s29fTkwbdNbo9yBmuB.svg	2026-02-14 12:49:07.088998+00	2026-03-06 07:40:00.039657+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-06 07:40:00.039657+00	0.00	0	0	f	\N	\N
308	7837038661	\N	𝓚𝓲𝓻	\N	https://t.me/i/userpic/320/bWKfGCpK1GGOG9flMag00jdyLvqNJarKJYdhdiRQFu9WRYSRruJ1dGokD34vzj6B.svg	2026-02-14 19:48:43.226459+00	2026-05-18 17:10:03.635479+00	\N	2026-05-18 17:10:03.635479+00	0.00	0	0	f	\N	\N
379	277897764	grishinage	Andrey	\N	https://t.me/i/userpic/320/TuIDGHudOXJYcZlCV-X8myxi3GmgSKistMVZOoCx9zc.svg	2026-02-17 19:38:00.159886+00	2026-02-17 19:38:59.110752+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-17 19:38:59.110752+00	0.00	0	0	f	\N	\N
210	438296572	ZoyaOm	Зоя	\N	https://t.me/i/userpic/320/ISohBjsAznMhlU9AUFw0o8PHHIQxqNVJzB701AlJHMo.svg	2026-02-14 11:53:18.743239+00	2026-04-23 22:02:04.933696+00	\N	2026-04-23 22:02:04.933696+00	0.00	0	0	f	\N	\N
361	347467414	alexducker	Александр	Уткин	https://t.me/i/userpic/320/Lkkg_upllZ3h2EtrjPyrXmvWdWzTv4nPUOY3hq4_puA.svg	2026-02-16 13:01:17.196197+00	2026-05-28 17:24:42.61561+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-28 17:24:42.61561+00	0.00	0	0	f	\N	\N
766	996248287	golosvechnosty	Konstantin	\N	https://t.me/i/userpic/320/t4lTnv2dq1WY-_srXv7MIW4NcWjTLzCDFFyD5aCswS4.svg	2026-03-09 07:48:14.760055+00	2026-03-09 07:50:04.541937+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-09 07:50:04.541937+00	0.00	0	0	f	\N	\N
237	670756238	DeeplyBeeply	Marilyn	Miller	https://t.me/i/userpic/320/pkJ2YP1TJhFb_CUa71wnPbBMtVmJbTOtXvXDTFt5OL0.svg	2026-02-14 12:43:43.683171+00	2026-02-17 01:20:27.134206+00	\N	2026-02-17 01:20:27.134206+00	0.00	0	0	f	\N	\N
754	286115324	Mushroom_Foxy	Mushroom	Foxy	https://t.me/i/userpic/320/IzzDlfANzN88YKcrKXXWPD0d0MHlaHCuzk7xJSpYY_Q.svg	2026-03-08 17:24:14.337083+00	2026-03-09 12:39:46.637428+00	0101000020E61000000805002258285340D80E46EC13855040	2026-03-09 12:39:46.637428+00	0.00	0	0	f	\N	\N
383	355954306	NaviVokram	Ivan	\N	https://t.me/i/userpic/320/KTvxODlTeAtT9Vvvku5x5DVKZFor7rwQOGTb-8W_gWo.svg	2026-02-18 08:06:29.870512+00	2026-02-21 21:18:13.967538+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-21 21:18:13.967538+00	0.00	0	0	f	\N	\N
350	332432568	RAVELORD135	RaveLord	\N	https://t.me/i/userpic/320/zB2Fe7wKgW4OWEGpu5VaPJHaMUl6tHiomRuYsXbZ7g0.svg	2026-02-16 06:00:56.663704+00	2026-03-03 12:20:46.986571+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-03 12:19:44.071178+00	0.00	0	100	f	\N	\N
387	1740679626	GastroGentleMan	Well	\N	https://t.me/i/userpic/320/169kaObgGBk1hodaUne6yp_DozwSFUfXK5DvLkysJXc.svg	2026-02-18 12:34:13.418845+00	2026-02-19 18:49:39.159018+00	\N	2026-02-19 18:49:39.159018+00	0.00	0	0	f	\N	\N
654	1872754876	Annplants1	АnnPlants	\N	https://t.me/i/userpic/320/calHkN7srcUzEixQ02BZmewdfeQYtfUBQ9oX5mGvutI.svg	2026-03-03 16:51:48.84266+00	2026-03-03 16:53:09.760879+00	\N	2026-03-03 16:53:09.760879+00	0.00	0	0	f	\N	\N
541	5428618069	at_ohm	Nick	\N	https://t.me/i/userpic/320/GmG_7s_ZvEbFD56hP5H1vqv7Hoh5KZK3_mTPL_xSiViTLKxAvFTVsop_Xrh37RK4.svg	2026-02-21 14:29:47.891295+00	2026-02-21 14:30:20.529818+00	\N	2026-02-21 14:30:20.529818+00	0.00	0	100	f	\N	\N
341	619947044	sa666a6	sa666(	\N	https://t.me/i/userpic/320/qV6ymuwhdShWiBZ5gxHXLpn56EKUeWD7_8569kcKM7U.svg	2026-02-15 17:08:59.095731+00	2026-02-25 09:42:51.903018+00	\N	2026-02-25 09:42:51.903018+00	0.00	0	0	f	\N	\N
133	321242719	spacer_spb	Evgeniy	Krasnoshchekov	https://t.me/i/userpic/320/3A2xEarLKSoG9OzMF4w_qNXFsLvbcOtd2Bbh0cmOzjw.svg	2026-02-13 13:26:39.791672+00	2026-02-22 02:15:49.921748+00	0101000020E6100000C7BAD2BCA7206340475B8FC1903D3BC0	2026-02-22 02:15:49.921748+00	0.00	0	0	f	\N	\N
254	7386529789	Islesov604	𝔅𝔯𝔞𝔱𝔶𝔞 𝔳𝔞𝔰𝔥𝔦	𝔪𝔢𝔫𝔰𝔥𝔦𝔢	https://t.me/i/userpic/320/0hoJH8rjg2UlxPOPaOOES5uJZ3J8NzEUdky3kGjPtKviRQxlZ0ejgUZbnveAwfsH.svg	2026-02-14 13:37:54.618325+00	2026-02-22 05:14:06.208534+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-02-22 05:14:06.208534+00	0.00	0	0	f	\N	\N
659	205245315	Katerina_Zi	Екатерина	Зимина	https://t.me/i/userpic/320/8Q7B0gV6TGhfRpPNOBJJU7uggBeJD9BYon-HhucJazc.svg	2026-03-04 13:20:32.005644+00	2026-03-04 13:20:45.327319+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-04 13:20:45.327319+00	0.00	0	0	f	\N	\N
660	825731816	Dariya_Potapkina	Daria	Potapkina	https://t.me/i/userpic/320/xeXMbCwvTBFfVSXDWHP-u8h-bkniaT-qC6Ca9IkESFI.svg	2026-03-04 20:20:08.071281+00	2026-03-04 20:24:05.436523+00	\N	2026-03-04 20:24:05.436523+00	0.00	0	0	f	\N	\N
829	312674598	kevargen87	kevargen87	\N	https://t.me/i/userpic/320/CvZEfjuF3KMVgj6IKBElJ3VoXtEz1TAshmzJpqGwjSc.svg	2026-04-03 17:36:10.671084+00	2026-04-03 17:36:10.671084+00	\N	2026-04-03 17:36:10.671084+00	0.00	0	0	f	\N	\N
676	56423163	DikobRaZo	Семён	\N	https://t.me/i/userpic/320/Kq64HO3bn5UU2ZV4yEYnWKokVv_Q4mjSJct75DtxaPo.svg	2026-03-06 09:43:03.354726+00	2026-03-06 09:43:33.404359+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-06 09:43:33.404359+00	0.00	0	0	f	\N	\N
255	170224927	kishori_floweret	kishori_floweret	\N	https://t.me/i/userpic/320/70WqhbH9PcQmr7sjrIwdExtiIYfeyRyWB_e1xJYCSyk.svg	2026-02-14 13:38:01.30858+00	2026-06-25 16:01:01.933427+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-25 16:01:01.933427+00	0.00	0	0	f	\N	\N
1578	1512497258	Riba_nozh	Сергей	Киселев	https://t.me/i/userpic/320/i2Nf936UejmWLH9rFzRrhTXTPfo7edcqGtsGFDpHLz4.svg	2026-07-02 01:06:22.667365+00	2026-07-02 01:06:28.142516+00	0101000020E6100000FE6E70D86CF14240221741086D054C40	2026-07-02 01:06:28.142516+00	0.00	0	0	f	\N	\N
337	384510453	sasha_hare	Sasha	Hare	https://t.me/i/userpic/320/EHseOpuXjmhWHnWBsd109D-rTXhNOTMYlwXK1p8yS08.svg	2026-02-15 12:50:36.252244+00	2026-03-07 14:52:20.78193+00	\N	2026-03-07 14:52:20.78193+00	0.00	0	0	f	\N	\N
832	825743783	Ramahare	harharmahadev	\N	https://t.me/i/userpic/320/mvSsITKsIII1tsToQgTOZpijEsM8Kt72dsJJ7-Uzbq0.svg	2026-04-03 18:25:58.594775+00	2026-04-03 18:25:58.594775+00	\N	2026-04-03 18:25:58.594775+00	0.00	0	0	f	\N	\N
734	1262024979	seashell_SG	Seashell	\N	https://t.me/i/userpic/320/-4q2kDK9Q2MLX9591Qi9OWUWo4B0oASGz3AhRBRB3Vw.svg	2026-03-07 15:09:41.233665+00	2026-03-07 15:12:04.994345+00	\N	2026-03-07 15:12:04.994345+00	0.00	0	0	f	\N	\N
692	503726802	Kalashnikovaolka	Олька Калашникова	\N	https://t.me/i/userpic/320/UnGNIyeGamhh5AiDdcVPhTGF_FPceFliUm47yLYRthk.svg	2026-03-06 17:27:01.877647+00	2026-05-21 10:46:20.409258+00	\N	2026-05-21 10:46:20.409258+00	0.00	0	0	f	\N	\N
281	747483512	nicetrippy	Сергей	Соболев	https://t.me/i/userpic/320/fpQnN3LAWwq8-ZD63yaPtLql1eJVSwG3XW_gW1sbzBc.svg	2026-02-14 15:17:51.066272+00	2026-03-08 13:23:23.65799+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-08 13:23:23.65799+00	0.00	0	0	f	\N	\N
1081	5092060037	\N	Alexey	B	https://t.me/i/userpic/320/i_AHqi73dMSO2Wr8FlB2Bs4Kg7sA_MX6XvQjUSbJhH_ja9PvgHk1QwxGYs8FzucG.svg	2026-05-20 10:51:14.557798+00	2026-05-20 10:51:14.557798+00	\N	2026-05-20 10:51:14.557798+00	0.00	0	0	f	\N	\N
1178	134282236	vseznaika	Михаил	Сенсеев	https://t.me/i/userpic/320/xdQTuoYf-shEbw2zEWzcfVFFM6bKDnjD7-6rzdUxfxo.svg	2026-05-31 05:32:35.351322+00	2026-05-31 05:32:35.351322+00	\N	2026-05-31 05:32:35.351322+00	0.00	0	0	f	\N	\N
735	846273533	ZverEdition	Neva	\N	https://t.me/i/userpic/320/Ae3vcsDenSfne8hTSKDLu_PGXdGLsW0nBp65VP68trQ.svg	2026-03-07 16:13:09.66072+00	2026-03-18 12:28:00.441935+00	\N	2026-03-18 12:28:00.441935+00	0.00	0	0	f	\N	\N
772	146777480	GambRa_dj	Денис	М	https://t.me/i/userpic/320/Ra6FgPvnWY_PVXlsHYlGovZSWA8pQkwqu_FzUSGxUVc.svg	2026-03-09 15:22:13.070819+00	2026-03-20 14:43:19.355841+00	\N	2026-03-20 14:43:19.355841+00	0.00	0	0	f	\N	\N
740	1373951270	yaminawa	Katherine 🦇	\N	https://t.me/i/userpic/320/RdZ2bKvvj-yM-WlNPzHzPic9a598yphQdv9CHIDjpbc.svg	2026-03-08 06:18:22.000882+00	2026-06-19 12:36:43.464157+00	0101000020E61000003858A7A41D583E40D47C32D620014E40	2026-06-19 12:36:43.464157+00	0.00	0	0	f	\N	\N
1525	1214070866	iluha5315	El	\N	https://t.me/i/userpic/320/o_olxJ2dLlO6tDORAOeyCEtSr9t0QP1QZOScPx-sbdw.svg	2026-06-29 13:17:44.72961+00	2026-06-29 13:17:44.72961+00	\N	2026-06-29 13:17:44.72961+00	0.00	0	0	f	\N	\N
831	759337966	kkoshaevaa	=^_^=	\N	https://t.me/i/userpic/320/xd2wJ5EKhMlOmNFkIxRtP5_zKyuu_QEK0i2QcJKLKWw.svg	2026-04-03 18:11:46.914595+00	2026-06-24 12:16:02.962783+00	0101000020E6100000AB515048A5573E40957D9FBC89F64D40	2026-06-24 12:16:02.962783+00	0.00	0	0	f	\N	\N
738	141322890	Ole_JAH	Genrikh Motc	\N	https://t.me/i/userpic/320/crwlASZxQwOEm0ZkyE_oTsenYMvnZrpalnHwASqOZns.svg	2026-03-07 17:14:37.62704+00	2026-03-07 17:14:37.62704+00	\N	2026-03-07 17:14:37.62704+00	0.00	0	0	f	\N	\N
335	356972906	bjuice25	Иван	\N	https://t.me/i/userpic/320/ooLUToG8PH6D9hti5iuMkYD970vQoIrZ46RhIsz8SvA.svg	2026-02-15 11:33:21.952573+00	2026-03-08 18:10:47.493453+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-08 18:10:47.493453+00	0.00	0	0	f	\N	\N
278	311493797	horrrse	Alexander	Bratchikov	https://t.me/i/userpic/320/UnUbVxlsTuPCKivLey9c1otyPTPvT2k3ycVOX-ruL64.svg	2026-02-14 15:10:14.755312+00	2026-03-06 19:32:24.861409+00	0101000020E6100000342C21A903D74240B39F41E508D74B40	2026-03-06 19:32:24.861409+00	0.00	0	0	f	\N	\N
678	1796219627	\N	Pavel	\N	https://t.me/i/userpic/320/8MkDv6YDkhqtSRqV3NEKb0Rz4ZOf0NlB_xY9sm6z-so.svg	2026-03-06 15:51:54.788102+00	2026-03-06 15:51:54.788102+00	\N	2026-03-06 15:51:54.788102+00	0.00	0	0	f	\N	\N
704	281767113	Konstantin_inneralchemy	Konstantin	\N	https://t.me/i/userpic/320/HlxR21BvxVOWgnWk5f32AkqF75c_pH497Pk_8vnR9r4.svg	2026-03-06 19:49:16.032352+00	2026-03-06 19:49:16.032352+00	\N	2026-03-06 19:49:16.032352+00	0.00	0	0	f	\N	\N
952	668717686	NyuraKit	Anna	Kit	https://t.me/i/userpic/320/8TWwOs6T942Q68dpEpOj3KFNuB_n5MD3Ehd46mR_8ow.svg	2026-05-11 07:50:57.532508+00	2026-05-27 15:21:50.622435+00	\N	2026-05-27 15:21:50.622435+00	0.00	0	0	f	\N	\N
760	794451988	izzalesaizzagor	izzalesaizzagor	\N	https://t.me/i/userpic/320/7DgmBteOdbAF0DGbJvVFDMqD5CZFuLX5wre1K54NzGM.svg	2026-03-08 19:43:53.410979+00	2026-03-08 19:43:53.410979+00	\N	2026-03-08 19:43:53.410979+00	0.00	0	0	f	\N	\N
679	152663046	Goshishinho	Gᥱ᧐rgᥱ	\N	https://t.me/i/userpic/320/Hu_pbKKt6c5K-uWa5N8vI9rhOrwKkIpqOuzHLCwmHkA.svg	2026-03-06 15:54:06.443595+00	2026-03-06 15:55:19.343721+00	0101000020E6100000BCC3C31412B54240CB2C937563FC4B40	2026-03-06 15:55:19.343721+00	0.00	0	0	f	\N	\N
695	491417113	psycapoeira	Evgeniya	Tundra👁️‍🗨️	https://t.me/i/userpic/320/rBbcR1iRaPP5H22xglpDZbc2ins-1vhiyEUDeynhsFQ.svg	2026-03-06 18:13:38.54723+00	2026-03-06 19:58:23.338972+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-06 19:58:23.338972+00	0.00	0	0	f	\N	\N
707	120951245	nastasi9i	Anastasiia	\N	https://t.me/i/userpic/320/n2ZRiPpXungshTqdo3ZFdf3Suz6bxDQTMAcCBd25BIE.svg	2026-03-06 20:55:54.362052+00	2026-03-06 20:55:54.362052+00	\N	2026-03-06 20:55:54.362052+00	0.00	0	0	f	\N	\N
474	399445929	drkdna	Gerrie	van Boven	https://t.me/i/userpic/320/1PwNGk7fRow6UT0oQ3lrAHHDPCEj8iCjKP_v0ipbHko.svg	2026-02-20 20:30:19.772293+00	2026-03-07 19:50:19.944751+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-07 19:50:19.944751+00	0.00	0	0	f	\N	\N
733	518229679	konstantin_kykaracha	Konstantin	Kykaracha	https://t.me/i/userpic/320/wqTWDViS85hfyzXf77tqt2upfjI0nMGmIEDGuKm4tkQ.svg	2026-03-07 14:54:21.011304+00	2026-03-10 06:13:50.550173+00	\N	2026-03-10 06:13:50.550173+00	0.00	0	0	f	\N	\N
685	669730541	Musta_ryssa	Musta	Ryssä	https://t.me/i/userpic/320/OyeeZ3MXH6pbDVrKJ4F3XpQfrRjKP-B8PLQIxQE2u1w.svg	2026-03-06 16:18:43.449341+00	2026-03-06 16:18:43.449341+00	\N	2026-03-06 16:18:43.449341+00	0.00	0	0	f	\N	\N
710	268861226	iamgolovanov	Евгений	Голованов	https://t.me/i/userpic/320/VE4WIyMqfA-8_pGWg49iVAS5mBxsizSnt5tDSlLvIes.svg	2026-03-07 03:24:47.991964+00	2026-03-07 03:27:01.297407+00	\N	2026-03-07 03:27:01.297407+00	0.00	0	0	f	\N	\N
713	53780354	skramf	YA.ROSH	\N	https://t.me/i/userpic/320/5gIX_sfpOUo_Fm4ldGFCCJlrulvvz4y7k29ty8Sxtng.svg	2026-03-07 06:06:54.934139+00	2026-03-07 06:07:49.418145+00	\N	2026-03-07 06:07:49.418145+00	0.00	0	0	f	\N	\N
688	714182656	Rezida_your_mandala	Резида	Целлер	https://t.me/i/userpic/320/ZI26xjf0d2pqSvfxc9tanQl0-zVB3cJrS08Oii4aDas.svg	2026-03-06 16:47:48.876657+00	2026-03-06 16:47:48.876657+00	\N	2026-03-06 16:47:48.876657+00	0.00	0	0	f	\N	\N
687	314215274	Fatamorganaz	Va	She	https://t.me/i/userpic/320/T0N7zbyknxe1jBeMYG_qAyiA014FOxDH-_2Ab4Iv0ag.svg	2026-03-06 16:37:04.714852+00	2026-03-06 17:01:32.175585+00	0101000020E6100000243FB1A338C842400217F9E605F04B40	2026-03-06 17:01:32.175585+00	0.00	0	0	f	\N	\N
690	49675314	ice_steel	Stem	\N	https://t.me/i/userpic/320/Tddc78RbhE6RifX_hZQj6tfrxZhZQOC9H34vzGJQNvE.svg	2026-03-06 17:05:28.841024+00	2026-03-06 17:05:39.081996+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-06 17:05:39.081996+00	0.00	0	0	f	\N	\N
719	309011426	Andastral	And	Bushuev	https://t.me/i/userpic/320/dvEEoBGMyDTBemClAXSJg0QE0oDegY9-2Whxk3q0unA.svg	2026-03-07 08:02:29.99518+00	2026-03-07 08:02:29.99518+00	\N	2026-03-07 08:02:29.99518+00	0.00	0	0	f	\N	\N
724	1560672668	Pyryrympympym	ꪖꪀꪀꪊᦓꫝᛕꪖ	\N	https://t.me/i/userpic/320/ZYAEPEfABr8yvudFxgIXviZ4A2Al8sv-w7OMQeTzWc8.svg	2026-03-07 11:28:12.009596+00	2026-03-07 11:34:17.599586+00	\N	2026-03-07 11:34:17.599586+00	0.00	0	0	f	\N	\N
1353	902535612	Gr1nd3c4y	Нестор	Фактов	https://t.me/i/userpic/320/lc8bLgKFVGrw8SNK3N1NPatV6RpP8l-kkqGEUv-pmp8.svg	2026-06-17 14:45:20.117527+00	2026-06-17 14:47:13.073377+00	\N	2026-06-17 14:47:13.073377+00	0.00	0	0	f	\N	\N
824	5982981760	lazygarik	Игорь	\N	https://t.me/i/userpic/320/DvnCVfAt07kUfio1cFKoXNZiDF-ZcMM173LYgGi4UWd0mDB4UO5SEbdxssRwqEyF.svg	2026-04-03 07:59:26.983286+00	2026-05-19 21:18:04.342786+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-19 21:18:04.342786+00	0.00	0	0	f	\N	\N
788	323701675	Nostromo_2122	m.	Warsaw	https://t.me/i/userpic/320/iQwiE-R2Uj3NrsZ0y-sheuN7qvZyO_H_sZZuwi0k0h4.svg	2026-03-13 11:06:21.661851+00	2026-03-13 11:06:30.672911+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-13 11:06:30.672911+00	0.00	0	0	f	\N	\N
632	162990073	Jul_Veselova	Julia	\N	https://t.me/i/userpic/320/BrPxmoQttyRbprv9sZvpdFqAxDC_c3C6PKXRpJseLa8.svg	2026-03-01 10:22:09.16272+00	2026-05-15 15:40:09.275628+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-15 15:40:09.275628+00	0.00	0	0	f	\N	\N
1174	635848725	atinsareti	𝙁𝙪𝙣𝙠_𝙎𝙤𝙪𝙡	\N	https://t.me/i/userpic/320/hOGJikwWvVh-6ngvrbV5mW-8pbhUdP2-S0cr6qnuTR0.svg	2026-05-30 17:42:39.071889+00	2026-05-30 17:42:39.071889+00	\N	2026-05-30 17:42:39.071889+00	0.00	0	0	f	\N	\N
703	517626399	sis666666	Система	\N	https://t.me/i/userpic/320/7cdjgghryMzwWwOmZnu_zJPukj6HZidlBufJgJC6Bh8.svg	2026-03-06 19:49:09.74409+00	2026-05-21 13:32:52.376946+00	\N	2026-05-21 13:32:52.376946+00	0.00	0	0	f	\N	\N
1270	719630948	vlaaislove	VladislaV	\N	https://t.me/i/userpic/320/eF0BaC-b9SFeZhbeko9galtR_Q2tJrsEbOFmj6ZzxnY.svg	2026-06-08 10:01:22.021725+00	2026-06-08 10:01:22.021725+00	\N	2026-06-08 10:01:22.021725+00	0.00	0	0	f	\N	\N
808	279664518	dyda1989	Лёня	Лёня	https://t.me/i/userpic/320/iJ1XRszfqkJlae053yCATQFvBe_fgzI77YGN3BASIOI.svg	2026-03-23 21:37:35.954328+00	2026-06-16 20:16:49.380635+00	\N	2026-06-16 20:16:49.380635+00	0.00	0	0	f	\N	\N
1051	198951673	\N	Вячеслав	\N	https://t.me/i/userpic/320/20clUDau77pokpdIw-k5v7Xm2Qol0VKu229RdmCMq0E.svg	2026-05-17 18:20:10.653497+00	2026-05-17 18:20:10.653497+00	\N	2026-05-17 18:20:10.653497+00	0.00	0	0	f	\N	\N
652	290081780	pavelmagpie	Pavel	Sorokin	https://t.me/i/userpic/320/qu39Lm9vggtf1rfVMY2PjgH1MJAt1FjgF2CNBDxIK4s.svg	2026-03-03 12:20:46.653512+00	2026-05-18 08:59:44.864431+00	0101000020E61000001D3E7A9FC0D44240F7DDAFDB68DE4B40	2026-05-18 08:59:44.864431+00	0.00	0	100	f	\N	\N
1075	448081496	was0707	WAS	\N	https://t.me/i/userpic/320/j74BClseMZoxn_WY_NhuRwGYqqD3ULJFATlf8BOPPEE.svg	2026-05-20 09:27:01.965135+00	2026-05-20 09:29:53.962002+00	0101000020E61000008A9245AF314E3E40567DCA0179FC4D40	2026-05-20 09:29:53.962002+00	0.00	0	0	f	\N	\N
839	335387944	dundustik	Danila	Belyaev	https://t.me/i/userpic/320/vKCAmixQWGVDa8du74tFU7OOXzXuyV6JtQ4r1I75FQA.svg	2026-04-03 19:57:33.755091+00	2026-06-06 10:31:39.037428+00	\N	2026-06-06 10:31:39.037428+00	0.00	0	0	f	\N	\N
272	7456981986	ironsmoke_t_1000	T-1000🚀	\N	https://t.me/i/userpic/320/SVUdt1yXoObF6jjAMUGH-2LDBm9DygNIRMjlhlvuFXiiMWm62ulGp7P8evZgdlfi.svg	2026-02-14 14:34:25.504066+00	2026-03-08 20:39:29.727484+00	0101000020E61000009BADBCE47F9E484073F7393E5AE24B40	2026-03-08 20:39:29.727484+00	0.00	0	0	f	\N	\N
794	530422330	Kristina_Vtornik	Кристина	Vtornik	https://t.me/i/userpic/320/5h8N1r7YaAYjDre1LgUSW3olM0i5OgSehpMRw5abZRg.svg	2026-03-15 14:57:16.288154+00	2026-03-15 14:57:16.288154+00	\N	2026-03-15 14:57:16.288154+00	0.00	0	0	f	\N	\N
790	270661678	iTonyJah	Anton	Mr.Was	https://t.me/i/userpic/320/u2TtjQtUckTF4wgEi9UA15Ixaw1upKgyEhmRawcYfPE.svg	2026-03-14 09:37:45.308916+00	2026-03-16 07:50:46.850004+00	\N	2026-03-16 07:50:46.850004+00	0.00	0	0	f	\N	\N
798	103520300	psyservice	::psyservice::	\N	https://t.me/i/userpic/320/rk74I6yPffp2zMYQ35NES4sLv_qei8f-sVteP3yaaok.svg	2026-03-19 07:14:47.135196+00	2026-03-19 07:14:47.135196+00	\N	2026-03-19 07:14:47.135196+00	0.00	0	0	f	\N	\N
803	254603892	maxim_klinkov	Maxim	Klinkov	https://t.me/i/userpic/320/5mxDRQ8uHQW-LnuM6zRiaObaM3c1tGLg7GTEa2-UVqk.svg	2026-03-22 20:04:12.82568+00	2026-03-23 08:00:37.717339+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-03-23 08:00:37.717339+00	0.00	0	0	f	\N	\N
774	164584337	grilledgrill	A	Z	https://t.me/i/userpic/320/-Klm485MmMsZrWmyUJr1lZWJb_xIK8p7_Guhrev6pfo.svg	2026-03-09 20:11:15.155659+00	2026-03-09 20:11:15.155659+00	\N	2026-03-09 20:11:15.155659+00	0.00	0	0	f	\N	\N
954	89809188	doctodoctosb	Илья	\N	https://t.me/i/userpic/320/o2EBLzmF2Ze0FO5iyVKzam0XhZzoNnIUOvM1jAoVHHY.svg	2026-05-11 12:38:51.280087+00	2026-05-11 12:38:51.280087+00	\N	2026-05-11 12:38:51.280087+00	0.00	0	0	f	\N	\N
807	1380528668	Alexandergypsy	ALEXANDER	\N	https://t.me/i/userpic/320/AEcCibGNMF2LV2Ugabr3rR-8W15eJDtd-xPc3ne2OPk.svg	2026-03-23 19:21:14.547784+00	2026-03-23 19:21:14.547784+00	\N	2026-03-23 19:21:14.547784+00	0.00	0	0	f	\N	\N
830	306395450	Julia_yokay	Kansi	\N	https://t.me/i/userpic/320/vvQhoQAfBun15GiYdEnEwVg6ssUkn-28VBsASVHPwzk.svg	2026-04-03 17:38:23.871984+00	2026-04-03 17:38:23.871984+00	\N	2026-04-03 17:38:23.871984+00	0.00	0	0	f	\N	\N
834	207214106	Shustari	Evgeniy	\N	https://t.me/i/userpic/320/wZDFwZK6NQdgpTH3EuHZz5jKABEiZYj7LD4f891aSEk.svg	2026-04-03 18:59:19.926043+00	2026-04-03 18:59:19.926043+00	\N	2026-04-03 18:59:19.926043+00	0.00	0	0	f	\N	\N
835	713544023	Zrm750	Стас	\N	https://t.me/i/userpic/320/XC1KSWnHIAfhXQlfDvnlD3yLWs_NR95ECUqNB8-HIZg.svg	2026-04-03 19:09:07.000725+00	2026-04-03 19:09:34.771741+00	0101000020E61000001D4AFE710CA7424001CA953089DF4B40	2026-04-03 19:09:34.771741+00	0.00	0	0	f	\N	\N
809	1429261562	farmiga69	farmiga	\N	https://t.me/i/userpic/320/jiuChv40vZfYxg_Racq5ZgkCt9SKX99DzJXYkP82mMI.svg	2026-03-24 11:08:02.797262+00	2026-03-24 16:45:25.676511+00	0101000020E6100000D503DB7AF6553E402E4E2C1A87074E40	2026-03-24 16:45:25.676511+00	0.00	0	0	f	\N	\N
816	1105320975	ShattaLove	Mikhail	Shalov	https://t.me/i/userpic/320/QZvsIx6e76azrVGor6752YU-chfyGYD4IpGrMBknbY4.svg	2026-03-25 19:17:02.354468+00	2026-03-25 19:18:24.086366+00	\N	2026-03-25 19:18:24.086366+00	0.00	0	0	f	\N	\N
837	5056643265	BelbekStore	Protagonist	\N	https://t.me/i/userpic/320/9yIHHTLjVsSZk-io1AC29rDS-73Gw3oJjDIp2WS-RPT0GWEyAedhdfPns0zyp38a.svg	2026-04-03 19:36:55.702868+00	2026-04-03 19:37:47.544586+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-03 19:37:47.544586+00	0.00	0	0	f	\N	\N
838	313769548	\N	Anja	G	https://t.me/i/userpic/320/edzqniOsf1QIo8KIV5Jzg4LdQvs0XI5d2iRGJYgHTt4.svg	2026-04-03 19:55:10.952764+00	2026-04-03 19:55:10.952764+00	\N	2026-04-03 19:55:10.952764+00	0.00	0	0	f	\N	\N
840	358531428	Mikhail_Krv	Mikhail K	\N	https://t.me/i/userpic/320/mgh9iSN2GQ2pw05YlPTBToB7WcOoEd2Yef0Ivdwxyfk.svg	2026-04-03 20:01:10.429542+00	2026-04-03 20:01:10.429542+00	\N	2026-04-03 20:01:10.429542+00	0.00	0	0	f	\N	\N
843	347570519	\N	Pittong	\N	https://t.me/i/userpic/320/d3RC0aFDNj7G17UNRou1CpcQatZV0FaAchJdlwIsQVk.svg	2026-04-04 04:20:19.48783+00	2026-04-04 04:20:19.48783+00	\N	2026-04-04 04:20:19.48783+00	0.00	0	0	f	\N	\N
844	357959631	docnos84	nosss	\N	https://t.me/i/userpic/320/7OeZpc2IvQrdVDgYjP2Tl7vjPJsXcUZetAv7puu2IaI.svg	2026-04-04 06:06:20.185902+00	2026-04-04 06:06:20.185902+00	\N	2026-04-04 06:06:20.185902+00	0.00	0	0	f	\N	\N
124	957320680	bornspb	bornspb	\N	https://t.me/i/userpic/320/x1Cnu4PxnnHRx5xzVvmtkR-WuSxMQYA6VXJ5mCV0rUY.svg	2026-02-13 09:45:31.275976+00	2026-04-04 06:07:25.105982+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-04 06:07:25.105982+00	0.00	0	0	f	\N	\N
848	417700143	mountainKid	Sergey	Melnikov	https://t.me/i/userpic/320/YzmQy6eJRRH5K31ejooxfkBPW-YY8aRlLjfxWpYO5Ds.svg	2026-04-04 16:15:39.342929+00	2026-04-04 17:18:20.56848+00	\N	2026-04-04 17:18:20.56848+00	0.00	0	0	f	\N	\N
850	202320777	nicksasov	Nick	Sasov	https://t.me/i/userpic/320/NzILrlIa14a0PlHDOGcq_wW-Naoff8gNhVRwwh-KlTQ.svg	2026-04-04 21:54:20.123187+00	2026-04-04 21:54:20.123187+00	\N	2026-04-04 21:54:20.123187+00	0.00	0	0	f	\N	\N
854	510295261	post7kriptum	PoSt	\N	https://t.me/i/userpic/320/yd87MZMu9WPg0YWRgUXb6anAnwpTDR0K2qslwVUIMAY.svg	2026-04-05 17:37:31.571352+00	2026-04-05 17:37:31.571352+00	\N	2026-04-05 17:37:31.571352+00	0.00	0	0	f	\N	\N
859	341512667	marfa55555	Маруся Марусевич	\N	https://t.me/i/userpic/320/RiyO9UVDQC6o6vUaCI8hyGZQkq-gYqNcBZQjjwO7rns.svg	2026-04-07 10:31:30.247045+00	2026-04-07 10:31:30.394749+00	\N	2026-04-07 10:31:30.247045+00	0.00	0	100	f	\N	\N
820	99999132	nomencognomen	Nomen	Cognomen	https://t.me/i/userpic/320/X11XyvD_b7glWlPXllVkUMRRghEWydsYBiyfe1ackMU.svg	2026-03-30 08:24:03.618365+00	2026-03-30 08:24:03.618365+00	\N	2026-03-30 08:24:03.618365+00	0.00	0	0	f	\N	\N
862	990376488	mariya_dakini	Мария	Смирнова	https://t.me/i/userpic/320/6iywI7F80lackALe-dlRnWWsY00rWrFDJxO564peUKc.svg	2026-04-08 20:03:10.309042+00	2026-04-08 20:03:10.309042+00	\N	2026-04-08 20:03:10.309042+00	0.00	0	0	f	\N	\N
1175	243064386	NotBlock2busted	Oleg	\N	https://t.me/i/userpic/320/kS4SNYd2SbVVbrLOBfLbesD4dJmE7ZSP4suw7nXYS8Q.svg	2026-05-30 18:28:27.238685+00	2026-05-30 18:28:27.238685+00	\N	2026-05-30 18:28:27.238685+00	0.00	0	0	f	\N	\N
251	908191553	acronym14	Acronym	14	https://t.me/i/userpic/320/Uank4YA4_WShMx7rMdk4ptz7Q-gkLmmZV8qtcn_Ycas.svg	2026-02-14 13:31:53.147873+00	2026-04-24 19:06:04.642579+00	0101000020E6100000FC5FA0FDE6D042405278C99C72E14B40	2026-04-24 19:06:04.642579+00	0.00	0	0	f	\N	\N
826	80950544	vaiter	Kirill	Belov	https://t.me/i/userpic/320/LB07ZojDt_I5PUxBrUhFKSguMBLlYTkzv6fZPAwAaYA.svg	2026-04-03 17:00:30.046928+00	2026-06-16 19:57:01.285523+00	\N	2026-06-16 19:57:01.285523+00	0.00	0	0	f	\N	\N
1139	6053447172	ilyaO525	Ilya	Chirkov	https://t.me/i/userpic/320/RtJfdFCEcziuHaUOQR2ouaQ9vYmCGgqAkTG5FcgCYxcHwZMbWqXdRiRajGifXREJ.svg	2026-05-28 12:58:36.793964+00	2026-06-04 07:53:01.962244+00	0101000020E6100000EA2E4725E3913E4076EE584683034E40	2026-06-04 07:53:01.962244+00	0.00	0	0	f	\N	\N
404	162477653	SeregaCamp4rest	Sergei Shabalin	\N	https://t.me/i/userpic/320/sR14Z6HDZO9WB8ntZWnTrDYslIoHHIVlfKBSaEDKhus.svg	2026-02-19 12:17:03.139994+00	2026-04-08 21:25:26.751412+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-08 21:25:26.751412+00	0.00	0	0	f	\N	\N
1019	766702807	Roizor	Ройзор	\N	https://t.me/i/userpic/320/R4ldlg0hd4HZlYaDT3_pq-NGCCa5qrNsJwfz8xR80zo.svg	2026-05-16 15:21:43.193388+00	2026-05-22 07:10:43.020646+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-22 07:10:43.020646+00	0.00	0	0	f	\N	\N
866	556788935	chibiribibi	🩷Chibi🩷	\N	https://t.me/i/userpic/320/9EhAUfFAHBwNTz-VqzboVeTh6h3CQMvjSNO7N3k-DLE.svg	2026-04-10 06:54:54.200591+00	2026-06-16 19:58:56.663281+00	\N	2026-06-16 19:58:56.663281+00	0.00	0	0	f	\N	\N
865	7556414918	O28485	..	\N	https://t.me/i/userpic/320/ebozSGFOPxWnlaoI1Qv3VawOklkp0xjyH5hUr-nMy-2gWdziKa4xq2f9aZTxjPzn.svg	2026-04-09 19:57:39.86573+00	2026-04-09 19:57:39.86573+00	\N	2026-04-09 19:57:39.86573+00	0.00	0	0	f	\N	\N
1358	17508815	evgeny	Eugn	Matvyv	https://t.me/i/userpic/320/qUnczyR1gN2Uu5DDwIRoSna75Ykw5Ibl1t7ybAxN7uM.svg	2026-06-17 20:41:35.855608+00	2026-06-17 20:41:35.855608+00	\N	2026-06-17 20:41:35.855608+00	0.00	0	0	f	\N	\N
897	-744263	vk744263	Юлия	Павлова	https://sun1-25.vkuserphoto.ru/s/v1/ig2/plRCmmgLxo5nc4MSOqnfIbJwD3rr_ld70ejz5rzFygPMXkT0dWxjAwWIb3Ot_n9kOBcgb2ZdVhPEfiZAXyNYdUJu.jpg?quality=95&crop=206,59,189,189&as=32x32,48x48,72x72,108x108,160x160&ava=1&cs=50x50	2026-04-24 19:54:04.324869+00	2026-04-24 19:55:11.146372+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-24 19:55:11.146372+00	0.00	0	0	f	\N	\N
620	337821005	Alexandr_Shapovalov	Alex	Shapovalov	https://t.me/i/userpic/320/dj4001pDRjmoYVRLE6GeI2EIW0KJoy53m7LPDi98bys.svg	2026-02-28 17:04:28.773259+00	2026-04-12 09:55:30.603427+00	0101000020E6100000E695AD7DC86E424051B4994A86F44B40	2026-04-12 09:55:30.603427+00	0.00	0	0	f	\N	\N
871	206898938	ozibo	osibo	\N	https://t.me/i/userpic/320/vj7Md-yQea9ptax5xU6SOAH8pDB98rCAAQ10AvPu2yQ.svg	2026-04-13 01:24:55.822998+00	2026-04-13 01:24:55.822998+00	\N	2026-04-13 01:24:55.822998+00	0.00	0	0	f	\N	\N
872	658636817	spacemalina	Алина	ВеДаРа	https://t.me/i/userpic/320/JhsOMIycgybpawC1bbaFgIwxqwhxZwyVlWyOg9lUdPc.svg	2026-04-13 12:17:47.798447+00	2026-04-13 12:17:47.798447+00	\N	2026-04-13 12:17:47.798447+00	0.00	0	0	f	\N	\N
928	547770338	Dahutyan	Drariя	\N	https://t.me/i/userpic/320/Ve-Px_FfKJgCIcyua4fCiWfpAtm34IwCcctY4Sl5UtY.svg	2026-05-08 14:34:49.790791+00	2026-06-17 05:53:45.840306+00	\N	2026-06-17 05:53:45.840306+00	0.00	0	0	f	\N	\N
874	457105005	Mary_Myagkaya	Мария	\N	https://t.me/i/userpic/320/Wyvu70tqcPqJasYWlEAUQGACKRecOJo6nyMCPNDxfR8.svg	2026-04-14 08:25:42.342218+00	2026-04-14 08:25:42.342218+00	\N	2026-04-14 08:25:42.342218+00	0.00	0	0	f	\N	\N
875	6480518417	\N	scottina	\N	https://t.me/i/userpic/320/ATh6ZlTQ-M7sE4d3C9NfnG5nRwMNucQ6p0iyrsHxwn1LTRSt8MQeSrenTTmtCV2N.svg	2026-04-14 13:41:33.548427+00	2026-04-14 13:41:33.548427+00	\N	2026-04-14 13:41:33.548427+00	0.00	0	0	f	\N	\N
877	916432638	pirpirtg	pirpir	\N	https://t.me/i/userpic/320/Gcrf5emZwn-ZP-BiY0yKveR0s5PnQxwiHXoH2Ort9yk.svg	2026-04-15 05:30:16.77813+00	2026-04-15 15:22:27.792042+00	\N	2026-04-15 15:22:27.792042+00	0.00	0	0	f	\N	\N
882	340601464	crystobalmartinez	Crystobal	Martínez	https://t.me/i/userpic/320/VGz0smtRfzOLyfCWywjbr5xFbZqgv7jicajI9RRZ-gM.svg	2026-04-19 13:29:36.23133+00	2026-04-19 13:29:36.23133+00	\N	2026-04-19 13:29:36.23133+00	0.00	0	0	f	\N	\N
899	708658361	VladimirKonovalovGolos	Владимир	Коновалов | вокал и английский	https://t.me/i/userpic/320/QsA2lYbVuDIMwfxXdleyPqTt9duq-tLfnhE6fWpVZtc.svg	2026-04-24 21:36:00.077214+00	2026-04-24 21:36:18.906328+00	0101000020E6100000B6FBB03962CF424042F5C594FEEE4B40	2026-04-24 21:36:18.906328+00	0.00	0	0	f	\N	\N
1373	748340087	lyagushkinapadut	alexandra	\N	https://t.me/i/userpic/320/H21bVexwRimEheGvlNK5VSmmh05JrxBoyS1UEiPOTUI.svg	2026-06-19 08:55:47.130132+00	2026-06-19 08:55:47.130132+00	\N	2026-06-19 08:55:47.130132+00	0.00	0	0	f	\N	\N
883	830872866	marina_manasa	Marina	Sitnikova	https://t.me/i/userpic/320/M3Sl-ltGfFJcdvf81lGW24z6LsKsdbRl7Zg7gQHzgqk.svg	2026-04-20 15:29:24.57583+00	2026-04-20 15:32:34.742052+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-20 15:32:34.742052+00	0.00	0	0	f	\N	\N
1078	338110678	AlexZRN	Alex	\N	https://t.me/i/userpic/320/zIqreJ1znPdz57zKMhMFVDPVIPmNdxehOEjvL_FRPVo.svg	2026-05-20 09:31:37.903086+00	2026-05-20 09:31:37.903086+00	\N	2026-05-20 09:31:37.903086+00	0.00	0	0	f	\N	\N
884	1038701314	alexey_galaktika	Alexey Galaktika	\N	https://t.me/i/userpic/320/DycKHF58wENBIlcln1fLdrbPOHGNcG316maVmkdAodI.svg	2026-04-20 15:52:08.788534+00	2026-04-20 15:53:26.319092+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-04-20 15:53:26.319092+00	0.00	0	0	f	\N	\N
936	584182318	\N	Александра	\N	https://t.me/i/userpic/320/Bq9mMVx6hmm2KtHnTfVrZO3QlMsVwf3ABd85rYFLPeM.svg	2026-05-09 15:03:09.803143+00	2026-05-10 08:22:44.34102+00	\N	2026-05-10 08:22:44.34102+00	0.00	0	0	f	\N	\N
935	216294440	Dubvnnnnnn	Dubvnnnnnn	\N	https://t.me/i/userpic/320/Qq0TqGhqEmszafmJn-mp0-nKDEg95PMfqueDE93s9vU.svg	2026-05-09 15:01:36.768942+00	2026-05-10 09:57:28.584193+00	\N	2026-05-10 09:57:28.584193+00	0.00	0	0	f	\N	\N
912	447641303	sergey_seg	Seg	\N	https://t.me/i/userpic/320/8wItEPom9ovm6j4IkhfkPAazNhC7w-exrkGfG7SCDvg.svg	2026-04-29 20:07:54.095944+00	2026-04-29 20:13:42.121855+00	\N	2026-04-29 20:13:42.121855+00	0.00	0	0	f	\N	\N
918	102409130	himynameismax	Max	\N	https://t.me/i/userpic/320/icN32MXeegehvJMNpn3GHUXBBrDldXv7mJ5x-1Gzj2o.svg	2026-05-07 13:09:26.008801+00	2026-05-07 13:09:26.008801+00	\N	2026-05-07 13:09:26.008801+00	0.00	0	0	f	\N	\N
957	6408235575	Mahmudozz	Рустам	Хан	https://t.me/i/userpic/320/gaKa3WxOzgQrnq2ZgLkwuZMHz2Gx5TbG3n6QYvX4MtZXBt0pv4vwLN-bqhjsJFqj.svg	2026-05-11 15:03:21.600107+00	2026-05-11 15:03:32.849566+00	\N	2026-05-11 15:03:21.600107+00	0.00	0	100	f	\N	\N
920	-31719661	vk31719661	Кирилл	Семёнов	https://sun1-29.vkuserphoto.ru/s/v1/ig2/rCspB-4NQ35X3ely9iSD1fOkuNkUuHwPP-iKWeu73dNB6rwhaPkX5gubMQ3Dy-zwVXnjny_n2SiTUqvuTghlgZjy.jpg?quality=95&crop=135,312,404,404&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360&ava=1&cs=50x50	2026-05-07 21:43:26.364988+00	2026-05-07 21:43:47.929373+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-07 21:43:47.929373+00	0.00	0	0	f	\N	\N
922	252226865	R0MANESC0	Roman	Gavrilov	https://t.me/i/userpic/320/3jp_z636vdEqko2Sw7KfGuwZt6l4yoUFIFNxNc3dPR0.svg	2026-05-07 22:07:00.154904+00	2026-05-08 09:57:07.534011+00	\N	2026-05-08 09:57:07.534011+00	0.00	0	0	f	\N	\N
873	124148007	Kosh12	Kosh12	\N	https://t.me/i/userpic/320/p-w7nRr5Er_ak4TWYd5JVO2bud6ApN655Wr6vMOp6hk.svg	2026-04-14 08:19:13.200461+00	2026-05-08 13:36:25.313476+00	\N	2026-05-08 13:36:25.313476+00	0.00	0	0	f	\N	\N
931	429915159	verhoffen_505	Nadejda	\N	https://t.me/i/userpic/320/1Hj3zADhNBTHuQ5tOaOUQTY5jZuItom8M9wbAKe9rSc.svg	2026-05-08 21:21:21.788+00	2026-05-08 21:22:40.107725+00	0101000020E6100000D22E5303BA57424062893477E6944B40	2026-05-08 21:22:40.107725+00	0.00	0	0	f	\N	\N
932	2065121662	s_weydenkeller	Александра	Вейденкеллер	https://t.me/i/userpic/320/5sK81nLHt3YrsotG2t-196bgZa9xbQhXViJNWN-M7lc.svg	2026-05-09 05:07:11.606586+00	2026-05-09 05:07:11.606586+00	\N	2026-05-09 05:07:11.606586+00	0.00	0	0	f	\N	\N
933	473314590	DanilaTerentev	Danila	Terentev	https://t.me/i/userpic/320/6XutkX36-LL6161eAX-U9LI2XgnxkMCcUOf704jh8mA.svg	2026-05-09 08:18:57.701266+00	2026-05-09 08:18:57.701266+00	\N	2026-05-09 08:18:57.701266+00	0.00	0	0	f	\N	\N
958	296057481	Bongo_69	Dmitry	\N	https://t.me/i/userpic/320/hMnrDqIBT_3LiRQ2D1RiAAUkVEJVMutkPBxRZDYg1uQ.svg	2026-05-11 15:48:47.25501+00	2026-05-11 15:48:52.516736+00	\N	2026-05-11 15:48:47.25501+00	0.00	0	100	f	\N	\N
959	1410004003	\N	Екатерина	Кондратова	https://t.me/i/userpic/320/WqTLN38I_AC2lxGf9-2tgIQg_2pO2BwfSPIKXXn0vJ4.svg	2026-05-11 15:58:40.702512+00	2026-05-11 15:58:45.059722+00	\N	2026-05-11 15:58:40.702512+00	0.00	0	100	f	\N	\N
1171	-210606482	vk210606482	Marina	Gromova	https://sun1-54.vkuserphoto.ru/s/v1/ig2/GhgeT4uKSzvoFAOVzsKqWRvkt1xq_ZEZ0gB4B0SMWrgjZAbj6BKxMZF3rk2DygxfK5VHY20skNkI8sjmCgCGOTYd.jpg?quality=96&crop=174,86,322,322&as=32x32,48x48,72x72,108x108,160x160,240x240&ava=1&cs=50x50	2026-05-30 14:26:42.156362+00	2026-05-30 14:26:46.18516+00	0101000020E6100000174F095A42493E407C964387D6004E40	2026-05-30 14:26:46.18516+00	0.00	0	0	f	\N	\N
1427	188918830	ivanchin	Андрей	Иванчин	https://t.me/i/userpic/320/7679KbnXE3iNfd16tGLgwQSsWqDkkRhDPQi4hbu8P2c.svg	2026-06-23 23:29:11.155209+00	2026-06-23 23:30:06.555958+00	\N	2026-06-23 23:30:06.555958+00	0.00	0	0	f	\N	\N
1213	304928275	kateintrvl	Katerina	\N	https://t.me/i/userpic/320/azESH2Uw5NsBQcjS3yXTX_4O1CeH9K_CHanYdpReSlQ.svg	2026-06-03 09:14:17.725943+00	2026-06-03 09:59:41.89187+00	\N	2026-06-03 09:59:41.89187+00	0.00	0	0	f	\N	\N
1433	240777771	Bshinee	Vadim Shi͠ne	\N	https://t.me/i/userpic/320/fkTK57APYzo6mTu3JHvHYMcZXtgphButGeU7HYoq9Lk.svg	2026-06-24 08:24:28.434016+00	2026-06-24 08:24:28.434016+00	\N	2026-06-24 08:24:28.434016+00	0.00	0	0	f	\N	\N
1066	1772189425	ElenaShiba16	elena	shiba	https://t.me/i/userpic/320/e5ph9GkwXV--zMCTFv_ib-cyo740wsJd56Et9C6SYEg.svg	2026-05-19 15:57:42.290666+00	2026-05-31 08:51:38.870731+00	\N	2026-05-31 08:51:38.870731+00	0.00	0	100	f	\N	\N
368	392159605	Natasis	Христенко	Наталья	https://t.me/i/userpic/320/EmclHVhxGjVXezGQD7STxybWqW3bAhHD_CEWXDGqQuI.svg	2026-02-17 06:55:00.69104+00	2026-05-13 10:38:01.110632+00	\N	2026-05-13 10:38:01.110632+00	0.00	0	100	f	\N	\N
1217	544668063	mr_probability	PYOTR	\N	https://t.me/i/userpic/320/jpPLWfg8lP-64iuIEMnkWTNQ40fhQ3csgRJFE44f8xc.svg	2026-06-03 10:02:21.612552+00	2026-06-03 10:02:21.612552+00	\N	2026-06-03 10:02:21.612552+00	0.00	0	0	f	\N	\N
968	467399025	Albik_a	Albina	\N	https://t.me/i/userpic/320/CX4ZwlmhkchQk-sRR5k7G5EiN1miiGFSExbW669mDzk.svg	2026-05-13 10:42:08.786521+00	2026-05-13 10:50:34.154092+00	\N	2026-05-13 10:50:34.154092+00	0.00	0	0	f	\N	\N
1439	480013046	Burzavr	Vladimir	K	https://t.me/i/userpic/320/GELP1NxKWrFZx6YH__scp35Cn-ce4_sm6k1XW5vL6UY.svg	2026-06-24 11:39:43.283043+00	2026-06-24 11:39:43.283043+00	\N	2026-06-24 11:39:43.283043+00	0.00	0	0	f	\N	\N
1032	318958032	Kostyarik_T	Kostyarich	\N	https://t.me/i/userpic/320/D5ow3l8wE3bUC2OojoLsGV6atd8CEoeU4VHE7uZXSn8.svg	2026-05-16 23:30:06.555712+00	2026-05-17 04:48:00.760011+00	0101000020E61000001B2C9CA4F9B9424075CEAA2A8F004C40	2026-05-17 04:48:00.760011+00	0.00	0	0	f	\N	\N
334	93163730	pec9999	Сritical thinker	\N	https://t.me/i/userpic/320/7MQBtE1KaCtMm8jLymKPtkW9-5I0Oz_3NxgVCG1oZUs.svg	2026-02-15 11:32:30.947531+00	2026-06-17 16:30:18.91197+00	0101000020E6100000ADDADA673AF64240C3A68416C8E94B40	2026-06-17 16:30:18.91197+00	0.00	0	0	f	\N	\N
1580	1241769461	lesovoyy	Илья Лесовой	\N	https://t.me/i/userpic/320/kieze86eX57wp2spcWQ_JVXAw9pVcAFKt0AocQNFGC0.svg	2026-07-02 06:42:10.782376+00	2026-07-02 06:42:22.42865+00	0101000020E6100000472281D72BFC42402D75B9C646E94B40	2026-07-02 06:42:22.42865+00	0.00	0	0	f	\N	\N
295	509555788	alllullla	A||A	\N	https://t.me/i/userpic/320/8fYtcK9o_q6SeewAtevn-DQlZuBjC3bf2i9GgjrPRqs.svg	2026-02-14 16:43:59.482409+00	2026-06-30 08:18:19.086146+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 08:18:19.086146+00	0.00	0	0	f	\N	\N
701	891487411	Whazzupslav	Whatsupslav	Ozhek	https://t.me/i/userpic/320/ZQuBzVlVMdnGxhBfCtcTolsaRqmaWGUUUlc7Qck3oTU.svg	2026-03-06 19:05:08.276767+00	2026-05-13 11:29:37.763547+00	\N	2026-05-13 11:29:37.763547+00	0.00	0	0	f	\N	\N
973	6403241506	ventilyator999	Kastor	Troy	https://t.me/i/userpic/320/junZsGo1zK0hIeI8tOMJnaYOB7GJzxe6KrbW_S8cygjRjz3kLNo-KuQASRqi4eOl.svg	2026-05-13 12:01:01.828323+00	2026-05-13 12:02:51.165277+00	\N	2026-05-13 12:02:51.165277+00	0.00	0	0	f	\N	\N
974	536617699	pHoto_Shaman	Вера	Кучерявая	https://t.me/i/userpic/320/nYa3yiNTCW_tPnsLu7f3FJy7zEp1g6DznaLxtJYuk-Q.svg	2026-05-13 12:20:40.46451+00	2026-05-13 12:20:40.46451+00	\N	2026-05-13 12:20:40.46451+00	0.00	0	0	f	\N	\N
988	395225094	Sweetik	Svetik	\N	https://t.me/i/userpic/320/_6xUQ_QvjHUtqRMYtfjX42nuqaEC3LS-UHMicNxWa6s.svg	2026-05-14 03:04:18.253353+00	2026-06-18 19:35:33.844138+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-18 19:35:33.844138+00	0.00	0	0	f	\N	\N
1391	323139428	Artpanz	Artur	\N	https://t.me/i/userpic/320/hn7QLoWiCccxoXpHDDK-n9v1bTLqgJ8wkg6Kn_h8ekQ.svg	2026-06-20 09:21:05.513248+00	2026-06-20 09:21:05.513248+00	\N	2026-06-20 09:21:05.513248+00	0.00	0	0	f	\N	\N
1000	430935922	tevortho	Екатерина	\N	https://t.me/i/userpic/320/pDfEtdqE5DydXb0bcnq9u6jujXWtRMMGyllgJVSOWlU.svg	2026-05-16 11:43:43.634864+00	2026-06-30 09:15:42.685029+00	\N	2026-06-30 09:15:42.685029+00	0.00	0	0	f	\N	\N
1042	254036090	sualto	Natalia	\N	https://t.me/i/userpic/320/mM9Uq3SG4HABoN578HtLLzStOlt_GifA4hjz0qDh2yQ.svg	2026-05-17 10:31:15.886757+00	2026-05-17 10:31:15.886757+00	\N	2026-05-17 10:31:15.886757+00	0.00	0	0	f	\N	\N
960	7048667725	anfisa_aka_koba	Anfisa aka	Koba	https://t.me/i/userpic/320/-6_o97X7gFSRLxmB4WXb8qoCkBWCVTnyfh0AHjpx38IBNuymfb8IkoGLCeqHuafw.svg	2026-05-13 10:36:12.519245+00	2026-05-13 15:29:19.332877+00	\N	2026-05-13 15:29:19.332877+00	0.00	0	0	f	\N	\N
1045	524516721	dmitrijzabelin	Dmitrij	Zabelin	https://t.me/i/userpic/320/PWCx8ZQ5grH-aFirZyncy4Hmj70GAb3NDQ9eSmENe7Y.svg	2026-05-17 13:36:45.238279+00	2026-05-17 13:39:35.282319+00	\N	2026-05-17 13:39:35.282319+00	0.00	0	0	f	\N	\N
978	1822867691	Avenpets	Dashoo	\N	https://t.me/i/userpic/320/j8GmL_blLRgfKeZuAss5KbNq2nfWcLBE2If39e_56c8.svg	2026-05-13 15:20:43.122983+00	2026-05-13 16:23:53.358461+00	\N	2026-05-13 16:23:53.358461+00	0.00	0	0	f	\N	\N
1038	393834167	\N	Elena	Karpukhina	https://t.me/i/userpic/320/sKvsaTWGMRaBzMfZ8MhKNYhepi4qZfJk1_iWyR-XUxA.svg	2026-05-17 10:06:03.988112+00	2026-05-17 14:59:13.21539+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-17 14:59:13.21539+00	0.00	0	0	f	\N	\N
985	576207097	madijikjilupeji	maxim	\N	https://t.me/i/userpic/320/O5UjUFOVPyEnra8MjcSklbbaNcff9Yq44lrVtMLhba0.svg	2026-05-13 17:56:29.152805+00	2026-05-13 17:56:29.152805+00	\N	2026-05-13 17:56:29.152805+00	0.00	0	0	f	\N	\N
989	143452409	kitelesha	Alexey	\N	https://t.me/i/userpic/320/2PqdRyvOZiS_IqdyYqnjnfXmlpjGNSkNde7XzOqMl8Q.svg	2026-05-14 10:58:08.801132+00	2026-05-14 10:58:08.801132+00	\N	2026-05-14 10:58:08.801132+00	0.00	0	0	f	\N	\N
399	587997508	Vvoyager747	V	K	https://t.me/i/userpic/320/UwHq1MGL5AylZqTeG7TOzqE7NILjFNinCnqXEQk1A5o.svg	2026-02-19 11:47:53.471427+00	2026-05-16 15:34:52.120787+00	0101000020E6100000BC74385F91D6424040D8CE9C9AE44B40	2026-05-16 15:34:52.120787+00	0.00	0	100	f	\N	\N
1073	122695868	iAnastu	Anastusha	\N	https://t.me/i/userpic/320/RonTIcj4rbCXjjOscZD8qgJzZq42RrjcqtlmjjPK__o.svg	2026-05-20 08:03:38.319504+00	2026-05-20 09:47:39.893402+00	0101000020E6100000F426CC394DAF4840C4EA49E107BD4A40	2026-05-20 09:47:39.893402+00	0.00	0	0	f	\N	\N
1082	122867711	Vibovskiy	Вайбовский	\N	https://t.me/i/userpic/320/Oj0go1Q1iMV74_0IcfQ5NMD3_8jHpcDFH_VX_0yCoVo.svg	2026-05-20 10:52:22.249858+00	2026-05-20 10:53:45.899056+00	\N	2026-05-20 10:53:45.899056+00	0.00	0	0	f	\N	\N
1083	287497342	NopersonNoname	dmitry	m	https://t.me/i/userpic/320/lXBedohrSe3aoiX96Wye8apsLHWvnh24aN2iNFW0C2w.svg	2026-05-20 13:16:05.219518+00	2026-05-20 13:26:42.797317+00	0101000020E610000010F02F1849B24D40E767E890C6DA4D40	2026-05-20 13:26:42.797317+00	0.00	0	0	f	\N	\N
217	1893786751	M_Julia_4	Julia	Merzlikina	https://t.me/i/userpic/320/vSpn3AInirJcSaMI5GGGlgSCsMFxJQDxoplZEqN951U.svg	2026-02-14 12:10:57.227295+00	2026-05-19 08:04:06.448651+00	0101000020E6100000AEC487198FC742407397D1594DF14B40	2026-05-19 08:04:06.448651+00	0.00	0	0	f	\N	\N
864	1072365395	miyamana	Anastasia	Chi	https://t.me/i/userpic/320/giKSI5sKGzCvL6KMnqrq39EHY2ZNBRy6ge6Bmd0oU9A.svg	2026-04-09 08:51:29.771559+00	2026-05-21 01:16:02.558109+00	\N	2026-05-21 01:16:02.558109+00	0.00	0	0	f	\N	\N
1090	947493485	PSY_IX	Просто	В	https://t.me/i/userpic/320/TQ_OD65Uz3SIfoQ-4W8xYdeoV5gVbJOaV4axvvgui30.svg	2026-05-21 05:21:03.613662+00	2026-05-21 05:21:03.613662+00	\N	2026-05-21 05:21:03.613662+00	0.00	0	0	f	\N	\N
61	156311855	picapicachuuu	Picapicachuuu	\N	https://t.me/i/userpic/320/-k_eiTGN9zEHSoRRt5A52szpLahETWVdmlbL5ryqfRQ.svg	2026-02-12 10:52:29.047832+00	2026-05-21 06:42:10.995862+00	\N	2026-05-21 06:42:10.995862+00	0.00	0	0	f	\N	\N
1172	644081372	gruuvvv	Илья	Григорьев	https://t.me/i/userpic/320/jpYtyx301-EKQJ4tYPuE3KZPWS3RiYjUhDYXOGFyMbM.svg	2026-05-30 14:27:21.614742+00	2026-05-30 14:27:21.614742+00	\N	2026-05-30 14:27:21.614742+00	0.00	0	0	f	\N	\N
1177	738484883	olegshengen	Олег	Воробьев	https://t.me/i/userpic/320/ezJfii5XwCt9PzxCJTuKL6kTl4cbqlZeTxsd_XUldP8.svg	2026-05-31 04:34:22.953538+00	2026-05-31 04:34:22.953538+00	\N	2026-05-31 04:34:22.953538+00	0.00	0	0	f	\N	\N
1180	290522682	Masslvr	Aleksandr	Maslov	https://t.me/i/userpic/320/D3yTli-LbHeJf5WuIgUi6IrwRFMRjjGwZyR6vWr1Rb0.svg	2026-05-31 09:30:03.120542+00	2026-05-31 09:30:03.120542+00	\N	2026-05-31 09:30:03.120542+00	0.00	0	0	f	\N	\N
1225	253424059	fxstlxw	Mixa	Bánh bao	https://t.me/i/userpic/320/hwLVi8-QVWRl0A5xzLb5hERnEQuT8b0N5gKTke4X_7g.svg	2026-06-04 08:28:58.063603+00	2026-06-04 08:28:58.063603+00	\N	2026-06-04 08:28:58.063603+00	0.00	0	0	f	\N	\N
1276	446033841	Evgeny_Kiryukhin	Женя	\N	https://t.me/i/userpic/320/LvQ_9YuiVTMzXNUrIYsjCg5sGVx3QCS5BUBTyhHBOgc.svg	2026-06-08 14:14:51.273515+00	2026-06-08 14:14:51.273515+00	\N	2026-06-08 14:14:51.273515+00	0.00	0	0	f	\N	\N
269	532018173	atremtabooo	Artem	\N	https://t.me/i/userpic/320/VhcJfSr-JN03_qhmeCqMXvrdzaUpyK7h6VQJu_7jLJc.svg	2026-02-14 14:28:42.417678+00	2026-07-01 20:01:53.218549+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 20:01:53.218549+00	0.00	0	200	f	\N	\N
1227	392334875	\N	Ярослав Константинович	\N	https://t.me/i/userpic/320/xW4ju2Vs-3pFwbJMmFN08BnWTqXLL10UK4Sre0I2ibU.svg	2026-06-04 10:24:26.34001+00	2026-06-04 10:24:26.34001+00	\N	2026-06-04 10:24:26.34001+00	0.00	0	0	f	\N	\N
1220	294122930	pocket_tape	Pocket tape	\N	https://t.me/i/userpic/320/nPLJeMev6Qp_fML7VWveA9vlq7Wsvm19tIFVhxWkNm8.svg	2026-06-03 18:30:24.890885+00	2026-06-27 09:57:21.31173+00	\N	2026-06-27 09:57:21.31173+00	0.00	0	0	f	\N	\N
1369	1383920484	mazzal25	Александр	\N	https://t.me/i/userpic/320/03P9vryB1r8gZ9aKUVAiCM-ppj9wl0_KAaZ_xWxDO40.svg	2026-06-18 22:33:16.73793+00	2026-06-18 22:33:16.73793+00	\N	2026-06-18 22:33:16.73793+00	0.00	0	0	f	\N	\N
1374	369538168	argeberge	Arge	Berge	https://t.me/i/userpic/320/fLYkboVqXmZOgWL4rf4s8_3VsQHjvRAo-0d4Iw1cZPA.svg	2026-06-19 09:49:19.168677+00	2026-06-19 10:06:53.970359+00	\N	2026-06-19 10:06:53.970359+00	0.00	0	0	f	\N	\N
1095	1089638456	ObyOne88	𝕶𝖎𝖗𝖎𝖑𝖑	\N	https://t.me/i/userpic/320/srA3J3VGfnvkDvlTT3cXhNQjjcGGPCI3McG-_p0GCv0.svg	2026-05-21 07:32:00.746771+00	2026-05-21 08:55:45.420294+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-21 08:55:45.420294+00	0.00	0	0	f	\N	\N
1105	1071985473	Anna_koleso	Anna	\N	https://t.me/i/userpic/320/0PdISn9S3N9NNXacKb7rO60hcT1lUaprZlky1qe5ZIc.svg	2026-05-22 04:29:19.806062+00	2026-06-07 14:17:08.345164+00	\N	2026-06-07 14:17:08.345164+00	0.00	0	0	f	\N	\N
1131	8517794690	ergodika	Gabriela Velitch	\N	https://t.me/i/userpic/320/n_4cOMCwT28E8GU5Ubrl-yqxzj2LaNUwZtCiKcJxLpMSN6EPDCdVsWCI_dB-lzl_.svg	2026-05-27 09:03:16.95649+00	2026-06-07 16:10:29.939254+00	\N	2026-06-07 16:10:29.939254+00	0.00	0	0	f	\N	\N
1499	872146366	Veronika_Lestrance	Вероника	Майнингер	https://t.me/i/userpic/320/TF3OCI3R2rbn3H72b4cTFMEZcGeB2W0PRg9jz_Kvgjw.svg	2026-06-27 19:16:56.064541+00	2026-06-27 19:16:56.064541+00	\N	2026-06-27 19:16:56.064541+00	0.00	0	0	f	\N	\N
1121	667378871	oblack_0	Ася 🫧	\N	https://t.me/i/userpic/320/5wglYvnXPaTi71Te_PqCotSHsBOH227icHRPYH3Scsg.svg	2026-05-25 18:10:46.664137+00	2026-06-16 19:52:16.734368+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-16 19:52:16.734368+00	0.00	0	0	f	\N	\N
1116	403581885	tihkalcoholic	ª	b	https://t.me/i/userpic/320/VJ4mLz2TCpZr8Hkm3o6P3A_otwq31NU_pBaUp5lkfeE.svg	2026-05-23 08:45:07.818442+00	2026-06-16 20:45:50.675363+00	\N	2026-06-16 20:45:50.675363+00	0.00	0	0	f	\N	\N
858	45512907	shstva	Stas	\N	https://t.me/i/userpic/320/-et1q8pYDA_AURF4bKKohy6R7i5eaowif2T5PSsi_PE.svg	2026-04-06 15:55:38.463212+00	2026-06-16 20:55:03.083752+00	\N	2026-06-16 20:55:03.083752+00	0.00	0	0	f	\N	\N
1477	326373481	Danila_Bratcom	Danil	K	https://t.me/i/userpic/320/ZclTNiq-2p0a8wSoMIo6dxc4JRLKC28d72DTd1z3YNA.svg	2026-06-26 06:33:09.09866+00	2026-06-26 06:33:09.09866+00	\N	2026-06-26 06:33:09.09866+00	0.00	0	0	f	\N	\N
1109	1394012445	\N	Окси	\N	https://t.me/i/userpic/320/K0O8b7TW9EaMMRt1NEboSt1JAAqPDDSIFpodPyzR5CI.svg	2026-05-22 10:16:18.188235+00	2026-05-22 13:59:53.505598+00	0101000020E61000006889DF5EE3D742407029424530F14B40	2026-05-22 13:59:53.505598+00	0.00	0	100	f	\N	\N
1114	7449964747	Stepangrigorian	Степан	\N	https://t.me/i/userpic/320/YO-RH5cmcJ6tvBbRM20MWxBhFPn_Vsfwd5CCF8v6tLXO1SmlOQXxnpYtMYNo7KoJ.svg	2026-05-22 15:38:41.760176+00	2026-05-22 15:38:41.760176+00	\N	2026-05-22 15:38:41.760176+00	0.00	0	0	f	\N	\N
1187	8072705426	darkriver25	Pretty	Vacant	https://t.me/i/userpic/320/8FuY5UKaGCGQWcWxZL-MMWYvjpt2f3SdCbnRM8yXd5h5JgLoEe9engVikjxj5mnv.svg	2026-05-31 20:21:11.617624+00	2026-05-31 20:26:53.49218+00	\N	2026-05-31 20:26:53.49218+00	0.00	0	0	f	\N	\N
1118	164101186	CatPercik	Tima	Tima	https://t.me/i/userpic/320/0UDlGMD2a16fFndq_vtsLcWs0pzUqi_rF8Btu5mH-YM.svg	2026-05-24 16:06:12.727088+00	2026-05-24 19:21:52.451087+00	\N	2026-05-24 19:21:52.451087+00	0.00	0	0	f	\N	\N
1124	446781722	mary0pyre	La Grenouille	Marie	https://t.me/i/userpic/320/RrSF1bd3xDr43U52FDVo2m555xVNnRF6A9v7oyPXXkM.jpg	2026-05-26 06:25:00.973113+00	2026-05-26 17:29:36.218408+00	\N	2026-05-26 17:29:36.218408+00	0.00	0	0	f	\N	\N
274	714260951	julia_lukashina	Julia	\N	https://t.me/i/userpic/320/2li4SURvsNSMK9j_RZaCIT5yBPp0ZHB1iWMzQp7knvY.svg	2026-02-14 14:47:04.060883+00	2026-05-28 08:52:00.391767+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-28 08:52:00.391767+00	0.00	0	0	f	\N	\N
1140	202716993	rondundon	Родион	Азаревич	https://t.me/i/userpic/320/bTeZ3gPnbLoWEo8J0H_n7CxG0ISsB2r-9HeN9caU8tc.svg	2026-05-28 17:19:40.767966+00	2026-05-28 17:19:40.767966+00	\N	2026-05-28 17:19:40.767966+00	0.00	0	0	f	\N	\N
1142	256371512	makstrip	Макс	Максимов	https://t.me/i/userpic/320/pR556KO5FjmpQO_nUbuwyIm501o4P2yJkY5Sgf5tUHU.svg	2026-05-28 17:24:47.700261+00	2026-05-28 17:24:47.700261+00	\N	2026-05-28 17:24:47.700261+00	0.00	0	0	f	\N	\N
1147	8217074028	Pash_Be	Pasha	\N	https://t.me/i/userpic/320/Hlp4EWePle_H7D-dFmsXYTsEfcxs4zVjn0INUqJdX9Bg5Hc1sufHUIuJQdKPvTD4.svg	2026-05-29 07:09:27.282701+00	2026-05-29 07:11:07.927651+00	\N	2026-05-29 07:11:07.927651+00	0.00	0	0	f	\N	\N
1148	1350722339	BMB_2oz4	M	B	https://t.me/i/userpic/320/v6sD1Q3GF-yuh55IHjgxLLXD3lUujAoHK6AdYIlR2L8.svg	2026-05-29 07:13:46.072568+00	2026-05-29 07:50:17.724233+00	0101000020E6100000A09F4E1EBBE83C40D0E341C417224E40	2026-05-29 07:50:17.724233+00	0.00	0	0	f	\N	\N
1151	7635567971	rametrika	Julia Kuzmina	\N	https://t.me/i/userpic/320/wJGqLWz6H28yZozhC8j1-okcnUVGduA48W9kcQIfgy5RzP-88DIeonNVE7x_T84I.svg	2026-05-29 09:55:26.895104+00	2026-05-29 09:55:26.895104+00	\N	2026-05-29 09:55:26.895104+00	0.00	0	0	f	\N	\N
1152	321662169	deepindub	ᴅᴇᴇᴘɪ͢͢͢ɴᴅᴜʙ	\N	https://t.me/i/userpic/320/OrZJSh87loOMSjJmMWiU-gvj8O-OXIgkIffz38jy2zA.svg	2026-05-29 10:22:35.146542+00	2026-05-29 10:22:35.146542+00	\N	2026-05-29 10:22:35.146542+00	0.00	0	0	f	\N	\N
1156	1427146438	Rubikonda	Ruberto 🇷🇺	Hexian	https://t.me/i/userpic/320/VllVSiPwF67YasGSVhj53bN4evk8GUMUWivYF5q6Lcg.svg	2026-05-29 11:39:29.498142+00	2026-05-29 11:39:40.509846+00	\N	2026-05-29 11:39:40.509846+00	0.00	0	0	f	\N	\N
1158	1059724414	mamari_13	Мария	\N	https://t.me/i/userpic/320/GGyTmJQV1JhW_NN1AI2zpyuy-cuvPBp2HRzNx9UpBWA.svg	2026-05-29 11:47:41.938595+00	2026-05-29 11:47:41.938595+00	\N	2026-05-29 11:47:41.938595+00	0.00	0	0	f	\N	\N
1159	792945173	updias	Dias	\N	https://t.me/i/userpic/320/JkfTYxVFtPtST-_zMeNa21bfKhd8GBG-cbXsAm7iI9o.svg	2026-05-29 14:31:50.017873+00	2026-05-29 14:33:28.321885+00	0101000020E61000002120188DBC603F40C71EF6E9C50E4E40	2026-05-29 14:33:28.321885+00	0.00	0	0	f	\N	\N
1160	54793174	Vassap18	Vasiliy	Saparov	https://t.me/i/userpic/320/h-uwMR1zNsSD-nRq7en8pZr01EeLzll1GDO1ZPaE78M.svg	2026-05-29 15:04:27.410955+00	2026-05-29 15:04:27.410955+00	\N	2026-05-29 15:04:27.410955+00	0.00	0	0	f	\N	\N
1153	1026127941	Etoschyajesch	etosh	yajesch	https://t.me/i/userpic/320/Fm5eDqbI0YcaYYbpjAsPGWFvWr3NxljL04enckbpH5g.svg	2026-05-29 10:23:21.428109+00	2026-05-29 16:40:10.111471+00	\N	2026-05-29 16:40:10.111471+00	0.00	0	0	f	\N	\N
1162	444177457	\N	Stas Ber	\N	https://t.me/i/userpic/320/rJyGEFDuI-CoFDhMuRQsAlKPTyorf3e9hzyWGJ5pimk.svg	2026-05-29 18:09:54.720972+00	2026-05-29 20:36:35.957974+00	\N	2026-05-29 20:36:35.957974+00	0.00	0	0	f	\N	\N
1168	828822254	angell667	Ангелина	\N	https://t.me/i/userpic/320/oLL0sS65HlbvefoXZ0ySrIHZppuEv7Nfwk8e4B-HUHc.svg	2026-05-30 06:58:20.48108+00	2026-05-30 06:58:20.48108+00	\N	2026-05-30 06:58:20.48108+00	0.00	0	0	f	\N	\N
1002	313027787	Kley107	Николай Николаевич	\N	https://t.me/i/userpic/320/dceJQCisFcEJ4zLFYbCTUJGRdQ7wbuCe-J7j7VH6sxM.svg	2026-05-16 12:11:28.502288+00	2026-06-01 06:59:41.692881+00	\N	2026-06-01 06:59:41.692881+00	0.00	0	0	f	\N	\N
1084	2010336268	\N	Андрей	\N	https://t.me/i/userpic/320/j3uEZldpBiV5rbaXI4ZfeCSazqKtHIY422Vefws1z4s.svg	2026-05-20 14:39:13.135958+00	2026-06-25 15:34:42.767127+00	\N	2026-06-25 15:34:42.767127+00	0.00	0	0	f	\N	\N
1581	902640946	Lasos777	Ласось💩	\N	https://t.me/i/userpic/320/zcda75AELc0hgscGktv8u5pm1S3Cm_tp5Dp8gKbt8hk.svg	2026-07-02 08:23:55.486319+00	2026-07-02 08:24:25.214129+00	\N	2026-07-02 08:24:25.214129+00	0.00	0	0	f	\N	\N
1520	81614209	oDislaff	oDislaff	\N	https://t.me/i/userpic/320/WnweXl3R2izURc38NSW6S5ghtbJmwAryM7p3HuR5LNI.svg	2026-06-29 10:37:42.668967+00	2026-06-29 10:42:01.023925+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 10:42:01.023925+00	0.00	0	0	f	\N	\N
1527	1659954889	AnzhelaWs	AnzhelaWs	\N	https://t.me/i/userpic/320/yfmaV9_joQI1czEG1VsquLIgeoaeCOdb9BUWe_5Liaw.jpg	2026-06-29 16:37:28.049832+00	2026-06-29 16:37:28.049832+00	\N	2026-06-29 16:37:28.049832+00	0.00	0	0	f	\N	\N
1290	8577781893	ultio_contesto	John	Dow	https://t.me/i/userpic/320/p1MjV_btB7zUgOJ99xEDXqzCiOSjng6Zk0mFozuO25QzmBozBYf4dFK57X7W0MNi.svg	2026-06-11 09:59:10.819187+00	2026-06-30 14:28:28.669196+00	\N	2026-06-30 14:28:28.669196+00	0.00	0	0	f	\N	\N
1539	355604669	aka_amiga	Amiga	\N	https://t.me/i/userpic/320/V2WVEjh5igOl73kkW4AcyD71UVlcNdfotKoouwQdZX8.svg	2026-06-30 14:34:24.479455+00	2026-06-30 14:34:24.479455+00	\N	2026-06-30 14:34:24.479455+00	0.00	0	0	f	\N	\N
1009	1005442993	Alex_Korshunov	Alexey	Korshunov	https://t.me/i/userpic/320/DjAU5P3LJKIx4b81VoNGP7tb7WoZz96hCCI7vb-qavQ.svg	2026-05-16 12:47:29.489282+00	2026-06-24 10:22:44.506158+00	\N	2026-06-24 10:22:44.506158+00	0.00	0	0	f	\N	\N
1493	298027360	nvzankova	Nadin	\N	https://t.me/i/userpic/320/1wkJuI0Oqf3NrUZvATzF9swvSzbU80xauBJkd1L6U1c.svg	2026-06-27 11:03:39.535439+00	2026-06-27 11:07:29.003703+00	\N	2026-06-27 11:07:29.003703+00	0.00	0	0	f	\N	\N
1278	203178945	Oksssannna	Оксана	\N	https://t.me/i/userpic/320/FqF1Eq_MXzXDmu8j6gXFBgUu8zMQchdBtPyjRwOYlN4.svg	2026-06-08 20:21:17.420057+00	2026-06-08 20:21:17.420057+00	\N	2026-06-08 20:21:17.420057+00	0.00	0	0	f	\N	\N
1486	-4692812325232670791	PIVO	PIVO	\N	\N	2026-06-26 15:33:14.468402+00	2026-06-28 15:07:48.934859+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-28 15:07:48.934859+00	0.00	0	0	f	\N	\N
582	966311493	Psyxoz25	Александр	\N	https://t.me/i/userpic/320/1DuF_F5tPZr5tvZblqTkmep276Lv05AIezZ2rgYtmec.svg	2026-02-24 04:44:55.998844+00	2026-06-09 16:13:21.615077+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-09 16:13:21.615077+00	0.00	0	0	f	\N	\N
1221	430284107	SEKSONSKI	Seksonski	Anton Vozhd	https://t.me/i/userpic/320/ys4LXzTPhNPqCy6Jjs-Tss_BjdL0yae2r05Bj_BLTzg.svg	2026-06-03 18:53:00.53131+00	2026-06-03 18:53:00.53131+00	\N	2026-06-03 18:53:00.53131+00	0.00	0	0	f	\N	\N
1145	171475022	andreyollegovich	Andrey	Olegovich	https://t.me/i/userpic/320/-YdO6I7nxN7eFjOXju_ZVGjyO5r8NEK6IZx0ee3NqlM.svg	2026-05-29 05:11:35.243328+00	2026-06-09 21:13:35.144915+00	\N	2026-06-09 21:13:35.144915+00	0.00	0	0	f	\N	\N
1228	1151562105	Roman_Uretch	Роман	Пономарев	https://t.me/i/userpic/320/FKkFqpQfRm0gYy3xnZJtb0fcpoUEUm89cQ-vroE2VQM.svg	2026-06-04 10:35:35.141226+00	2026-06-04 10:35:35.141226+00	\N	2026-06-04 10:35:35.141226+00	0.00	0	0	f	\N	\N
606	310513187	Di_maa89	Di	Ma	https://t.me/i/userpic/320/NikbVjpGXC-hmNYVyBa6CzgIB9ea0pgQ8jYPOUY5E5c.svg	2026-02-27 13:27:54.058128+00	2026-06-04 14:41:26.411264+00	0101000020E61000000C9BA20381DE42402B2ED92E82D74B40	2026-06-04 14:41:26.411264+00	0.00	0	0	f	\N	\N
1231	231279646	ommery	Olya	M	https://t.me/i/userpic/320/8tIszXTmPQMvS3Gn9duLYLj_sDqq8CFGW71QKLK7z04.svg	2026-06-04 19:59:17.545626+00	2026-06-04 19:59:17.545626+00	\N	2026-06-04 19:59:17.545626+00	0.00	0	0	f	\N	\N
1233	5296608154	serokvel	Paul	\N	https://t.me/i/userpic/320/PsizPW5Aq_3rko5s_KPq8yT9Xg1lPUtu9vzv6BdpTtBC-iSw0Ejo1vXO8DU-On18.svg	2026-06-04 20:53:29.849888+00	2026-06-04 20:53:29.849888+00	\N	2026-06-04 20:53:29.849888+00	0.00	0	0	f	\N	\N
1288	353008860	AlexLubich	Alexandra	Lu	https://t.me/i/userpic/320/LsSDC79T-VkFZzujqpa1q6UKJFjID7LjN2dWkRtPUGs.svg	2026-06-11 07:47:01.216161+00	2026-06-11 07:47:01.216161+00	\N	2026-06-11 07:47:01.216161+00	0.00	0	0	f	\N	\N
1289	133454109	Shamovsky	Yuriy	Sh.	https://t.me/i/userpic/320/c-tbRNWTiQq0FcBSwozQpkKkITBMsO9nZYcAYeFrGAs.svg	2026-06-11 08:04:31.984708+00	2026-06-11 08:04:31.984708+00	\N	2026-06-11 08:04:31.984708+00	0.00	0	0	f	\N	\N
1235	788711900	tsygelskiy	Сергей	\N	https://t.me/i/userpic/320/GGTqSUrNN2PcNcm1jB3SvY7bpTrXkAMXzMl_re-ZjSs.svg	2026-06-04 23:06:50.277302+00	2026-06-04 23:10:55.158964+00	\N	2026-06-04 23:10:55.158964+00	0.00	0	0	f	\N	\N
1291	5254182023	TarantinoWild	TARANTINO	☯️	https://t.me/i/userpic/320/zU2RJmM24l5H1-ru-N2J687-sl8kE4SsPEJN5sevKZsPm4ZKY2BuCgLiMFFW7phi.svg	2026-06-11 12:02:10.620235+00	2026-06-11 12:02:10.620235+00	\N	2026-06-11 12:02:10.620235+00	0.00	0	0	f	\N	\N
1200	970662326	Krammadelia	Ольга	Крамм	https://t.me/i/userpic/320/waG-P2bEAYroo_Pzz16ag6HthAfi1H1uEI4eObg-Lrk.svg	2026-06-01 18:25:24.597325+00	2026-06-01 18:25:24.597325+00	\N	2026-06-01 18:25:24.597325+00	0.00	0	0	f	\N	\N
1293	611571967	Opiatv	PsySonka	\N	https://t.me/i/userpic/320/qUxVNb9rLzQxlRUvAn_tERAH53zQ-6ki8mgw-R4Cxvc.svg	2026-06-11 15:14:10.0751+00	2026-06-11 15:14:10.0751+00	\N	2026-06-11 15:14:10.0751+00	0.00	0	0	f	\N	\N
1190	8381306229	Alexandr10460	Александр	Т	https://t.me/i/userpic/320/cruKoeCF1x0hMsFqjTRRw7mj0a3VkVNU0P_hD6e0Xs-DsqV2QW5ryKonYreuhvy-.svg	2026-05-31 22:51:41.264203+00	2026-06-11 15:20:27.961426+00	\N	2026-06-11 15:20:27.961426+00	0.00	0	0	f	\N	\N
351	465046556	EasyEsther	Esther	\N	https://t.me/i/userpic/320/FW3eskv9b26LKskxw9jMzTXTGqzx-xnRgJEyaruu7Pg.svg	2026-02-16 08:39:09.300704+00	2026-06-29 03:17:07.434812+00	0101000020E61000002B6F4A0449EA4240062707E1ACE14B40	2026-06-29 03:17:07.434812+00	0.00	0	0	f	\N	\N
1287	1266184129	Pechnik_pios	Алексей	Савин	https://t.me/i/userpic/320/fpy3O19IgO8fMcMqniLFtFEfUp_lL_YorxsIrs7GOSg.svg	2026-06-11 03:45:21.77086+00	2026-06-23 05:10:51.810145+00	\N	2026-06-23 05:10:51.810145+00	0.00	0	100	f	\N	\N
1300	610854618	KIRRKKIRR	KI	\N	https://t.me/i/userpic/320/7J9rYRwQV708QgGTiqE5cHXXJ6So9ja-wPOl9TBbqAs.svg	2026-06-12 09:58:07.662106+00	2026-06-12 09:58:07.662106+00	\N	2026-06-12 09:58:07.662106+00	0.00	0	0	f	\N	\N
1286	5819025927	\N	Nickos	Nickopoulos	https://t.me/i/userpic/320/dkWfZ0qLfS_EXaHz8FtEFtEu12AD6KUE-F6vrcZfcvsggfXfmrJcYa1jCYipMrUK.svg	2026-06-10 22:33:46.327235+00	2026-06-14 00:47:26.430148+00	\N	2026-06-14 00:47:26.430148+00	0.00	0	0	f	\N	\N
1061	8751927381	Trumprussik	Trump	\N	https://t.me/i/userpic/320/lqq9ur8yJazdTsuHymbpfpfcTNM3JUwCSVp8f4R08PoLlhMGa3DG6paF2dTP88jp.svg	2026-05-19 05:24:59.615259+00	2026-06-05 21:44:06.777017+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-05 21:44:06.777017+00	0.00	0	0	f	\N	\N
1248	120343301	Lisaa_Karpova	Lisa	\N	https://t.me/i/userpic/320/d_7l-3kGl-POVhNhwi1FES5_xnbZGluyckzUyukGa4I.svg	2026-06-06 06:37:08.6761+00	2026-06-06 06:37:08.6761+00	\N	2026-06-06 06:37:08.6761+00	0.00	0	0	f	\N	\N
1249	1839383981	Qbitti	Richard	Marten .🐰	https://t.me/i/userpic/320/aXncZh7SWunU2rIZVfa2Z7gMQuTc8ov2tA_1Xm60nT8.svg	2026-06-06 07:43:13.143785+00	2026-06-06 07:43:13.143785+00	\N	2026-06-06 07:43:13.143785+00	0.00	0	0	f	\N	\N
1254	626309762	ivan_yuhin	Ivan	Yuhin	https://t.me/i/userpic/320/RLQTonyHbSe7d3MHXCtuNIFZ02IhiwSu2EPDlFgqbKY.svg	2026-06-06 16:11:13.998735+00	2026-06-06 16:45:53.49509+00	\N	2026-06-06 16:45:53.49509+00	0.00	0	0	f	\N	\N
1257	173996649	egor_nvm	Egor	\N	https://t.me/i/userpic/320/vT8cAe0XDHCR2-eZb_0YpGGOzA22_Rwc51xml7RNw7w.svg	2026-06-06 23:03:23.942048+00	2026-06-06 23:03:23.942048+00	\N	2026-06-06 23:03:23.942048+00	0.00	0	0	f	\N	\N
1259	362465858	katt_nest	Катерина	\N	https://t.me/i/userpic/320/OBkVex2CEqvPA2zLnEjX4MWbvLnDnUKqV4_7HOyOr2w.svg	2026-06-07 10:10:47.123151+00	2026-06-07 10:10:47.123151+00	\N	2026-06-07 10:10:47.123151+00	0.00	0	0	f	\N	\N
1262	654617972	nd141km	Sofia	\N	https://t.me/i/userpic/320/Vivoni7xRwLrX3u8IsoALOW41UCGm5Q99tOYbIlvHcY.svg	2026-06-07 16:11:56.102114+00	2026-06-07 16:24:06.497859+00	\N	2026-06-07 16:24:06.497859+00	0.00	0	0	f	\N	\N
1263	5820005239	Ilai_11	Ilai	\N	https://t.me/i/userpic/320/iPpOHcqPRue7WC21UDb94gD5zem66GcZT13gUleieK57_lrcpfbbO7bqpQnGqTsT.svg	2026-06-07 18:50:44.217047+00	2026-06-07 18:50:44.217047+00	\N	2026-06-07 18:50:44.217047+00	0.00	0	0	f	\N	\N
1304	-38367100	vk38367100	Виталий	Дудкин	https://sun1-18.vkuserphoto.ru/s/v1/ig2/sxjTsJcjv2NhQORTUsecKa13ZWgvw9zdo2j-w9aECWWSsJil9xql-esqkvtiUSXmbs2arF8SOZ4-pwQoaeA0_XN_.jpg?quality=95&crop=428,219,997,997&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720&ava=1&cs=50x50	2026-06-14 18:25:33.744377+00	2026-06-14 18:25:36.487492+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-14 18:25:36.487492+00	0.00	0	0	f	\N	\N
250	205150026	YXAHBEPTYXAH	YXAN	BEPTYXAH	https://t.me/i/userpic/320/sMwN_yux0ArnpiVs6ZpK-1NwIv95W6V-vb-uAxkzqww.svg	2026-02-14 13:29:59.433944+00	2026-06-26 09:54:19.36452+00	\N	2026-06-26 09:54:19.36452+00	0.00	0	0	f	\N	\N
1062	197663153	Tatapsy	Tatiana	Vanaeva	https://t.me/i/userpic/320/CtAUeJLPVdl4IKiLSp5X_mRgz7aCRylbUSvMXRlBznU.svg	2026-05-19 07:52:47.883085+00	2026-06-23 17:20:34.319602+00	\N	2026-06-23 17:20:34.319602+00	0.00	0	0	f	\N	\N
1412	481480832	\N	Svetlana	Gudkevich	https://t.me/i/userpic/320/ut8iEGZ2TQ3vYHe81_3oPBTPKivKQY8NLQLuiqFmsvs.svg	2026-06-22 14:57:17.233421+00	2026-06-27 12:17:29.664407+00	\N	2026-06-27 12:17:29.664407+00	0.00	0	0	f	\N	\N
1360	1355702468	\N	Татьяна	\N	https://t.me/i/userpic/320/tBqD1j2otsw-EUJzrNFQLIrcIUW3LgGpdr4kdfmxeuk.svg	2026-06-18 16:30:56.773176+00	2026-06-18 16:58:38.542076+00	\N	2026-06-18 16:58:38.542076+00	0.00	0	100	f	\N	\N
1361	1255224764	AmSorryNA	Марина	\N	https://t.me/i/userpic/320/EeCqYTgarTihSNGTOPU_GF4tbWLusUVjzG0jG-F94qQ.svg	2026-06-18 16:47:02.964325+00	2026-06-18 17:27:26.37912+00	\N	2026-06-18 17:27:26.37912+00	0.00	0	100	f	\N	\N
412	-535709298	vk535709298	Space	Main	https://sun1-30.vkuserphoto.ru/s/v1/ig2/xMeeN4OG2_adyYaL-ZnD2PpCairFnRLqMp2SxT7auL7e-lCZerAzZm4F1YaEXWEAcc43TGaC1dLJG7Z-khMirLQq.jpg?quality=95&crop=378,92,598,598&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540&ava=1&cs=50x50	2026-02-19 16:32:25.980523+00	2026-06-24 04:43:22.890397+00	0101000020E6100000BD6CF4FF6452474014A3FBFF59304B40	2026-06-24 04:43:22.890397+00	0.00	0	0	f	\N	\N
1370	195318109	axxelerator	Axxel	\N	https://t.me/i/userpic/320/pTH6gbA6OZRMaO7I4oPqK1SfVvGH60LPwFMuIUu4wlI.svg	2026-06-19 07:24:15.401333+00	2026-06-19 08:53:18.961281+00	\N	2026-06-19 08:53:18.961281+00	0.00	0	0	f	\N	\N
1495	6914948840	peacedataaa	DT	\N	https://t.me/i/userpic/320/5wF7l6YaJwykhKy5DfdAhnUCpPyeEYboD7IzhCKCerFEijbyDYHRfz3Bzfp2Yv18.svg	2026-06-27 12:49:49.820545+00	2026-06-27 12:49:49.820545+00	\N	2026-06-27 12:49:49.820545+00	0.00	0	0	f	\N	\N
382	451713544	OlegNegrov	Oleg	Negrov	https://t.me/i/userpic/320/DSVw24LsF-PJB-5fSHtrOmRghXOK2ZBYyaV00md9c3w.svg	2026-02-18 06:41:33.713366+00	2026-06-27 20:10:06.843209+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-27 20:10:06.843209+00	0.00	0	0	f	\N	\N
1202	278078401	mrNice_666	Ivan	Kaminskii	https://t.me/i/userpic/320/48C8M_OLvsXwv1i95j4X4bEDfZkTMyssZ5VmhlkEL9Y.svg	2026-06-02 08:25:44.885718+00	2026-06-29 03:58:33.669947+00	0101000020E61000001ACABE5214493F40A645F056B20D4E40	2026-06-29 03:58:33.669947+00	0.00	0	0	f	\N	\N
1432	-298674	vk298674	Александр	Сергеевич	https://sun9-21.vkuserphoto.ru/s/v1/ig1/jtBaZwUT07hpc6Hcx47cGaj4_oy6oUuLjbj53zm5fR7yNjH_Ef69MDWMYMAuCzhnzXnfQ9Mb.jpg?quality=96&crop=167,316,454,454&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360&ava=1&cs=50x50	2026-06-24 07:42:52.410418+00	2026-06-24 07:42:52.410418+00	\N	2026-06-24 07:42:52.410418+00	0.00	0	0	f	\N	\N
1437	1927094462	sergey_vwbus	Сергей	\N	https://t.me/i/userpic/320/cdtfWAnEWcpMmQBzB1Skd9IgGobe_Lpb9Z0xDC9qAuE.svg	2026-06-24 11:34:04.849392+00	2026-06-24 12:04:02.677373+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-24 12:04:02.677373+00	0.00	0	0	f	\N	\N
215	321771876	NataliaOhdooddi	Natalia	\N	https://t.me/i/userpic/320/K3-hpNTOm_urCIolZbvkIT-mjYKSlB-rPUMOGeZjdKU.svg	2026-02-14 12:08:11.507493+00	2026-06-19 22:10:59.541282+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-05-16 18:21:44.826972+00	0.00	0	1200	f	\N	\N
1385	1091715138	Katriniti108	Katriniti	\N	https://t.me/i/userpic/320/Lj4QI_kG9XTho8zxvyJAMPvwhklCYyEIj5le62bJnhg.svg	2026-06-19 22:10:59.275592+00	2026-06-19 22:10:59.541282+00	\N	2026-06-19 22:10:59.275592+00	0.00	0	100	f	\N	\N
369	813852364	tupurucha	Lena K.	\N	https://t.me/i/userpic/320/1s6sYyhSfmC8YlTrW-_jiSNrISN1Gdb1p0QqqKcKNnw.svg	2026-02-17 07:54:51.947057+00	2026-06-24 14:26:12.232457+00	0101000020E61000004CB4155EB6D64240593095395CE24B40	2026-06-24 14:26:12.232457+00	0.00	0	0	f	\N	\N
975	864432398	\N	дмитрий	\N	https://t.me/i/userpic/320/cLliT_z0Iq4QNCt_E8YEdx0F3yeuwYfhYBqtALpZkys.svg	2026-05-13 12:27:58.635238+00	2026-06-20 09:03:49.435182+00	0101000020E61000005CEFED4C57CB4240E1021AB677F44B40	2026-06-20 09:03:49.435182+00	0.00	0	0	f	\N	\N
1392	594208854	MargoSever	СеверМарго	\N	https://t.me/i/userpic/320/PCl0ECAHhwTUNpu_CYOUIhiXboyL5xmHow2beKAqd6Y.svg	2026-06-20 10:29:01.618947+00	2026-06-20 10:29:01.618947+00	\N	2026-06-20 10:29:01.618947+00	0.00	0	0	f	\N	\N
1397	1105370747	pavelsvod	🐲	🏴‍☠️	https://t.me/i/userpic/320/ct9Dm6eU3WGPwRqaM1umyIve7bd2si_AXYFOF084TrU.svg	2026-06-20 22:21:02.637521+00	2026-06-20 22:21:02.637521+00	\N	2026-06-20 22:21:02.637521+00	0.00	0	0	f	\N	\N
1450	458893487	kriss_68_rus	Кристина	Гульева	https://t.me/i/userpic/320/TaF0853LpgHIdHt7Qh-HX1tHoK1fzYVwtsESj4o4DLY.svg	2026-06-24 18:34:07.875331+00	2026-06-29 11:16:40.151972+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 11:16:40.151972+00	0.00	0	0	f	\N	\N
1409	737615451	krasavelladj	Александр	Krasavella	https://t.me/i/userpic/320/J-Es7ey03Zx8bSHYHNd6R1NC5NpF_JRdAijKo--c6Ug.svg	2026-06-22 08:16:58.743282+00	2026-06-22 08:16:58.743282+00	\N	2026-06-22 08:16:58.743282+00	0.00	0	0	f	\N	\N
1383	1958754600	Thesamurai666	Mark	Alexsandrowitch	https://t.me/i/userpic/320/mgHH_pCaL5k-PMjFezHEUmfM8BZcMtn_TUxW_hJaPSA.svg	2026-06-19 19:15:30.759472+00	2026-06-30 14:29:38.197965+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 14:29:38.197965+00	0.00	0	0	f	\N	\N
1125	844175503	TMN_Rodion_Papizh	rodjon	\N	https://t.me/i/userpic/320/R2abVmJedlN66nRMfyM9aqoCJwgFvhTfuJhqYWHpVRA.svg	2026-05-26 06:53:03.407887+00	2026-06-23 09:00:56.907774+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-23 09:00:56.907774+00	0.00	0	0	f	\N	\N
1431	-709817457	vk709817457	Степан	Григорян	https://sun1-21.vkuserphoto.ru/s/v1/ig2/rV94qQhOxfz1sz7ugXub8oD3ThDDz5Ut_nsaD7maKZQ8HzJQs9l1O1Q4XhUPXvbWx_vTlEOakZs37bK86C5VJDje.jpg?quality=95&crop=548,417,959,959&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720&ava=1&cs=50x50	2026-06-24 07:01:10.932011+00	2026-06-25 02:47:28.535137+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-25 02:47:28.535137+00	0.00	0	0	f	\N	\N
1453	318306316	PsyCook	Павел	Корзин🌞	https://t.me/i/userpic/320/lGziQlC2rw-IXv2HWpeBdShMF1kTlPGF8TDTgFQT93k.svg	2026-06-25 04:40:03.271637+00	2026-06-25 04:40:22.133302+00	\N	2026-06-25 04:40:22.133302+00	0.00	0	0	f	\N	\N
1456	345002812	Madlen_ph	Alena	\N	https://t.me/i/userpic/320/pBceV7S9RiFUSvgV6h5vxMUyXSsez5x0a0V7shZUnB0.svg	2026-06-25 07:56:46.18059+00	2026-06-25 07:56:46.18059+00	\N	2026-06-25 07:56:46.18059+00	0.00	0	0	f	\N	\N
782	136485518	baby_kills_bambi	Olga	A.	https://t.me/i/userpic/320/UA40JZnqEo9lpVUtPMLRZ-XpFrHL0Aglr40OdBsOTxQ.svg	2026-03-10 11:12:53.683141+00	2026-06-25 12:35:55.09472+00	0101000020E61000002B89341D0DCE4240D528EC5749E04B40	2026-06-25 12:35:55.09472+00	0.00	0	0	f	\N	\N
1461	-650179	vk650179	Илья	Фещук	https://sun9-68.vkuserphoto.ru/s/v1/ig2/Ixzw0OTCfaH52anl-oGDcDIbBNJjg-X9mBIBbCmwiiP7tFqHZ-7Rx0HrNIy79f0ve0wooToS2FJOpaE0KEftFwex.jpg?quality=95&crop=8,259,1027,1027&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720&ava=1&cs=50x50	2026-06-25 14:30:33.941429+00	2026-06-25 14:31:19.848227+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-25 14:31:19.848227+00	0.00	0	0	f	\N	\N
1411	169004123	timofeyp	Timofey	\N	https://t.me/i/userpic/320/BJJdE6YkPB6KqZiDTZ70_BZ3l6FiHt6JE17F4Qm3PRk.svg	2026-06-22 13:59:37.666279+00	2026-06-23 11:00:17.990261+00	\N	2026-06-23 11:00:17.990261+00	0.00	0	0	f	\N	\N
1330	133103180	Eclipse_black_san	Juli Ju	\N	https://t.me/i/userpic/320/cn5YejP9fSTQrZc4L902BoE6svIBtmU_dOFe9sDEU9g.svg	2026-06-16 20:22:00.21031+00	2026-06-26 05:57:30.175551+00	\N	2026-06-26 05:57:30.175551+00	0.00	0	0	f	\N	\N
1340	5224016514	\N	Вероника	\N	https://t.me/i/userpic/320/AOqXLk2zcr6vrvGVYjOPKv9SWA8FtTtpgSdWS8Eqgly_Mpt_tXzjXFAHgDDIc7jw.svg	2026-06-17 05:12:38.748906+00	2026-06-17 13:47:54.575703+00	\N	2026-06-17 13:47:54.575703+00	0.00	0	0	f	\N	\N
384	6585734125	dook108	dook	\N	https://t.me/i/userpic/320/OKRl4_JSudUpuQ7N7FeCClBVzZGKt5fbNAOWxgfM7aBolZfUbjLTS8ezriwvYn78.svg	2026-02-18 08:41:43.330378+00	2026-06-18 03:26:18.259359+00	\N	2026-06-18 03:26:18.259359+00	0.00	0	0	f	\N	\N
1308	743244671	ole9ku	Олег К	\N	https://t.me/i/userpic/320/_af6mX-iif1hAo-xC5mSxHa3mLrvavwbfXT8ssW_ArM.svg	2026-06-15 14:10:39.597395+00	2026-06-15 14:10:39.597395+00	\N	2026-06-15 14:10:39.597395+00	0.00	0	0	f	\N	\N
1364	388674603	pure_adventure	Danechka	\N	https://t.me/i/userpic/320/saE6UfmVejzGoIpLqFhL3rqXkNKgGGJ2590jZAEhm8Q.svg	2026-06-18 17:21:38.114962+00	2026-06-18 17:21:38.114962+00	\N	2026-06-18 17:21:38.114962+00	0.00	0	0	f	\N	\N
1315	861694780	Katerina_Korrs	Katerina	\N	https://t.me/i/userpic/320/5XPHsZn_1VaPZLLWZwW88QI5ezDYVayz6qII09dPHBg.svg	2026-06-16 18:51:30.979263+00	2026-06-29 13:10:40.59746+00	\N	2026-06-29 13:10:40.59746+00	0.00	0	0	f	\N	\N
1376	266468916	Om_NamoNarayanaya	Добрый	Молодец	https://t.me/i/userpic/320/W0QQqp1I9UKn-H3fPaNlksrRTAJPpZEOJ2XEX89n7uE.svg	2026-06-19 10:25:34.151846+00	2026-06-19 10:25:34.151846+00	\N	2026-06-19 10:25:34.151846+00	0.00	0	0	f	\N	\N
1312	242789656	asalkhanova_psy	Александра	Асалханова	https://t.me/i/userpic/320/QDXZjYjPkFk5l0Wz_ZtnVYuJNYjFMyDB_wGfdvGUl8k.svg	2026-06-15 21:57:43.976306+00	2026-06-15 21:57:43.976306+00	\N	2026-06-15 21:57:43.976306+00	0.00	0	0	f	\N	\N
1309	6061270816	OG_slk	Ser	\N	https://t.me/i/userpic/320/mBH-W9LQcpvwl41DnAUyEauzSq97-TeBeGp4eRpCRTayvayxLIuFNmPL1PC_-g4T.jpg	2026-06-15 14:32:49.367365+00	2026-06-16 13:32:13.759318+00	\N	2026-06-16 13:32:13.759318+00	0.00	0	0	f	\N	\N
1314	206638471	dj_luba	Luba	Schneider	https://t.me/i/userpic/320/Xb3eswzcIwUcKvWOJOIPJSF-o43iBt5deMdo7_SnTXo.svg	2026-06-16 16:56:47.399083+00	2026-06-16 16:56:47.399083+00	\N	2026-06-16 16:56:47.399083+00	0.00	0	0	f	\N	\N
1346	430944420	ansti2	A🌘✨🌒	\N	https://t.me/i/userpic/320/y73cpd8_BAd5kGNQHrDsP_w-TswhuY5dQKReP2bR9JI.svg	2026-06-17 09:01:34.02797+00	2026-07-02 06:11:42.371151+00	\N	2026-07-02 06:11:42.371151+00	0.00	0	0	f	\N	\N
1318	1485901976	leaflift	Leaf	Lift	https://t.me/i/userpic/320/qFofBNRMQ1VuVCmMHpN6BzmHNpWa-0M890Vq8DgU-FI.svg	2026-06-16 19:54:12.71457+00	2026-06-16 19:54:12.71457+00	\N	2026-06-16 19:54:12.71457+00	0.00	0	0	f	\N	\N
1319	126617386	Evgeniy_V_Mukhin	🇷🇺 ᴇᴠɢᴇɴɪʏ	ᴍᴜᴋʜɪɴ	https://t.me/i/userpic/320/XYQhBazQRSytZpfS81DFeCTGNr_rFez4xFEWl6OxuN0.svg	2026-06-16 19:55:21.808208+00	2026-06-16 19:55:21.808208+00	\N	2026-06-16 19:55:21.808208+00	0.00	0	0	f	\N	\N
1323	1034320898	Avemaugli	avemaugli	\N	https://t.me/i/userpic/320/tvaB94VWA5aVYzzlhP6JSvivibd-L28jTVMa6U-wt8M.svg	2026-06-16 20:03:09.568245+00	2026-06-16 20:03:09.568245+00	\N	2026-06-16 20:03:09.568245+00	0.00	0	0	f	\N	\N
1307	633843569	SvatoslavKozlov	Sviatoslav Kozlov	\N	https://t.me/i/userpic/320/UuxCsEuRw5akX-y8AcZ8GkG7G66Dq2v-MLjfCMM_XJI.svg	2026-06-15 13:14:06.938075+00	2026-06-16 20:09:09.225673+00	\N	2026-06-16 20:09:09.225673+00	0.00	0	0	f	\N	\N
315	780600864	nazaregolosazovytmenya	sekira♡	\N	https://t.me/i/userpic/320/KBd3gMIYZIJe3-twAyXQW2S3NO08xQPezhAr1Mn3dJ4.svg	2026-02-15 03:00:12.914079+00	2026-06-16 20:26:53.101875+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-16 20:26:53.101875+00	0.00	0	0	f	\N	\N
1332	440383527	katshalygina	Ekaterina	Shalygina	https://t.me/i/userpic/320/G3-pxUinfiQe1fMKrYXBCJFB9egChovGlfLqVzULwQ0.svg	2026-06-16 20:43:11.37983+00	2026-06-16 20:43:11.37983+00	\N	2026-06-16 20:43:11.37983+00	0.00	0	0	f	\N	\N
1335	547209564	FunkyYanki	Yana	Almazova	https://t.me/i/userpic/320/xcVzhb5-bkk-WPssHuNZgcQuNKpQgESv4nP_7A3t_vA.svg	2026-06-16 21:06:55.556974+00	2026-06-16 21:06:55.556974+00	\N	2026-06-16 21:06:55.556974+00	0.00	0	0	f	\N	\N
1336	972999125	Alena_Fedorova_artist	Alena	Fedorova	https://t.me/i/userpic/320/JWKKZpZZ36EvW0tfjHTJSGw2VktnYadGuqsbsW60Di4.svg	2026-06-16 21:33:17.481568+00	2026-06-16 21:33:17.481568+00	\N	2026-06-16 21:33:17.481568+00	0.00	0	0	f	\N	\N
1337	409172	koto_kit	Oleg	\N	https://t.me/i/userpic/320/pETVidCYRkVxqX0Sg13NnGYDadQo0lZN0kyOUy-0phw.svg	2026-06-16 21:46:33.020943+00	2026-06-16 21:46:33.020943+00	\N	2026-06-16 21:46:33.020943+00	0.00	0	0	f	\N	\N
1381	299216207	natt_bad	Наталия	Бадосова	https://t.me/i/userpic/320/YxG9rfne0aMIy6Yi7vmTwN_GU2cf3oiiZrdp1LwcZuo.svg	2026-06-19 18:04:39.958392+00	2026-06-19 18:04:39.958392+00	\N	2026-06-19 18:04:39.958392+00	0.00	0	0	f	\N	\N
1342	50503924	loverushappy	Ruslan	Love	https://t.me/i/userpic/320/3xv9k1EmrRvsk7mK-2m5SIyJTxdiJoHLVDawQuB6soI.svg	2026-06-17 05:45:30.1514+00	2026-06-17 05:45:30.1514+00	\N	2026-06-17 05:45:30.1514+00	0.00	0	0	f	\N	\N
1344	458326502	eeeirene8	Ira	M	https://t.me/i/userpic/320/AGsnD7UtQL5cwZaQKVAYR0wP-r4vRxh7UkfiX-fiB04.svg	2026-06-17 06:03:50.945544+00	2026-06-17 06:03:50.945544+00	\N	2026-06-17 06:03:50.945544+00	0.00	0	0	f	\N	\N
1345	190019157	Biomonster	Dmitry	\N	https://t.me/i/userpic/320/TxW1UUXbFGu-YDYfgeUiwLWbi62vF4BVqTN3XePaQIs.svg	2026-06-17 08:34:30.170775+00	2026-06-17 08:38:16.383404+00	\N	2026-06-17 08:38:16.383404+00	0.00	0	0	f	\N	\N
1384	8252525586	bremenskij	BRÈMÈNSKIJ	\N	https://t.me/i/userpic/320/_7P1a84KmiWQJqo3FVzWnWDALpFc9yqKrFSaM2W3gACvwjgbRms9DLnl_CP7rafF.svg	2026-06-19 21:54:08.113317+00	2026-06-19 22:49:36.110767+00	0101000020E6100000F6D1A92B9F433E403E80A03770F14D40	2026-06-19 22:49:36.110767+00	0.00	0	0	f	\N	\N
296	497323550	Koshmarider	Пампампарампам	\N	https://t.me/i/userpic/320/gYcu7RIiH-g4hAWdHHteUALJJqz_IruVqMVZLOcn26I.svg	2026-02-14 16:53:12.619546+00	2026-06-20 08:20:44.565702+00	\N	2026-06-20 08:20:44.565702+00	0.00	0	0	f	\N	\N
1393	553648539	caxarokkkGG	caxarokkk	\N	https://t.me/i/userpic/320/34xmqvNKompgS6sdn0ww6PNw8iw-1Nk-UexVK3dcesM.svg	2026-06-20 16:09:28.204883+00	2026-06-20 16:26:19.472419+00	0101000020E610000044985941669B4840827957F803E94B40	2026-06-20 16:26:19.472419+00	0.00	0	0	f	\N	\N
1305	148062	SyrKot	Kostian	Kostyansky	https://t.me/i/userpic/320/2Lpmcd-xi2EiuipwKoHNMqEo2dhAtD5BKdpOvBxLaY4.svg	2026-06-14 21:20:07.497529+00	2026-06-20 21:31:48.646847+00	\N	2026-06-20 21:31:48.646847+00	0.00	0	0	f	\N	\N
1398	834255003	ArturTropinkin	Green Man	\N	https://t.me/i/userpic/320/_wSQSgZuest-exmvlsCIJsjYKJ0a-DfdTRPftZy38QA.svg	2026-06-21 02:04:02.498543+00	2026-06-21 02:06:16.63819+00	\N	2026-06-21 02:06:16.63819+00	0.00	0	0	f	\N	\N
1399	400989119	beh1gh	andrew s.	\N	https://t.me/i/userpic/320/wG0JQ3UWhyuwVjYoRGNAymFzo_0ItWS9L3Lv1_tp-L8.svg	2026-06-21 06:21:33.017158+00	2026-06-22 02:43:36.674432+00	\N	2026-06-22 02:43:36.674432+00	0.00	0	0	f	\N	\N
1371	412143865	tripping_bear	Рита	\N	https://t.me/i/userpic/320/KhlmqirKIhxOcGa6UTgvIQc5qMa9DIjzzQThIqdkY5s.svg	2026-06-19 08:51:54.909321+00	2026-06-22 06:09:38.122879+00	\N	2026-06-22 06:09:38.122879+00	0.00	0	0	f	\N	\N
1404	297196492	Frenchmilkshake	Marina	Likhacheva	https://t.me/i/userpic/320/ZHOV2gUoCtXVkjZtl2yXo6XBWdVWpVMpzzmCLe6Os-o.svg	2026-06-22 07:12:32.613447+00	2026-06-22 07:12:32.613447+00	\N	2026-06-22 07:12:32.613447+00	0.00	0	0	f	\N	\N
1316	125449513	\N	Kumiko	Sengo	https://t.me/i/userpic/320/vRGycnoLDxBFn7H8I20MKUgaywrilP9UAC-u98dnTWQ.svg	2026-06-16 19:46:49.110315+00	2026-06-22 07:20:01.725064+00	\N	2026-06-22 07:20:01.725064+00	0.00	0	0	f	\N	\N
2	476021753	ggEff	Egor	Galaev	https://t.me/i/userpic/320/34L_QBqR4x3XOHeMHLX8BsWQpOX7_TukH8dMtCRzeOo.svg	2026-02-09 09:19:05.106467+00	2026-06-28 18:09:34.711912+00	0101000020E610000069E9DA3B645247407E4C9CBC5A304B40	2026-06-28 18:09:34.711912+00	0.00	0	100	f	\N	\N
1406	-1817613	vk1817613	Саша	Сафронова	https://sun1-27.vkuserphoto.ru/s/v1/ig1/n-tO6wsr98ldXEQxXaKN4XvlXxZ2kWtoi5oPIAjMVLS4nzxIshY_nxC4zHVJFv-jeYYnG5D7.jpg?quality=96&crop=0,178,510,510&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480&ava=1&cs=50x50	2026-06-22 07:25:42.028208+00	2026-06-22 08:26:31.064484+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-22 08:26:31.064484+00	0.00	0	0	f	\N	\N
1511	1030962280	\N	Ыыы	\N	https://t.me/i/userpic/320/bmxm2rdmPvc0LEJR8BjmS_JEPZW8aVqAXq4SBhYhlsk.svg	2026-06-29 05:52:13.227505+00	2026-06-29 05:52:13.227505+00	\N	2026-06-29 05:52:13.227505+00	0.00	0	0	f	\N	\N
1512	518982999	alex_mamaev72	Алексей	Мамаев	https://t.me/i/userpic/320/zNvD5lZ9Azr3_pf6zsF76lxYSTrI6vdwJH6RN1A4oP4.svg	2026-06-29 06:14:18.888708+00	2026-06-29 06:14:18.888708+00	\N	2026-06-29 06:14:18.888708+00	0.00	0	0	f	\N	\N
1514	-7561713	vk7561713	Кристина	Гульева	https://sun1-24.vkuserphoto.ru/s/v1/ig2/_s4SfaY40jSDQpDE1uxL8x-Q0CBwfLpix8JnTAKNvO6ssNS6bjqtFxTLA4-Rh0Um7qKtfMmRB8oIuhjWHQ1CVB0m.jpg?quality=95&crop=4,388,1703,1703&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720,1080x1080,1280x1280,1440x1440&ava=1&cs=50x50	2026-06-29 07:13:37.996712+00	2026-06-29 07:15:10.963769+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 07:15:10.963769+00	0.00	0	0	f	\N	\N
1515	1978259843	\N	Владимир	Bob	https://t.me/i/userpic/320/fxh4bXqzinImlVoleafek8zBCZvrfQ5BXIdR31tF3iE.svg	2026-06-29 07:24:16.086166+00	2026-06-29 07:24:16.086166+00	\N	2026-06-29 07:24:16.086166+00	0.00	0	0	f	\N	\N
1518	142988617	zenkrat	Zenkratov	\N	https://t.me/i/userpic/320/mF8Kbd-VjYB87-0gXcvnA3umy8c92GsiM6C6B_PFAiQ.svg	2026-06-29 07:55:13.606151+00	2026-06-29 07:55:13.606151+00	\N	2026-06-29 07:55:13.606151+00	0.00	0	0	f	\N	\N
956	546657879	stanislavfedorchuk	Stanislav	\N	https://t.me/i/userpic/320/HqU1ONfHDiLjUmTKk5fd6aN-nAKwzYtSWDha3-vOemM.svg	2026-05-11 15:01:37.867513+00	2026-06-29 12:15:32.514857+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 12:15:32.514857+00	0.00	0	100	f	\N	\N
1519	513732504	Evgesha_604	April cat	\N	https://t.me/i/userpic/320/lYcN3QFKFSw92CHxtS9lkjNBnV-auMfRqigY2--RtB8.svg	2026-06-29 09:05:36.873529+00	2026-06-29 09:23:07.44184+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 09:23:07.44184+00	0.00	0	0	f	\N	\N
1226	1187694359	galaumerenkova	Галина	Умеренкова	https://t.me/i/userpic/320/yaUCdOxQzGveWfUT2ETOD-6-fpLLZx8LL72JDDdH7SA.svg	2026-06-04 08:46:10.585227+00	2026-06-29 12:46:53.41242+00	\N	2026-06-29 12:46:53.41242+00	0.00	0	0	f	\N	\N
1528	1054702841	Anastasiaa2728	Анастасия	\N	https://t.me/i/userpic/320/d9EReH8HaUo5ALaw5_lDquDCwFvQcjmD4WjdJwAtvkU.svg	2026-06-29 17:25:11.658776+00	2026-06-29 17:25:12.808138+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-29 17:25:12.808138+00	0.00	0	0	f	\N	\N
3	902324493	HeresCo	HeresCo	Service	https://t.me/i/userpic/320/OAcZqn_I7YIotKdeM31agjOFApkN3yCbip69GFjQrII.jpg	2026-02-09 09:59:39.573925+00	2026-06-29 19:00:25.745919+00	0101000020E6100000AF9221206552474078F6DFFF59304B40	2026-06-29 19:00:25.745919+00	0.00	0	200	f	\N	\N
1531	479244500	klean88	Каляка	Klein	https://t.me/i/userpic/320/gLzn0jLm62jOXG7o-i6V2yB3RdbZuLI80JBwYH9PSOs.svg	2026-06-30 05:11:09.236676+00	2026-06-30 05:11:10.907316+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 05:11:10.907316+00	0.00	0	0	f	\N	\N
1526	177900395	rodriguez_sbg	Rodion	Rodriguez	https://t.me/i/userpic/320/tjzXH9rdv-blWmnoxCK3ZghtfT3hLMGx5Dq0nP69DcU.svg	2026-06-29 13:20:20.328709+00	2026-07-02 16:48:15.76794+00	0101000020E6100000B3EA73B5155B3E404703780B24F84D40	2026-07-02 16:48:15.76794+00	0.00	0	0	f	\N	\N
1532	8063688141	Mrakto	Hanzik	\N	https://t.me/i/userpic/320/W7bxHpjUC5Q0VISolfrpFglBeUsDJp5mx7COhk6SiUhj_qgLdUZ0YCAX4QCVRrHg.svg	2026-06-30 05:45:08.297585+00	2026-06-30 05:45:15.471706+00	0101000020E6100000217F1FC484DD42402EA4688AA5CB4B40	2026-06-30 05:45:15.471706+00	0.00	0	0	f	\N	\N
1541	-31617627	vk31617627	Хасан	Смирнов	https://sun9-37.vkuserphoto.ru/s/v1/ig2/0n1JBldYgQ_OBsU1d8TlXH6rKTbke-D9O7liUhOp7Isd2ceasFe1zYHlHph778UHn9Ba_ZVLEzDiyglBGFB9uH64.jpg?quality=96&crop=49,0,200,200&as=32x32,48x48,72x72,108x108,160x160&ava=1&cs=50x50	2026-06-30 17:28:43.407759+00	2026-06-30 17:30:44.058857+00	0101000020E6100000A2E708CAFC573E40193DD229A0F84D40	2026-06-30 17:30:44.058857+00	0.00	0	0	f	\N	\N
1542	222088473	lalinok_li	Li	\N	https://t.me/i/userpic/320/F1GjuBDtshnPsK-a1l0pwlikKo9XyYtwiGuFnk8P7o8.svg	2026-06-30 19:19:49.681006+00	2026-06-30 19:19:55.078438+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 19:19:55.078438+00	0.00	0	0	f	\N	\N
731	7006078558	Shamless420	MiR	DobRo	https://t.me/i/userpic/320/RoPuVz9qX_Es6-fMxyCSRVggzf-lknuJz2jTsy3CyF1YnDHgdB5YPhI6-kL_XIma.svg	2026-03-07 14:51:31.555915+00	2026-06-30 20:34:50.967705+00	\N	2026-06-30 20:34:50.967705+00	0.00	0	0	f	\N	\N
1544	520208648	\N	Mr.	Hedgehog	https://t.me/i/userpic/320/1u1ieihF3SihrkdX0LxKLze3bEIq2Yuzy7fkVsu6ORk.svg	2026-06-30 20:46:38.401052+00	2026-06-30 20:46:43.52293+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 20:46:43.52293+00	0.00	0	0	f	\N	\N
1545	8422417063	anton7mit	Anton	\N	https://t.me/i/userpic/320/gZ62RXR3W-gbTvTQ_G0xdJ5AE6SJVItkxs1z3aZRizFO-W0fjPrpmQmaakHCATAB.svg	2026-06-30 21:21:56.431483+00	2026-06-30 21:21:56.431483+00	\N	2026-06-30 21:21:56.431483+00	0.00	0	0	f	\N	\N
1547	-4571351	vk4571351	Денис	Меньшиков	https://sun1-25.vkuserphoto.ru/s/v1/ig2/Qw6iuzmEGbio38V6AZP8alSV9wTftYSD5tOAMXLW8xlLcpm3ppy7FM-8XNhv7D0tQACkUHRq7Uu5yon2fYxBT1sW.jpg?quality=95&crop=1,206,959,959&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720&ava=1&cs=50x50	2026-06-30 21:48:28.825942+00	2026-06-30 21:48:45.489435+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-06-30 21:48:45.489435+00	0.00	0	0	f	\N	\N
1546	-841819336	vk841819336	Dmitriy	Beliy	https://sun1-56.vkuserphoto.ru/s/v1/ig2/2XR2wvCHi3-toTESaPI2AENHqywe-1a1qIv28BdHJ13VWZoZFMDw6D1cgT-gGS3q9TH8b9b7OvM0Ub3KXMAZNnW-.jpg?quality=95&crop=392,772,1163,1163&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720,1080x1080&ava=1&cs=50x50	2026-06-30 21:34:49.132447+00	2026-07-01 04:22:40.240351+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 04:22:40.240351+00	0.00	0	0	f	\N	\N
1550	1278765183	mfriida	Farida 🦋	\N	https://t.me/i/userpic/320/v6tQ1RwoXyimUl1Yxr0eqP1haOfajB9hQcIZgRBFBRo.svg	2026-07-01 06:37:59.246805+00	2026-07-01 06:38:03.100973+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 06:38:03.100973+00	0.00	0	0	f	\N	\N
1553	689377563	FFadeeVV	Александр.😉	\N	https://t.me/i/userpic/320/zLST6fn2MUWuC_0XfRatNx_6EywtuykQ2Tjb0dsPP2s.svg	2026-07-01 07:57:55.099104+00	2026-07-01 07:58:01.465258+00	0101000020E610000064A25236F64A3E406DCA15DEE5FA4D40	2026-07-01 07:58:01.465258+00	0.00	0	0	f	\N	\N
1540	705880150	PolIgorya	Pol	Igorya	https://t.me/i/userpic/320/YnuRF8kMNiCD0yynfz2_FnP2Ss7t24OHkQQ4MpGV__w.jpg	2026-06-30 15:47:50.511474+00	2026-07-01 10:07:23.485347+00	\N	2026-07-01 10:07:23.485347+00	0.00	0	0	f	\N	\N
1557	1695671884	SilentShrine	A	R1Play	https://t.me/i/userpic/320/oIXyD964_LM-wQV0HV9ylrXk6KSD4psamILEOL61sqk.svg	2026-07-01 10:23:41.001176+00	2026-07-01 10:24:09.882931+00	0101000020E610000018DAEF3FE806404001E77BFC94BE4D40	2026-07-01 10:24:09.882931+00	0.00	0	0	f	\N	\N
1558	81650381	hodislav	Слава	\N	https://t.me/i/userpic/320/goXWZiFzt3F5uaSecoi2EAaUpmUD-aQ8w8jhrggsUd8.svg	2026-07-01 14:34:37.110171+00	2026-07-01 14:35:20.10952+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 14:35:20.10952+00	0.00	0	0	f	\N	\N
1559	-232487	vk232487	Dmitry	V	https://sun1-30.vkuserphoto.ru/s/v1/ig2/lzFq3Kqr3QVS8slS0uDouU-qSPzzNjBlMfmxVzD8HKvU4JBy9kQr5aHAPLgmmrJSRvXD5x-F3ojMdMfmZ0kgJxza.jpg?quality=95&crop=160,160,319,319&as=32x32,48x48,72x72,108x108,160x160,240x240&ava=1&cs=50x50	2026-07-01 15:05:54.452732+00	2026-07-01 15:06:11.472116+00	0101000020E610000012578451FF513E40EC5C627660E14D40	2026-07-01 15:06:11.472116+00	0.00	0	0	f	\N	\N
1563	1518204487	Alex_Grilanse	Alex	Grilanse	https://t.me/i/userpic/320/ejK9j6DWrXiNTd-bEeGIJS8vOUmNFWIQzL6NDEnhOoc.svg	2026-07-01 18:33:29.201529+00	2026-07-01 18:33:29.201529+00	\N	2026-07-01 18:33:29.201529+00	0.00	0	0	f	\N	\N
1564	5042942435	YanPivCof	𝕐𝕒𝕟 ♪	कॉफ़ीवबीर	https://t.me/i/userpic/320/fNIhx-wAfeXCAWG1P-h2FJIyRXlLUz9enf_6FdoBEBwfQEKiFsQiS7O_FU1U1NMS.svg	2026-07-01 18:46:58.281333+00	2026-07-01 18:47:46.012711+00	0101000020E6100000CEEAD3E06C4B3E4095CB907417F04D40	2026-07-01 18:47:46.012711+00	0.00	0	0	f	\N	\N
1565	175185867	denchik_dizzya	Denchik	Dizzya	https://t.me/i/userpic/320/LfiZJ5MeWBYNGgAirZGP1hiAmga-GFHIqvNP1E2_WpQ.svg	2026-07-01 18:53:47.404173+00	2026-07-01 18:55:09.713204+00	\N	2026-07-01 18:55:09.713204+00	0.00	0	0	f	\N	\N
1567	6210727148	Finallynormalpeople	Евгений	\N	https://t.me/i/userpic/320/oUbjp8t_olYWJOuJY4q6eA1LV8Q-WOBAbP2RAeL2oTJxS7vVvqhzjTt95_tmP--t.svg	2026-07-01 18:56:08.960336+00	2026-07-01 18:56:08.960336+00	\N	2026-07-01 18:56:08.960336+00	0.00	0	0	f	\N	\N
1568	955043848	kosyrevala	Любовь	Косырева	https://t.me/i/userpic/320/KYtBE24NAlhpk0jLyT17UgUGE-M6vPhFDLCokA3r4dc.svg	2026-07-01 19:20:41.383265+00	2026-07-01 19:21:08.326571+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 19:21:08.326571+00	0.00	0	0	f	\N	\N
1569	1296832351	LLLCCCRAZ	Ivan.O	\N	https://t.me/i/userpic/320/48IfH_Cw1GjjVltdF6H7mK2Gy0H6vHQNxRz2cCkfHZE.svg	2026-07-01 19:25:27.832958+00	2026-07-01 19:25:31.674268+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 19:25:31.674268+00	0.00	0	0	f	\N	\N
1560	1980232238	omnia_floont	omnia_floont	\N	https://t.me/i/userpic/320/_dHIdXd6_ObWQXmCPL1Fi93LspVpU9GDUILv55bY8GA.svg	2026-07-01 17:20:26.026229+00	2026-07-01 19:31:23.677228+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-01 19:31:23.677228+00	0.00	0	0	f	\N	\N
1277	393068765	Kotyarishe	Константин	\N	https://t.me/i/userpic/320/Dd9PMWEvDFd2CAFwyzqarhM6mSaeW7VSWnhJ-_6XEaY.svg	2026-06-08 18:45:19.357438+00	2026-07-01 19:57:36.077092+00	0101000020E6100000DC9E20B1DD313E4098689082A7FE4D40	2026-07-01 19:57:36.077092+00	0.00	0	0	f	\N	\N
1573	616781392	WarmSeam	Егор	Иванов	https://t.me/i/userpic/320/K1Ek_kZQf87pZIYUJPJu2PlFzU62_bEEBAEgCKJ7uHY.svg	2026-07-01 20:00:18.329672+00	2026-07-01 20:00:18.329672+00	\N	2026-07-01 20:00:18.329672+00	0.00	0	0	f	\N	\N
1570	471200455	azrax81	Алексей	\N	https://t.me/i/userpic/320/vLHFV9LT_jWZeggO9fT5Woz4gSN7Lcq1nIXaBIagwNk.svg	2026-07-01 19:44:49.48864+00	2026-07-01 20:09:01.108643+00	\N	2026-07-01 20:09:01.108643+00	0.00	0	0	f	\N	\N
1574	40810031	nord1dea	Nikolay	Antonets	https://t.me/i/userpic/320/1LlaPt2hVl1k6SBccaweIHecQwOnZL0fuHjM9G7HvY8.svg	2026-07-01 20:26:58.8201+00	2026-07-01 20:26:58.8201+00	\N	2026-07-01 20:26:58.8201+00	0.00	0	0	f	\N	\N
1583	1253945817	Mi_r_u_mi_r	Миру Мир!	\N	https://t.me/i/userpic/320/MFR3qwmDtqBPmGYtR-IQV-AlfKsywx62C_OKGJxEG2Y.svg	2026-07-02 09:50:42.239111+00	2026-07-02 09:50:49.960316+00	0101000020E6100000EEDF06C60B9B3E40077F1A52A0DF4D40	2026-07-02 09:50:49.960316+00	0.00	0	0	f	\N	\N
1584	437202248	Usinstudio888	Екатерина НАТУРАЛЬНЫЕ Камни Браслеты Usinstudio.ru	\N	https://t.me/i/userpic/320/Qyhwi0nu0Armi8VdM8QtiNzS2LP3nPSQjRAwvzDMjpA.svg	2026-07-02 10:27:10.14026+00	2026-07-02 10:27:10.14026+00	\N	2026-07-02 10:27:10.14026+00	0.00	0	0	f	\N	\N
1585	1115446705	Kirill_Va	Кирилл🦕	\N	https://t.me/i/userpic/320/L8KrKrrmlM2D2hkcglVXAsAZ3xsEpVCRZ-s__qLHZn8.svg	2026-07-02 11:25:21.278056+00	2026-07-02 11:26:34.096321+00	\N	2026-07-02 11:26:34.096321+00	0.00	0	0	f	\N	\N
1555	5553430236	Shywzus	SHYWZUS	\N	https://t.me/i/userpic/320/Y-5jY0naoN2IgL85k74-ZNIsCN3IpSQ9B5mcSLIr8tDDA3_4zL7rZRNbyFq7GAqp.svg	2026-07-01 08:27:55.209024+00	2026-07-02 12:04:05.268101+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-02 12:04:05.268101+00	0.00	0	0	f	\N	\N
1	653848276	space4rest	. .	\N	https://t.me/i/userpic/320/J0p8oFMzf2KmicXf1MJvrPtLPV9Y1sR-AMO8ntCRvR8.svg	2026-02-09 09:14:34.275433+00	2026-07-02 18:27:55.5156+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-02 18:27:55.5156+00	0.00	0	1300	f	\N	\N
1587	352684960	santovva	Anton	Santowa	https://t.me/i/userpic/320/VUv8Usi9Wz52SERnGa1wqCtQCHm7yKTFUC1Dz7eaDZA.svg	2026-07-02 12:53:56.739477+00	2026-07-02 12:54:10.484906+00	0101000020E6100000D2F654F3C1613E408E942D9276FC4D40	2026-07-02 12:54:10.484906+00	0.00	0	0	f	\N	\N
1488	204450760	alinkino	Ой, всё!	\N	https://t.me/i/userpic/320/JXJM7AyBtCwNlJyQZxsWynxusGznSQRt9QDh67bAojU.svg	2026-06-26 18:01:35.619955+00	2026-07-02 15:05:49.085207+00	\N	2026-07-02 15:05:49.085207+00	0.00	0	0	f	\N	\N
1400	375375596	Regwoman	Reg	Woman🌙	https://t.me/i/userpic/320/NkWKzgEu0KSEYkRofrO0mQLmuCx62PiU38sOahjLlxs.svg	2026-06-21 11:55:12.659684+00	2026-07-02 16:55:17.541443+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-02 16:55:17.541443+00	0.00	0	0	f	\N	\N
1591	528560758	ilya_sun	Илья	\N	https://t.me/i/userpic/320/Vs2dEiUB7B87hxxu1Pgvl00Aeei2S8niElHQwbbXzwI.svg	2026-07-02 17:45:26.811631+00	2026-07-02 17:45:31.476953+00	0101000020E61000009A999999999913408FC2F5285C2F4A40	2026-07-02 17:45:31.476953+00	0.00	0	0	f	\N	\N
1592	6415872464	white_banshi	White	Banshi	https://t.me/i/userpic/320/liJ34_N051fKN0XBwrLOwBL0hs2TZ__lBg1SjUoycnSMx5Zf0zBw_A1Da5C3-yPr.svg	2026-07-02 17:54:09.089839+00	2026-07-02 17:54:09.089839+00	\N	2026-07-02 17:54:09.089839+00	0.00	0	0	f	\N	\N
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: gigme
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: gigme
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: admin_bot_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.admin_bot_messages_id_seq', 192, true);


--
-- Name: admin_broadcast_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.admin_broadcast_jobs_id_seq', 445, true);


--
-- Name: admin_broadcasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.admin_broadcasts_id_seq', 5, true);


--
-- Name: admin_event_parser_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.admin_event_parser_events_id_seq', 5, true);


--
-- Name: admin_event_parser_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.admin_event_parser_sources_id_seq', 2, true);


--
-- Name: event_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.event_comments_id_seq', 24, true);


--
-- Name: event_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.event_media_id_seq', 14, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.events_id_seq', 18, true);


--
-- Name: notification_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.notification_jobs_id_seq', 1294, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.order_items_id_seq', 118, true);


--
-- Name: referral_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.referral_claims_id_seq', 27, true);


--
-- Name: referral_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.referral_codes_id_seq', 9, true);


--
-- Name: user_push_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.user_push_tokens_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gigme
--

SELECT pg_catalog.setval('public.users_id_seq', 1593, true);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: gigme
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: admin_bot_messages admin_bot_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_bot_messages
    ADD CONSTRAINT admin_bot_messages_pkey PRIMARY KEY (id);


--
-- Name: admin_broadcast_jobs admin_broadcast_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcast_jobs
    ADD CONSTRAINT admin_broadcast_jobs_pkey PRIMARY KEY (id);


--
-- Name: admin_broadcasts admin_broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcasts
    ADD CONSTRAINT admin_broadcasts_pkey PRIMARY KEY (id);


--
-- Name: admin_event_parser_events admin_event_parser_events_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_events
    ADD CONSTRAINT admin_event_parser_events_pkey PRIMARY KEY (id);


--
-- Name: admin_event_parser_sources admin_event_parser_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_sources
    ADD CONSTRAINT admin_event_parser_sources_pkey PRIMARY KEY (id);


--
-- Name: event_comments event_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_pkey PRIMARY KEY (id);


--
-- Name: event_likes event_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_likes
    ADD CONSTRAINT event_likes_pkey PRIMARY KEY (event_id, user_id);


--
-- Name: event_media event_media_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_media
    ADD CONSTRAINT event_media_pkey PRIMARY KEY (id);


--
-- Name: event_participants event_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_pkey PRIMARY KEY (event_id, user_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: landing_content landing_content_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.landing_content
    ADD CONSTRAINT landing_content_pkey PRIMARY KEY (id);


--
-- Name: notification_jobs notification_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.notification_jobs
    ADD CONSTRAINT notification_jobs_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_settings payment_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_pkey PRIMARY KEY (id);


--
-- Name: payment_settings_scoped payment_settings_scoped_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payment_settings_scoped
    ADD CONSTRAINT payment_settings_scoped_pkey PRIMARY KEY (scope);


--
-- Name: payments payments_order_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_provider_key UNIQUE (order_id, provider);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: promo_codes promo_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_code_key UNIQUE (code);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: referral_claims referral_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims
    ADD CONSTRAINT referral_claims_pkey PRIMARY KEY (id);


--
-- Name: referral_codes referral_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_codes
    ADD CONSTRAINT referral_codes_code_key UNIQUE (code);


--
-- Name: referral_codes referral_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_codes
    ADD CONSTRAINT referral_codes_pkey PRIMARY KEY (id);


--
-- Name: sbp_qr sbp_qr_order_id_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.sbp_qr
    ADD CONSTRAINT sbp_qr_order_id_key UNIQUE (order_id);


--
-- Name: sbp_qr sbp_qr_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.sbp_qr
    ADD CONSTRAINT sbp_qr_pkey PRIMARY KEY (id);


--
-- Name: sbp_qr sbp_qr_qrc_id_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.sbp_qr
    ADD CONSTRAINT sbp_qr_qrc_id_key UNIQUE (qrc_id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: ticket_products ticket_products_event_id_type_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.ticket_products
    ADD CONSTRAINT ticket_products_event_id_type_key UNIQUE (event_id, type);


--
-- Name: ticket_products ticket_products_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.ticket_products
    ADD CONSTRAINT ticket_products_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: transfer_products transfer_products_event_id_direction_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.transfer_products
    ADD CONSTRAINT transfer_products_event_id_direction_key UNIQUE (event_id, direction);


--
-- Name: transfer_products transfer_products_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.transfer_products
    ADD CONSTRAINT transfer_products_pkey PRIMARY KEY (id);


--
-- Name: user_contact_matches user_contact_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_contact_matches
    ADD CONSTRAINT user_contact_matches_pkey PRIMARY KEY (user_id, contact_user_id);


--
-- Name: user_push_tokens user_push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_push_tokens
    ADD CONSTRAINT user_push_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_push_tokens user_push_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_push_tokens
    ADD CONSTRAINT user_push_tokens_token_key UNIQUE (token);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_id_key; Type: CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_telegram_id_key UNIQUE (telegram_id);


--
-- Name: admin_bot_messages_chat_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_bot_messages_chat_created_ix ON public.admin_bot_messages USING btree (chat_id, created_at DESC);


--
-- Name: admin_bot_messages_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_bot_messages_created_ix ON public.admin_bot_messages USING btree (created_at DESC);


--
-- Name: admin_broadcast_jobs_broadcast_status_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_broadcast_jobs_broadcast_status_ix ON public.admin_broadcast_jobs USING btree (broadcast_id, status);


--
-- Name: admin_broadcast_jobs_status_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_broadcast_jobs_status_created_ix ON public.admin_broadcast_jobs USING btree (status, created_at);


--
-- Name: admin_event_parser_events_source_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_event_parser_events_source_ix ON public.admin_event_parser_events USING btree (source_id, parsed_at DESC);


--
-- Name: admin_event_parser_events_status_parsed_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_event_parser_events_status_parsed_ix ON public.admin_event_parser_events USING btree (status, parsed_at DESC);


--
-- Name: admin_event_parser_sources_active_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX admin_event_parser_sources_active_ix ON public.admin_event_parser_sources USING btree (is_active, created_at DESC);


--
-- Name: event_comments_event_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_comments_event_ix ON public.event_comments USING btree (event_id);


--
-- Name: event_comments_user_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_comments_user_ix ON public.event_comments USING btree (user_id);


--
-- Name: event_likes_event_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_likes_event_ix ON public.event_likes USING btree (event_id);


--
-- Name: event_likes_user_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_likes_user_ix ON public.event_likes USING btree (user_id);


--
-- Name: event_media_event_id_id_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_media_event_id_id_ix ON public.event_media USING btree (event_id, id);


--
-- Name: event_participants_event_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_participants_event_ix ON public.event_participants USING btree (event_id);


--
-- Name: event_participants_user_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX event_participants_user_ix ON public.event_participants USING btree (user_id);


--
-- Name: events_access_key_uix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE UNIQUE INDEX events_access_key_uix ON public.events USING btree (access_key) WHERE (access_key IS NOT NULL);


--
-- Name: events_landing_published_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX events_landing_published_ix ON public.events USING btree (is_landing_published, starts_at) WHERE ((is_hidden = false) AND (is_private = false));


--
-- Name: events_location_gix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX events_location_gix ON public.events USING gist (location);


--
-- Name: events_starts_at_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX events_starts_at_ix ON public.events USING btree (starts_at);


--
-- Name: notification_jobs_status_run_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX notification_jobs_status_run_ix ON public.notification_jobs USING btree (status, run_at);


--
-- Name: order_items_order_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX order_items_order_ix ON public.order_items USING btree (order_id);


--
-- Name: orders_event_status_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX orders_event_status_created_ix ON public.orders USING btree (event_id, status, created_at DESC);


--
-- Name: orders_status_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX orders_status_created_ix ON public.orders USING btree (status, created_at DESC);


--
-- Name: orders_user_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX orders_user_created_ix ON public.orders USING btree (user_id, created_at DESC);


--
-- Name: payments_provider_payment_id_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX payments_provider_payment_id_ix ON public.payments USING btree (provider_payment_id);


--
-- Name: payments_provider_status_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX payments_provider_status_created_ix ON public.payments USING btree (provider, status, created_at DESC);


--
-- Name: promo_codes_code_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX promo_codes_code_ix ON public.promo_codes USING btree (lower(code));


--
-- Name: referral_claims_code_invitee_uix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE UNIQUE INDEX referral_claims_code_invitee_uix ON public.referral_claims USING btree (referral_code_id, invitee_user_id);


--
-- Name: referral_claims_invitee_uix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE UNIQUE INDEX referral_claims_invitee_uix ON public.referral_claims USING btree (invitee_user_id);


--
-- Name: referral_claims_inviter_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX referral_claims_inviter_ix ON public.referral_claims USING btree (inviter_user_id);


--
-- Name: referral_codes_owner_uix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE UNIQUE INDEX referral_codes_owner_uix ON public.referral_codes USING btree (owner_user_id);


--
-- Name: sbp_qr_status_created_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX sbp_qr_status_created_ix ON public.sbp_qr USING btree (status, created_at DESC);


--
-- Name: ticket_products_event_active_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX ticket_products_event_active_ix ON public.ticket_products USING btree (event_id, is_active);


--
-- Name: tickets_event_redeemed_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX tickets_event_redeemed_ix ON public.tickets USING btree (event_id, redeemed_at);


--
-- Name: tickets_order_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX tickets_order_ix ON public.tickets USING btree (order_id);


--
-- Name: tickets_qr_delivery_pending_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX tickets_qr_delivery_pending_ix ON public.tickets USING btree (order_id, qr_delivered_at) WHERE ((qr_payload IS NOT NULL) AND (qr_delivered_at IS NULL));


--
-- Name: tickets_user_event_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX tickets_user_event_ix ON public.tickets USING btree (user_id, event_id);


--
-- Name: transfer_products_event_active_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX transfer_products_event_active_ix ON public.transfer_products USING btree (event_id, is_active);


--
-- Name: user_contact_matches_contact_user_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX user_contact_matches_contact_user_ix ON public.user_contact_matches USING btree (contact_user_id);


--
-- Name: user_push_tokens_platform_active_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX user_push_tokens_platform_active_ix ON public.user_push_tokens USING btree (platform, is_active);


--
-- Name: user_push_tokens_user_active_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX user_push_tokens_user_active_ix ON public.user_push_tokens USING btree (user_id, is_active, updated_at DESC);


--
-- Name: users_is_blocked_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX users_is_blocked_ix ON public.users USING btree (is_blocked);


--
-- Name: users_last_location_gix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX users_last_location_gix ON public.users USING gist (last_location);


--
-- Name: users_last_seen_at_ix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX users_last_seen_at_ix ON public.users USING btree (last_seen_at);


--
-- Name: users_telegram_id_uix; Type: INDEX; Schema: public; Owner: gigme
--

CREATE INDEX users_telegram_id_uix ON public.users USING btree (telegram_id);


--
-- Name: admin_broadcast_jobs admin_broadcast_jobs_broadcast_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcast_jobs
    ADD CONSTRAINT admin_broadcast_jobs_broadcast_id_fkey FOREIGN KEY (broadcast_id) REFERENCES public.admin_broadcasts(id) ON DELETE CASCADE;


--
-- Name: admin_broadcast_jobs admin_broadcast_jobs_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcast_jobs
    ADD CONSTRAINT admin_broadcast_jobs_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: admin_broadcasts admin_broadcasts_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_broadcasts
    ADD CONSTRAINT admin_broadcasts_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.users(id);


--
-- Name: admin_event_parser_events admin_event_parser_events_imported_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_events
    ADD CONSTRAINT admin_event_parser_events_imported_by_fkey FOREIGN KEY (imported_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: admin_event_parser_events admin_event_parser_events_imported_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_events
    ADD CONSTRAINT admin_event_parser_events_imported_event_id_fkey FOREIGN KEY (imported_event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: admin_event_parser_events admin_event_parser_events_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_events
    ADD CONSTRAINT admin_event_parser_events_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.admin_event_parser_sources(id) ON DELETE SET NULL;


--
-- Name: admin_event_parser_sources admin_event_parser_sources_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.admin_event_parser_sources
    ADD CONSTRAINT admin_event_parser_sources_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: event_comments event_comments_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_comments event_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: event_likes event_likes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_likes
    ADD CONSTRAINT event_likes_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_likes event_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_likes
    ADD CONSTRAINT event_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: event_media event_media_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_media
    ADD CONSTRAINT event_media_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_participants event_participants_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: event_participants event_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.event_participants
    ADD CONSTRAINT event_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: events events_creator_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_creator_user_id_fkey FOREIGN KEY (creator_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: landing_content landing_content_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.landing_content
    ADD CONSTRAINT landing_content_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notification_jobs notification_jobs_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.notification_jobs
    ADD CONSTRAINT notification_jobs_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: notification_jobs notification_jobs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.notification_jobs
    ADD CONSTRAINT notification_jobs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_canceled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_canceled_by_fkey FOREIGN KEY (canceled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: orders orders_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: orders orders_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: orders orders_promo_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_promo_code_id_fkey FOREIGN KEY (promo_code_id) REFERENCES public.promo_codes(id) ON DELETE SET NULL;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_settings_scoped payment_settings_scoped_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payment_settings_scoped
    ADD CONSTRAINT payment_settings_scoped_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payment_settings payment_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payment_settings
    ADD CONSTRAINT payment_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: promo_codes promo_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: promo_codes promo_codes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE SET NULL;


--
-- Name: referral_claims referral_claims_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims
    ADD CONSTRAINT referral_claims_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: referral_claims referral_claims_invitee_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims
    ADD CONSTRAINT referral_claims_invitee_user_id_fkey FOREIGN KEY (invitee_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_claims referral_claims_inviter_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims
    ADD CONSTRAINT referral_claims_inviter_user_id_fkey FOREIGN KEY (inviter_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_claims referral_claims_referral_code_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_claims
    ADD CONSTRAINT referral_claims_referral_code_id_fkey FOREIGN KEY (referral_code_id) REFERENCES public.referral_codes(id) ON DELETE CASCADE;


--
-- Name: referral_codes referral_codes_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.referral_codes
    ADD CONSTRAINT referral_codes_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sbp_qr sbp_qr_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.sbp_qr
    ADD CONSTRAINT sbp_qr_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: ticket_products ticket_products_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.ticket_products
    ADD CONSTRAINT ticket_products_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ticket_products ticket_products_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.ticket_products
    ADD CONSTRAINT ticket_products_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_redeemed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_redeemed_by_fkey FOREIGN KEY (redeemed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transfer_products transfer_products_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.transfer_products
    ADD CONSTRAINT transfer_products_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: transfer_products transfer_products_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.transfer_products
    ADD CONSTRAINT transfer_products_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id) ON DELETE CASCADE;


--
-- Name: user_contact_matches user_contact_matches_contact_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_contact_matches
    ADD CONSTRAINT user_contact_matches_contact_user_id_fkey FOREIGN KEY (contact_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_contact_matches user_contact_matches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_contact_matches
    ADD CONSTRAINT user_contact_matches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_push_tokens user_push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gigme
--

ALTER TABLE ONLY public.user_push_tokens
    ADD CONSTRAINT user_push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: gigme
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO gigme;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: gigme
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- Database "template_postgis" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: template_postgis; Type: DATABASE; Schema: -; Owner: gigme
--

CREATE DATABASE template_postgis WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE template_postgis OWNER TO gigme;

\connect template_postgis

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: template_postgis; Type: DATABASE PROPERTIES; Schema: -; Owner: gigme
--

ALTER DATABASE template_postgis IS_TEMPLATE = true;
ALTER DATABASE template_postgis SET search_path TO '$user', 'public', 'topology', 'tiger';


\connect template_postgis

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO gigme;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO gigme;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: gigme
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO gigme;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: gigme
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: gigme
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: gigme
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: gigme
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: gigme
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: gigme
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

